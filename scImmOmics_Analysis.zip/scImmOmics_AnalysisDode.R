##################################################################scRNA-seq基本处理代码
library(Seurat)
library(ggplot2)
library(dplyr)
Downloadrds2<-count[,which(colnames(count)%in%meta[,1])]
row.names(Downloadrds2)<-count[,1]
meta2<-meta[which(meta[,1]%in%colnames(Downloadrds2)),]
row.names(meta2)<-meta2[,1]
pbmc <- CreateSeuratObject(counts = Downloadrds2, project = "pbmc",meta.data=as.data.frame(meta2))
pbmc <- NormalizeData(pbmc)
Downloadrds3<-pbmc@assays$RNA@data
all.genes <- rownames(pbmc)
pbmc <- FindVariableFeatures(object = pbmc, nfeatures = 2000)
pbmc <- ScaleData(pbmc, features = all.genes)
pbmc <- RunPCA(pbmc, features = VariableFeatures(object = pbmc))
pbmc <- JackStraw(pbmc, num.replicate = 100)
pbmc <- ScoreJackStraw(pbmc, dims = 1:10)
pbmc <- FindNeighbors(pbmc, dims = 1:10)
pbmc <- FindClusters(pbmc, resolution = 0.5)
pbmc <- RunUMAP(pbmc, dims = 1:10)
meta5<-cbind(as.matrix(pbmc@meta.data)[,4],matrix(1:length(as.matrix(pbmc@meta.data)[,4]),ncol=1),"UMAP",as.matrix(pbmc@reductions$umap@cell.embeddings),as.matrix(pbmc@meta.data)[,5:11])
colnames(meta5)<-c("ID","Index","Axis","Axis.x","Axis.y","SampleInfo","SampleInfo2","CellType","CellType2","GSM","Tissue","Disease_Status")
write.csv(meta5,paste0("metadata2.csv"),row.names=F,quote=F)
saveRDS(pbmc,paste0("Seurat.rds"))
indx <- factor(colnames(Downloadrds3), levels = as.vector(meta5[,2]))
Downloadrds4<- Downloadrds3[,order(indx)]
saveRDS(Downloadrds4,paste0("EXP.rds"))

##################################################################差异基因&功能注释
library(Seurat)
library(SeuratDisk)
library(ggplot2)
library(patchwork)
library(clusterProfiler)
library(org.Hs.eg.db)
pbmc<-readRDS(paste0("Seurat.rds"))
Idents(pbmc) <- pbmc@meta.data$CellType2
levels(pbmc)
markers_df <-FindAllMarkers(object = pbmc,only.pos = TRUE,logfc.threshold = 0.25)
write.csv(markers_df,paste0("DEG.csv"),row.names=F,quote=F)
result<-c()
Class<-as.character(unique(markers_df[,6]))
for(i in 1:length(Class))
{
genes<-as.matrix(unique(markers_df[which(markers_df[,6]%in%Class[i]),7]))
enrich.go <- enrichGO(gene = genes,  #待富集的基因列表
    OrgDb = 'org.Hs.eg.db',  #指定物种的基因数据库，示例物种是绵羊（sheep）
    keyType = 'SYMBOL',  #指定给定的基因名称类型，例如这里以 entrze id 为例
    ont = 'ALL',  #GO Ontology，可选 BP、MF、CC，也可以指定 ALL 同时计算 3 者
    pAdjustMethod = 'fdr',  #指定 p 值校正方法
    pvalueCutoff = 0.05,  #指定 p 值阈值（可指定 1 以输出全部）
    qvalueCutoff = 0.2,  #指定 q 值阈值（可指定 1 以输出全部）
    readable = FALSE)
if(length(as.data.frame(enrich.go)$ID)>0)
{
tmp<-as.matrix(cbind("GO",Class[i],as.data.frame(enrich.go)[,-1]))
}else{
tmp<-c()
}
trans = bitr(genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
kegg <- enrichKEGG(
    gene = trans$ENTREZID,  #基因列表文件中的基因名称
    keyType = 'kegg',  #KEGG 富集
    organism = 'hsa',  #例如，oas 代表绵羊，其它物种更改这行即可
    pAdjustMethod = 'fdr',  #指定 p 值校正方法
    pvalueCutoff = 0.05,  #指定 p 值阈值（可指定 1 以输出全部）
    qvalueCutoff = 0.2)  #指定 q 值阈值（可指定 1 以输出全部）
if(length(as.data.frame(kegg)$ID)>0)
{
tmp2<-as.matrix(cbind("Pathway",Class[i],as.data.frame(kegg)))
}else{
tmp2<-c()
}
result<-rbind(result,tmp2,tmp)
}
write.table(result,paste0("DEG_FunAnn.txt"),row.names=F,quote=F,sep="\t")

library(msigdbr)
library(dplyr)
library(clusterProfiler)
library(org.Hs.eg.db)
m_t2g <- msigdbr(species = "Homo sapiens", category = "C7") %>% dplyr::select(gs_name, entrez_gene)
markers_df<-read.csv(paste0("DEG.csv"),header=T)
result<-c()
Class<-as.character(unique(markers_df[,6]))
for(i in 1:length(Class))
{
genes<-as.matrix(unique(markers_df[which(markers_df[,6]%in%Class[i]),7]))
trans = bitr(genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
em <- enricher(gene = trans$ENTREZID,TERM2GENE=m_t2g,pAdjustMethod = 'fdr',pvalueCutoff = 0.05,qvalueCutoff = 0.2) 
if(length(as.data.frame(em)$ID)>0)
{
tmp2<-as.matrix(cbind("C7_ImmunologicSignatureGene",Class[i],as.data.frame(em)))
}else{
tmp2<-c()
}
result<-rbind(result,tmp2)
}
write.table(result,paste0("DEG_FunAnnC7.txt"),row.names=F,quote=F,sep="\t")

markers_df<-read.csv(DEG.csv"),header=T)
result<-c()
Class<-as.character(unique(markers_df[,6]))
for(i in 1:length(Class))
{
genes<-as.matrix(unique(markers_df[which(markers_df[,6]%in%Class[i]),7]))
trans = bitr(genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
em <- enricher(gene = trans$ENTREZID,TERM2GENE=m_t2g,pAdjustMethod = 'fdr',pvalueCutoff = 0.05,qvalueCutoff = 0.2) 
if(length(as.data.frame(em)$ID)>0)
{
tmp2<-as.matrix(cbind("H_Hallmark",Class[i],as.data.frame(em)))
}else{
tmp2<-c()
}
result<-rbind(result,tmp2)
}
colnames(result)[1:2]<-c("Hallmark","CellType2")
write.table(result,paste0("DEG_Hallmark.txt"),row.names=F,quote=F,sep="\t",eol = "\r\n")

##################################################################Monocle代码
library(monocle3)
library(Seurat)
library(ggplot2)
library(dplyr)
pbmc <- readRDS(paste0("Seurat.rds"))
meta<-as.matrix(read.csv(paste0("metadata2.csv"),header=T))
gene_metadata<-as.data.frame(matrix(row.names(pbmc@ assays$ RNA@ data),ncol=1))
row.names(gene_metadata)<-gene_metadata[,1]
data<-apply(as.matrix(as.data.frame(pbmc@ assays$ RNA@ data)),2,as.numeric)
row.names(data)<-gene_metadata[,1]
row.names(meta)<-meta[,1]

cds <- new_cell_data_set(data,
                         cell_metadata = pbmc@ meta.data,
                         gene_metadata = gene_metadata)

cds <- preprocess_cds(cds, num_dim = 100)
cds <- reduce_dimension(cds,reduction_method='UMAP',
                        preprocess_method = 'PCA')
cds <- cluster_cells(cds)


sam<-FetchData(pbmc ,vars=c("orig.ident","CellType2","UMAP_1","UMAP_2"))
reducedDims(cds)$UMAP<-sam[,c("UMAP_1","UMAP_2")]
colnames(reducedDims(cds)$UMAP)=c("V1","V2")


mycds <- learn_graph(cds,
                     verbose=T,
                     learn_graph_control=list(minimal_branch_len=20,#在图修剪过程中要保留的分支直径路径的最小长度。默认值是10。
                                              euclidean_distance_ratio=10#生成树中两个末端节点的欧氏距离与生成树上允许连接的任何连接点之间的最大距离之比。默认值为1。
                     ))

mycds2 <- mycds
get_earliest_principal_node <- function(cds){
  cell_ids <- dim(cds)[2]
  closest_vertex <- cds@principal_graph_aux[["UMAP"]]$pr_graph_cell_proj_closest_vertex
  closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
  root_pr_nodes <- igraph::V(principal_graph(cds)[["UMAP"]])$name[as.numeric(names(which.max(table(closest_vertex[cell_ids,]))))]
  root_pr_nodes
}
mycds2 <- order_cells(mycds2, root_pr_nodes=get_earliest_principal_node(mycds2))

pd <- pseudotime(mycds2, reduction_method = 'UMAP')
pbmc <- AddMetaData(pbmc,metadata = pd,col.name = 'pseudotime')#添加拟时
result<-cbind(meta,pbmc@ meta.data$pseudotime)
colnames(result)[length(result[1,])]<-"PseudoTime"
if(length(which(result[,length(result[1,])]%in%"Inf"))>1)
{
result[which(result[,length(result[1,])]%in%"Inf"),length(result[1,])]<-0
}
write.csv(result,paste0("metadata3.csv"),row.names=F,quote=F)
saveRDS(mycds2,paste0("Monocle.rds"))
pdf(paste0("Monocle.pdf"),width=10,height=8)
p<-plot_cells(mycds2, 
           color_cells_by = "pseudotime", 
           label_groups_by_cluster=F,
           label_leaves=F, 
           label_branch_points=F,
           graph_label_size=4)
plot(p)
dev.off()

##################################################################hdWGCNA代码
library(Seurat)
library(ggplot2)
library(patchwork)
library(hdWGCNA)
library(WGCNA)
library(tidyverse) 
library(igraph)
library(cowplot)
library(patchwork)
library(dplyr)
library(ggplot2)
library(stringr)
library(UCell)
library(ggraph)
library(tidygraph)
library(reshape2)
pbmc<-readRDS(paste0("Seurat.rds"))
pbmc <- SetupForWGCNA(pbmc,wgcna_name = "pbmc",gene_select = "fraction",fraction = 0.25)
pbmc <- MetacellsByGroups(seurat_obj =  pbmc ,group.by = c("CellType2","orig.ident"),k = 25,max_shared=20,reduction = 'umap',ident.group = 'CellType2')
pbmc <- NormalizeMetacells(pbmc)
pbmc <- SetDatExpr(pbmc, assay = 'RNA', slot = 'data')
pbmc <- TestSoftPowers(pbmc, networkType = 'signed') 
folder_path <- "scImmAtlas/Data/TOM/"
files <- list.files(folder_path, full.names = TRUE)
file.remove(files)
pbmc <- ConstructNetwork(pbmc,soft_power = 4,tom_name = "Test3",setDatExpr=T)
umap_df <- GetModuleUMAP(pbmc)
write.csv(umap_df,paste0("hdWGCNA_umap.csv"))
TOM <- GetTOM(pbmc)
graph <- TOM %>% igraph::graph_from_adjacency_matrix(mode='undirected', weighted=TRUE) %>% tidygraph::as_tbl_graph(directed=FALSE) %>% tidygraph::activate(nodes)
pbmc <- ModuleEigengenes(pbmc, group.by.vars = "CellType2")
pbmc <- ModuleConnectivity(pbmc)
pbmc <- ModuleExprScore(pbmc, n_genes = 25, method='UCell')
pbmc <- RunModuleUMAP(pbmc,n_hubs = 10, n_neighbors=10, min_dist=0.1, supervised=TRUE,target_weight=0.5)
modules <- GetModules(pbmc)
write.csv(modules, file = paste0("hdWGCNA_modules.csv"))
hub_df <- GetHubGenes(pbmc, n_hubs = 25)
write.csv(hub_df, file = paste0("hdWGCNA_hub_df.csv"))
graph2 <- melt(graph)
re<-c()
for(i in 1:length(as.matrix(graph2)))
{
re<-rbind(re[which(re[,3]>0),],cbind(as.matrix(graph2)[i],as.matrix(graph2),as.matrix(graph[i,])))
print(i)
}
write.csv(re,paste0("hdWGCNA_graph.csv"))

pdf(paste0("ModuleUMAPPlot_fianl.pdf"),width=8,height=8)
ModuleUMAPPlot(
  pbmc,
  edge.alpha=0.25,
  sample_edges=TRUE,
  edge_prop=0.1, # proportion of edges to sample (20% here)
  label_hubs=3 ,# how many hub genes to plot per module?
  keep_grey_edges=FALSE
)
dev.off()

pdf(paste0("ModuleFeaturePlot_hMEs.pdf"),width=10,height=8)
plot_hMEs <- ModuleFeaturePlot(
  pbmc,
  reduction = "umap",
  features='hMEs', # plot the hMEs
  order=TRUE,# order so the points with highest hMEs are on top
  raster = T
)
wrap_plots(plot_hMEs, ncol=3)
dev.off()


pdf(paste0(ModuleUMAPPlot_fianl2.pdf"),width=8,height=8)
ModuleUMAPPlot(
  pbmc,
  edge.alpha=0.25,
  sample_edges=TRUE,
  edge_prop=0.1, # proportion of edges to sample (20% here)
  label_hubs=3 ,# how many hub genes to plot per module?
  keep_grey_edges=FALSE
)
dev.off()

##################################################################cytotrace2代码
count<- readRDS(paste0("EXP.rds"))
meta<-read.table(paste0("metadata3.txt"),header=T,sep="\t")
row.names(meta)<-meta[,1]
pbmc <- CreateSeuratObject(counts = as.matrix(count),meta.data=as.data.frame(meta))
cytotrace2_sce <- cytotrace2(pbmc, #seurat对象
                             is_seurat = TRUE, 
                             slot_type = "counts", #counts和data都可以
                             species = 'human')#物种要选择，默认是小鼠
cytotrace2 <- data.frame(meta[,1:12],CytoTRACE2_Score=cytotrace2_sce$CytoTRACE2_Score,CytoTRACE2_Potency=cytotrace2_sce$CytoTRACE2_Potency,CytoTRACE2_Relative=cytotrace2_sce$CytoTRACE2_Relative,preKNN_CytoTRACE2_Score=cytotrace2_sce$preKNN_CytoTRACE2_Score,preKNN_CytoTRACE2_Potency=cytotrace2_sce$preKNN_CytoTRACE2_Potency)
write.table(cytotrace2,paste0("CytoTRACE2.txt"),row.names=F,quote=F,sep="\t")

##################################################################ClonalNetwork&StartracDiversity代码
pbmc<-readRDS("Seurat.rds")
pbmc <- combineExpression(combined, pbmc, 
                            cloneCall="gene", 
                           # group.by = "Sample", 
                            proportion = FALSE, 
                            cloneTypes=c(Single=1, Small=5, Medium=20, Large=100, Hyperexpanded=500))

pdf("ClonalNetwork.pdf")
clonalNetwork(pbmc, reduction = "umap", identity = "ident",filter.clones = NULL,
              filter.identity = NULL,cloneCall = "aa")
dev.off()

Idents(pbmc) <- pbmc@meta.data$CellType2
result<-StartracDiversity(pbmc, type = "CellType2",sample="GSMID",by = "overall",exportTable = T)
##################################################################CellChat代码
pbmc<-readRDS(paste0("Seurat.rds"))
HD.cellchat <- createCellChat(object = pbmc@assays$RNA@data, meta = pbmc@meta.data, group.by = "CellType2")
CellChatDB <- CellChatDB.human
HD.cellchat@DB <- CellChatDB
HD.cellchat <- subsetData(HD.cellchat) 
HD.cellchat <- identifyOverExpressedGenes(HD.cellchat)
HD.cellchat <- identifyOverExpressedInteractions(HD.cellchat)
HD.cellchat <- computeCommunProb(HD.cellchat, type = "triMean")
HD.cellchat <- filterCommunication(HD.cellchat, min.cells = 10)
HD.cellchat <- computeCommunProbPathway(HD.cellchat)
HD.cellchat <- aggregateNet(HD.cellchat)
df.net <- subsetCommunication(HD.cellchat) 
saveRDS(HD.cellchat,paste0("CellChat.rds"))

##################################################################scATAC代码
library(Matrix)
library(Seurat)
library(data.table)
library(magrittr)
library(ggplot2)
library(RColorBrewer)
library(viridis)
library(compiler)
library(readr)
library(matrixStats)
library(Matrix)
library(mefa4)
library(parallel)
library(devtools)
library(GenomicAlignments)
library(CNEr)
library(edgeR)
library(chromVARmotifs)
library(chromVAR)
library(BiocParallel)
library(motifmatchr)
library(Signac)
library(EnsDb.Hsapiens.v86)
library(biovizBase)
library(cicero)
library(Gviz)
library(httr2)
library(BSgenome.Hsapiens.UCSC.hg38)
library(chromVARmotifs)

dirt="/scImmAtlas"
mtx_path <- paste0(dirt, "/counts.mtx")
feature_path <- paste0(dirt, "/feature.tsv")
barcode_path <- paste0(dirt, "/barcode.tsv")
features <- fread(feature_path, header = F)
barcodes <- fread(barcode_path, header = F)
mtx <-  Matrix::readMM(mtx_path) %>%
    magrittr::set_rownames(features$V1)%>%
    magrittr::set_colnames(barcodes$V1) 
  

meta<-read.csv("metadata1.csv",header=T)
mtx2<-mtx[,which(colnames(mtx)%in%meta[,1])]
meta2<-meta[which(meta[,1]%in%colnames(mtx2)),]
row.names(meta2)<-meta2[,1]


genome_name = "hg38"
species="human"

if(species == "mouse"){
	tss_file = "mm10_tss.bed"
	genome_size_file = "chrom_mm10.sizes"
}
if(species == "human"){
	if(genome_name == "hg38")
	{
	tss_file = "hg38_tss.bed"
	genome_size_file = "chrom_hg38.sizes"
	}
	if(genome_name == "hg19")
	{
	tss_file = "hg19_tss.bed"
	genome_size_file = "chrom_hg19.sizes"
	}
	
}
if(species == "danRer"){
	tss_file = "danRer10_tss.bed"
	genome_size_file = "danRer10.chrom.sizes"
}


tss_path = tss_file
if(grepl(genome_name, pattern = '38'))genomeName = 'BSgenome.Hsapiens.UCSC.hg38'
if(grepl(genome_name, pattern = '19') || grepl(genome_name, pattern = '37'))genomeName = 'BSgenome.Hsapiens.UCSC.hg19'
if(grepl(genome_name, pattern = 'mm9'))genomeName = 'BSgenome.Mmusculus.UCSC.mm9'
if(grepl(genome_name, pattern = 'mm10'))genomeName = 'BSgenome.Mmusculus.UCSC.mm10'

tss_ann <- fread(tss_path, header = F)
names(tss_ann)[c(1:4)] <- c('chr', 'start', 'end', 'gene_name')

mtx3 = assignGene2Peak(mtx2, tss_ann)
colnames(mtx3)<-colnames(mtx2)


pbmc.atac = CreateSeuratObject(mtx3, project = 'scATAC',meta.data=as.data.frame(meta2), assay = 'ATAC',
                                  names.delim = '-', min.cells = 1,
                                  min.features = 1)
row.names(pbmc.atac@ assays$ ATAC@ layers$ counts)<-row.names(pbmc.atac@ assays$ ATAC@ features@ .Data)
colnames(pbmc.atac@ assays$ ATAC@ layers$ counts)<-row.names(pbmc.atac@ assays$ ATAC@ cells@ .Data)
pbmc.atac <- RunTFIDF(pbmc.atac)
pbmc.atac <- FindTopFeatures(pbmc.atac, min.cutoff = "q0")
pbmc.atac <- RunSVD(pbmc.atac)
pbmc.atac <- RunUMAP(pbmc.atac, reduction = "lsi", dims = 2:30, reduction.name = "umap.atac", reduction.key = "atacUMAP_")
Idents(pbmc.atac) <- pbmc.atac@meta.data$CellType2
levels(pbmc.atac)
markers_df <-FindAllMarkers(object = pbmc.atac,only.pos = TRUE,logfc.threshold = 0.25)

markers_df= data.table(markers_df)
markers_df[, 'peak0' := unlist(strsplit(gene, ','))[1], by = gene]
markers_df[, 'chr' := unlist(strsplit(peak0, ':'))[1], by = peak0]
markers_df[, 'start' := unlist(strsplit(peak0, ':'))[2], by = peak0]
markers_df[, 'end' := unlist(strsplit(start, '-'))[2], by = start]
markers_df[, 'start' := unlist(strsplit(start, '-'))[1], by = start]
markers_df$fdr =p.adjust(markers_df$p_val, method = 'fdr')
markers_df2= markers_df[fdr <= 0.05, ]
colnames(markers_df2)[7]<-"peak"
colnames(markers_df2)[11]<-"end"
write.table(markers_df2[,c(9,10,11,1:5,12,6:8)], file = paste0("scATAC_DA_peak.tsv"), sep = '\t', quote = F, row.names = F)
meta_result<-cbind(pbmc.atac@ meta.data[,4],pbmc.atac@ reductions$ umap.atac@ cell.embeddings,pbmc.atac@ meta.data[,c(7,10,6,5,11,8)])
colnames(meta_result)<-c("ID","UMAP1_X","UMAP1_Y","Celltype","Tissue","Stage","Sex","Health_state","Celltype2")
write.table(meta_result, file = paste0("metadata.txt"), sep = '\t', quote = F, row.names = F)


res = doCicero_gascore(pbmc.atac, reduction = 'umap', genome_size_file, tss_ann, npc = 30)
ga_score = log1p(res$ga_score * 10000)
ga_score<-ga_score[,match(rownames(meta_result),colnames(ga_score))]
conns = res$conns
saveRDS(ga_score, file = paste0("cicero_gene_activity.rds"))
write.table(conns, file = paste0("cicero_interactions.txt"), row.names = F,sep = '\t', quote = F)


if(grepl(genome_name, pattern = '38'))genomeName = 'BSgenome.Hsapiens.UCSC.hg38'
if(grepl(genome_name, pattern = '19') || grepl(genome_name, pattern = '37'))genomeName = 'BSgenome.Hsapiens.UCSC.hg19'
if(grepl(genome_name, pattern = 'mm9'))genomeName = 'BSgenome.Mmusculus.UCSC.mm9'
if(grepl(genome_name, pattern = 'mm10'))genomeName = 'BSgenome.Mmusculus.UCSC.mm10'
ncore = detectCores()
mtx = pbmc.atac@ assays$ ATAC@ layers$ counts
rnames = rownames(mtx)
new.rnames = sapply(rnames, function(x) unlist(strsplit(x, ','))[1])
new.rnames = sapply(new.rnames, function(x) gsub('_', '-', x))
names(new.rnames) = NULL
rownames(mtx) <- new.rnames

chromVar.obj = run_chromVAR(mtx, genomeName, max(1, ncore - 1))
saveRDS(chromVar.obj, file = paste0("chromVar_obj.rds"))

zscores<-chromVar.obj@assays@data$z
deviations<-chromVar.obj@assays@data$deviations
saveRDS(zscores, file = paste0("chromVar_obj_zscores.rds"))
saveRDS(deviations, file = paste0("chromVar_obj_deviations.rds"))

metaData = read.table(paste0("metadata.txt"),header=T,sep="\t")

dev = deviations(chromVar.obj)
da.res = do_DA_motif(dev, 
               clusters = data.table('barcode' = metaData$ID,
                                     'cluster' = metaData$Celltype2),topn = 10)
write.table(da.res, file = paste0("differential_TF_motif_enriched_in_clusters.tsv"), quote = F, sep = '\t', row.names = F)

zscores = deviationScores(chromVar.obj)
saveRDS(zscores , file = paste0("TF1000.rds"))

##################################################################整合分析代码
library(Seurat)
library(ggplot2)
library(patchwork)
library(Matrix)
library(Signac)
for(z in 1:length(name_ATAC))
{
count<-readRDS(paste0(name_ATAC[z],"_cicero_gene_activity.rds"))
meta<-read.csv(paste0(name_ATAC[z],"_metadata.csv"),header=T)
row.names(meta)<-meta[,1]
pbmc.atac <- CreateSeuratObject(counts = as.matrix(count),meta.data=as.data.frame(meta))
Idents(pbmc.atac) <- pbmc.atac@meta.data$Celltype2
pbmc.atac <- NormalizeData(pbmc.atac)
pbmc.atac <- ScaleData(pbmc.atac, features = rownames(pbmc.atac))
pbmc.atac <- RunTFIDF(pbmc.atac)
pbmc.atac <- FindTopFeatures(pbmc.atac)
pbmc.atac@meta.data$DataType<-"scATAC-seq"

for(n in 1:length(name_RNA))
{
count2<- readRDS(paste0(name_RNA[n],".rds"))
meta2<-read.table(paste0(name_RNA[n],"_metadata3.txt"),header=T,sep="\t")
row.names(meta2)<-meta2[,1]
pbmc.rna <- CreateSeuratObject(counts = as.matrix(count2),meta.data=as.data.frame(meta2))
pbmc.rna@meta.data$DataType<-"scRNA-seq"
Idents(pbmc.rna) <- pbmc.rna@meta.data$CellType2
pbmc.rna <- NormalizeData(pbmc.rna)
pbmc.rna <- ScaleData(pbmc.rna, features = rownames(pbmc.rna))
pbmc.rna <- FindVariableFeatures(pbmc.rna)

pbmc.list<-list()
pbmc.list[["ATAC"]]<-pbmc.atac
pbmc.list[["RNA"]]<-pbmc.rna
features <- SelectIntegrationFeatures(object.list = pbmc.list)

anchors <- FindIntegrationAnchors(object.list = pbmc.list, anchor.features = features)
combined <- IntegrateData(anchorset = anchors)
DefaultAssay(combined) <- "integrated"
combined <- ScaleData(combined, features = VariableFeatures(object = combined))
combined <- RunPCA(combined, features = VariableFeatures(object = combined))
combined <- RunUMAP(combined, features = VariableFeatures(object = combined))

write.csv(combined@ meta.data,paste0(name_RNA[n],"&",name_ATAC[z],".csv"))
saveRDS(combined,paste0(name_RNA[n],"&",name_ATAC[z],".rds"))
}
}
##################################################################AUCell代码
pbmc <- readRDS(paste0("EXP.rds"))
Set<-unique(file[,4])
AUCell_result<-c()
for(i in 1:length(Set))
{
geneSets<-as.data.frame(na.omit(file[which(file[,4]%in%Set[i]),3]))
cells_rankings<-AUCell_buildRankings(pbmc)
cells_AUC <- AUCell_calcAUC(geneSets,cells_rankings)
AUCell_result<-cbind(AUCell_result,matrix(cells_AUC@assays@data$AUC,ncol=1))
}
colnames(AUCell_result)<-Set
row.names(AUCell_result)<-colnames(pbmc)
saveRDS(AUCell_result,paste0("AUCell.rds"))