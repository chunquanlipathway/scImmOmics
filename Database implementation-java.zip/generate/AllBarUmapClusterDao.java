package generate;

import com.lcq.cell.pojo.AllBarUmapCluster;

public interface AllBarUmapClusterDao {
    int insert(AllBarUmapCluster record);

    int insertSelective(AllBarUmapCluster record);
}