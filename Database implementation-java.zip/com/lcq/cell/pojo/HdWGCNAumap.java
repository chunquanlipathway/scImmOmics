package com.lcq.cell.pojo;

import lombok.Data;
import java.io.Serializable;
/**
 * all_bar_umap_cluster
 * @author
 */
@Data
public class HdWGCNAumap implements Serializable{
    private String umap1;
    private String umap2;
    private String gene;
    private String module;
    private String color;
    private String hub;
    private String kme;

    private static final long serialVersionUID = 1L;
}
