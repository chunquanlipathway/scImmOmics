package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class Deg {
    private String p_val;
    private String avg_log2FC;
    private String pct1;
    private String pct2;
    private String p_val_adj;
    private String cluster;
    private String gene;
}
