package com.lcq.cell.pojo;

import java.io.Serializable;
import lombok.Data;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class AllBarUmapCluster implements Serializable {
    private String barcode;

    private String x;

    private String y;

    private String celltype;
    private String cluster;

    private static final long serialVersionUID = 1L;
}