package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class AUCellUmap implements Serializable {
    private String axis_x;
    private String axis_y;
    private String aucell;

    private static final long serialVersionUID = 1L;
}