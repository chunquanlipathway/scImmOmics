package com.lcq.cell.pojo;

public class BrowseTable {
    private String sampleID;
    private String dataSource;
    private String biosampleType;
    private String tissueType;
    private String biosampleName;
    private String idenSignal;
    private String pmid;
    private String article;
    private String journal;
    private String year;
    private String sapiens;
    private String tissue;
    private String disease;
    private String cell_Number;
    private String cellType_Number;
    private String data_Type;
    private String rna_GSE;
    private String integrated;
    private String status;
    private String platform;
    private String orderid;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getIntegrated() {
        return integrated;
    }

    public void setIntegrated(String integrated) {
        this.integrated = integrated;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getPmid() {
        return pmid;
    }

    public void setPmid(String pmid) {
        this.pmid = pmid;
    }

    public String getArticle() {
        return article;
    }

    public void setArticle(String article) {
        this.article = article;
    }

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSapiens() {
        return sapiens;
    }

    public void setSapiens(String sapiens) {
        this.sapiens = sapiens;
    }

    public String getTissue() {
        return tissue;
    }

    public void setTissue(String tissue) {
        this.tissue = tissue;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getCell_Number() {
        return cell_Number;
    }

    public void setCell_Number(String cell_Number) {
        this.cell_Number = cell_Number;
    }

    public String getCellType_Number() {
        return cellType_Number;
    }

    public void setCellType_Number(String cellType_Number) {
        this.cellType_Number = cellType_Number;
    }

    public String getData_Type() {
        return data_Type;
    }

    public void setData_Type(String data_Type) {
        this.data_Type = data_Type;
    }

    public String getRna_GSE() {
        return rna_GSE;
    }

    public void setRna_GSE(String rna_GSE) {
        this.rna_GSE = rna_GSE;
    }

    public String getSampleID() {
        return sampleID;
    }

    public void setSampleID(String sampleID) {
        this.sampleID = sampleID;
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public String getBiosampleType() {
        return biosampleType;
    }

    public void setBiosampleType(String biosampleType) {
        this.biosampleType = biosampleType;
    }

    public String getTissueType() {
        return tissueType;
    }

    public void setTissueType(String tissueType) {
        this.tissueType = tissueType;
    }

    public String getBiosampleName() {
        return biosampleName;
    }

    public void setBiosampleName(String biosampleName) {
        this.biosampleName = biosampleName;
    }

    public String getIdenSignal() {
        return idenSignal;
    }

    public void setIdenSignal(String idenSignal) {
        this.idenSignal = idenSignal;
    }

    @Override
    public String toString() {
        return "BrowseTable{" +
                "sampleID='" + sampleID + '\'' +
                ", dataSource='" + dataSource + '\'' +
                ", biosampleType='" + biosampleType + '\'' +
                ", tissueType='" + tissueType + '\'' +
                ", biosampleName='" + biosampleName + '\'' +
                ", idenSignal='" + idenSignal + '\'' +
                ", pmid='" + pmid + '\'' +
                ", article='" + article + '\'' +
                ", journal='" + journal + '\'' +
                ", year='" + year + '\'' +
                ", sapiens='" + sapiens + '\'' +
                ", tissue='" + tissue + '\'' +
                ", disease='" + disease + '\'' +
                ", cell_Number='" + cell_Number + '\'' +
                ", cellType_Number='" + cellType_Number + '\'' +
                ", data_Type='" + data_Type + '\'' +
                ", rna_GSE='" + rna_GSE + '\'' +
                ", integrated='" + integrated + '\'' +
                ", status='" + status + '\'' +
                ", platform='" + platform + '\'' +
                ", orderid='" + orderid + '\'' +
                '}';
    }
}
