package com.lcq.cell.pojo;


public class BrowserDetailTable {

    private String id;
    private String chrome;
    private String start;
    private String end;
    private String size;
    private String signals;
    private String signalnum;
    private String logpvalue;
    private String sampleid;
    private String tissueType;
    private String biosampleName;
    private String interaction;
    private String methy450K;
    private String commonsnp;
    private String crisps;
    private String enhancer;
    private String eqtl;
    private String gwas;
    private String tad;
    private String hmm;
    private String orderid;

    public void setHmm(String hmm) {
        this.hmm = hmm;
    }

    public String getHmm() {
        return hmm;
    }

    public String getTissueType() {
        return tissueType;
    }

    public void setTissueType(String tissueType) {
        this.tissueType = tissueType;
    }

    public String getBiosampleName() {
        return biosampleName;
    }

    public void setBiosampleName(String biosampleName) {
        this.biosampleName = biosampleName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChrome() {
        return chrome;
    }

    public void setChrome(String chrome) {
        this.chrome = chrome;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getLogpvalue() {
        return logpvalue;
    }

    public void setLogpvalue(String logpvalue) {
        this.logpvalue = logpvalue;
    }

    public String getSampleid() {
        return sampleid;
    }

    public void setSampleid(String sampleid) {
        this.sampleid = sampleid;
    }

    public String getInteraction() {
        return interaction;
    }

    public void setInteraction(String interaction) {
        this.interaction = interaction;
    }

    public String getMethy450K() {
        return methy450K;
    }

    public void setMethy450K(String methy450K) {
        this.methy450K = methy450K;
    }

    public String getCommonsnp() {
        return commonsnp;
    }

    public void setCommonsnp(String commonsnp) {
        this.commonsnp = commonsnp;
    }

    public String getCrisps() {
        return crisps;
    }

    public void setCrisps(String crisps) {
        this.crisps = crisps;
    }

    public String getEnhancer() {
        return enhancer;
    }

    public void setEnhancer(String enhancer) {
        this.enhancer = enhancer;
    }

    public String getEqtl() {
        return eqtl;
    }

    public void setEqtl(String eqtl) {
        this.eqtl = eqtl;
    }

    public String getGwas() {
        return gwas;
    }

    public void setGwas(String gwas) {
        this.gwas = gwas;
    }

    public String getTad() {
        return tad;
    }

    public void setTad(String tad) {
        this.tad = tad;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getSignals() {
        return signals;
    }

    public void setSignals(String signals) {
        this.signals = signals;
    }

    public String getSignalnum() {
        return signalnum;
    }

    public void setSignalnum(String signalnum) {
        this.signalnum = signalnum;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    @Override
    public String toString() {
        return "BrowserDetailTable{" +
                "id='" + id + '\'' +
                ", chrome='" + chrome + '\'' +
                ", start='" + start + '\'' +
                ", end='" + end + '\'' +
                ", size='" + size + '\'' +
                ", signals='" + signals + '\'' +
                ", signalnum='" + signalnum + '\'' +
                ", logpvalue='" + logpvalue + '\'' +
                ", sampleid='" + sampleid + '\'' +
                ", tissueType='" + tissueType + '\'' +
                ", biosampleName='" + biosampleName + '\'' +
                ", interaction='" + interaction + '\'' +
                ", methy450K='" + methy450K + '\'' +
                ", commonsnp='" + commonsnp + '\'' +
                ", crisps='" + crisps + '\'' +
                ", enhancer='" + enhancer + '\'' +
                ", eqtl='" + eqtl + '\'' +
                ", gwas='" + gwas + '\'' +
                ", tad='" + tad + '\'' +
                ", hmm='" + hmm + '\'' +
                ", orderid='" + orderid + '\'' +
                '}';
    }
}
