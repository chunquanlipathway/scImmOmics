package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author
 */
@Data
public class CellChatInfo implements Serializable{
    private String source;
    private String target;
    private String ligand;
    private String receptor;
    private String prob;
    private String pval;
    private String interaction_name;
    private String interaction_name_2;
    private String pathway_name;
    private String annotation;
    private String evidence;

    private static final long serialVersionUID = 1L;
}
