package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class Cicero {
    private String peak1;
    private String peak1gene;
    private String peak2;
    private String peak2gene;
    private String coaccess;
}
