package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class SampleTable implements Serializable {
    private String barcode;

    private String x;

    private String y;

    private String celltype;
    private String sampleinfo;
    private String otherinfo;
    private String tissueType;

    private static final long serialVersionUID = 1L;
}