package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class Cytokine implements Serializable {
    private String family;
    private String cytokine;
    private String indexid;
    private String sampleid;
    private String tissue;
    private String sapiens;


    private static final long serialVersionUID = 1L;
}