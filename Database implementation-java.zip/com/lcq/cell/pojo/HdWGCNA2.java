package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author
 */
@Data
public class HdWGCNA2 implements Serializable{
    private String gene1;
    private String gene2;
    private String score;

    private static final long serialVersionUID = 1L;
}
