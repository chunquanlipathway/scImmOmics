package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class SampleUmap implements Serializable {
    private String x;
    private String y;
    private String celltype;
    private String disease_status;
    private static final long serialVersionUID = 1L;
}