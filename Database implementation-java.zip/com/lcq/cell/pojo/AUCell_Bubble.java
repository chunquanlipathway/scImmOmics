package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class AUCell_Bubble implements Serializable {
    private String family;
    private String cytokine;
    private String celltype2;
    private String aucell_mean;
    private String celltype2_DiffValue;

    private static final long serialVersionUID = 1L;
}