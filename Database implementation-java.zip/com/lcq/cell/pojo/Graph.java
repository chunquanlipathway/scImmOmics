package com.lcq.cell.pojo;

import lombok.Data;
import sun.awt.image.ImageWatched;

import java.io.Serializable;
import java.util.List;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class Graph implements Serializable {
    private List<Nodes> nodes;
    private List<Links> links;
    private List<Categories> categories;

    private static final long serialVersionUID = 1L;
}