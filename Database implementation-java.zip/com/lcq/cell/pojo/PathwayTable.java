package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class PathwayTable {
    private String f_sample_id;
    private String f_level;
    private String f_cluster;
    private String f_description;
    private String f_gene_ratio;
    private String f_p_value;
    private String f_p_adjust;
    private String f_q_value;
    private String f_count;
}
