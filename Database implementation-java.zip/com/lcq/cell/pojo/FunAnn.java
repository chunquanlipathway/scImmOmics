package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class FunAnn implements Serializable {
    private String pathway;
    private String cluster;
    private String ID;
    private String Description;
    private String GeneRatio;
    private String BgRatio;
    private String pvalue;
    private String padjust;
    private String qvalue;
    private String geneID;
    private String Count;

    private static final long serialVersionUID = 1L;
}