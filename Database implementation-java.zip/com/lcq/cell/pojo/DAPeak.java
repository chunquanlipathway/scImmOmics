package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class DAPeak {
    private String chr;
    private String startposi;
    private String endposi;
    private String pvalue;
    private String log2fc;
    private String pct1;
    private String pct2;
    private String adjust;
    private String fdr;
    private String cluster;
    private String gene;
    private String peak0;
    private String sample;
    private String sampleid;
}
