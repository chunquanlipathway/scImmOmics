package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class EnrichmentResult {
    private String sample;
    private String sapiens;
    private String tissue;
    private String disease;
    private String status;
    private String pmid;
    private String article;
    private String journal;
    private String year;
    private String source;
    private String platform;
    private String integrated_Type;
    private String celltype2;
    private String genes;
    private String pvalue;
    private String padjust;
}