package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class Edge implements Serializable {
    private String source;
    private String target;
    private String width;
    private LineStyle lineStyle;

    private static final long serialVersionUID = 1L;
}