package com.lcq.cell.pojo;

public class BrowserParam {
    private String idenSignalParam;
    private String dataSourceParam;
    private String biosampleTypeParam;
    private String tissueTypeParam;
    private String biosampleNameParam;

    public BrowserParam(String idenSignalParam, String dataSourceParam, String biosampleTypeParam, String tissueTypeParam, String biosampleNameParam) {
        this.idenSignalParam = idenSignalParam;
        this.dataSourceParam = dataSourceParam;
        this.biosampleTypeParam = biosampleTypeParam;
        this.tissueTypeParam = tissueTypeParam;
        this.biosampleNameParam = biosampleNameParam;
    }

    public BrowserParam(String biosampleTypeParam, String tissueTypeParam) {
    }

    public String getIdenSignalParam() {
        return idenSignalParam;
    }

    public void setIdenSignalParam(String idenSignalParam) {
        this.idenSignalParam = idenSignalParam;
    }

    public String getDataSourceParam() {
        return dataSourceParam;
    }

    public void setDataSourceParam(String dataSourceParam) {
        this.dataSourceParam = dataSourceParam;
    }

    public String getBiosampleTypeParam() {
        return biosampleTypeParam;
    }

    public void setBiosampleTypeParam(String biosampleTypeParam) {
        this.biosampleTypeParam = biosampleTypeParam;
    }

    public String getTissueTypeParam() {
        return tissueTypeParam;
    }

    public void setTissueTypeParam(String tissueTypeParam) {
        this.tissueTypeParam = tissueTypeParam;
    }

    public String getBiosampleNameParam() {
        return biosampleNameParam;
    }

    public void setBiosampleNameParam(String biosampleNameParam) {
        this.biosampleNameParam = biosampleNameParam;
    }

    @Override
    public String toString() {
        return "BrowserParam{" +
                "idenSignalParam='" + idenSignalParam + '\'' +
                ", dataSourceParam='" + dataSourceParam + '\'' +
                ", biosampleTypeParam='" + biosampleTypeParam + '\'' +
                ", tissueTypeParam='" + tissueTypeParam + '\'' +
                ", biosampleNameParam='" + biosampleNameParam + '\'' +
                '}';
    }
}
