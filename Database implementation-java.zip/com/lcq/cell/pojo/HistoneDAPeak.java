package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class HistoneDAPeak {
    private String peak;
    private String p_value;
    private String avg_log2fc;
    private String pct1;
    private String pct2;
    private String p_value_adj;
    private String celltype;
}
