package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class AUCell implements Serializable {
    private String id;
    private String index;
    private String axis;
    private String axis_x;
    private String axis_y;
    private String sampleinfo;
    private String sampleinfo2;
    private String celltype;
    private String celltype2;
    private String gsm;
    private String tissue;
    private String disease_status;
    private String pseudotime;
    private String family;
    private String cytokine;
    private String set_celltype;
    private String aucell;

    private static final long serialVersionUID = 1L;
}