package com.lcq.cell.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * all_bar_umap_cluster
 * @author 
 */
@Data
public class Node implements Serializable {
    private String id;
    private String name;
    private String symbolSize;
    private String category;
    private String value;
    private static final long serialVersionUID = 1L;
}