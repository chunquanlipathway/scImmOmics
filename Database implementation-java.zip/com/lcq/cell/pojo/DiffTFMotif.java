package com.lcq.cell.pojo;

import lombok.Data;

@Data
public class DiffTFMotif {
    private String feature;
    private String cluster;
    private String mean1;
    private String mean2;
    private String pv;
    private String pv_adjust;
}
