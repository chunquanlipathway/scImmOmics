package com.lcq.cell.pojo;

public class CelltypeCellNum {
    private String celltype;
    private String clusterAllCellNum;
    private String clusterColonCellNum;

    public String getCelltype() {
        return celltype;
    }

    public void setCelltype(String celltype) {
        this.celltype = celltype;
    }

    public String getClusterAllCellNum() {
        return clusterAllCellNum;
    }

    public void setClusterAllCellNum(String clusterAllCellNum) {
        this.clusterAllCellNum = clusterAllCellNum;
    }

    public String getClusterColonCellNum() {
        return clusterColonCellNum;
    }

    public void setClusterColonCellNum(String clusterColonCellNum) {
        this.clusterColonCellNum = clusterColonCellNum;
    }

    @Override
    public String toString() {
        return "CelltypeCellNum{" +
                "celltype='" + celltype + '\'' +
                ", clusterAllCellNum='" + clusterAllCellNum + '\'' +
                ", clusterColonCellNum='" + clusterColonCellNum + '\'' +
                '}';
    }
}
