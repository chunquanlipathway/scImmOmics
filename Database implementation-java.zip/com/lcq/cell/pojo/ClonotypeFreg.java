package com.lcq.cell.pojo;

public class ClonotypeFreg {
    private String celltype;
    private String clonotype;
    private String clusterClonoTypeFreg;

    public String getCelltype() {
        return celltype;
    }

    public void setCelltype(String celltype) {
        this.celltype = celltype;
    }

    public String getClonotype() {
        return clonotype;
    }

    public void setClonotype(String clonotype) {
        this.clonotype = clonotype;
    }

    public String getClusterClonoTypeFreg() {
        return clusterClonoTypeFreg;
    }

    public void setClusterClonoTypeFreg(String clusterClonoTypeFreg) {
        this.clusterClonoTypeFreg = clusterClonoTypeFreg;
    }

    @Override
    public String toString() {
        return "ClonotypeFreg{" +
                "celltype='" + celltype + '\'' +
                ", clonotype='" + clonotype + '\'' +
                ", clusterClonoTypeFreg='" + clusterClonoTypeFreg + '\'' +
                '}';
    }
}
