package com.lcq.cell.until;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.pojo.PageTab;
import com.lcq.cell.pojo.Readfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShellUtil {
    @Autowired(required = false)
    /**
     *
     * @param fileName 文件全路径
     * @param start  页数
     * @param length  每页的条数
     * @return
     */
    public static PageTab getsubtractLines(String fileName, int start, int length, Integer draw){
        PageTab tabs = new PageTab();
        Page<Readfile> list = new Page<>();
        PageHelper.startPage(start / length + 1, length);
        File file = new File(fileName);
        BufferedReader reader = null;
        Readfile filerow = null;
        try {
            int startRow = start + 1;  //计算开始行数
            int endRow = start + length; //计算结束行数
            reader = new BufferedReader(new FileReader(file));
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));
            lineNumberReader.skip(Long.MAX_VALUE);
            int lineNumber = lineNumberReader.getLineNumber() + 1;   //获取文件里面的总行数
            if(endRow >= lineNumber){
                endRow = lineNumber;
            }
            String tempString = "";
            int line = 0;
            // 一次读入一行，直到读入null为文件结束
            while (tempString != null) {
                line++;
                tempString = reader.readLine();
                if(line >= startRow && line <= endRow) {
                    String arr[] = tempString.split("\t");
                    filerow = new Readfile();
                    filerow.setC1(arr[0]);
                    filerow.setC2(arr[1]);
                    filerow.setC3(arr[2]);
                    filerow.setC4(arr[3]);
                    filerow.setC5(arr[4]);//int(-10*log10qvalue)
                    filerow.setC6(arr[6]);//fold change
                    filerow.setC7(arr[7]);//-log10pvalue

                    list.add(filerow);
                }
            }
            reader.close();
            tabs.setData(list.getResult());
            tabs.setRecordsTotal(lineNumber);
            tabs.setRecordsFiltered(lineNumber);
            tabs.setDraw(draw);
            return tabs;
        } catch (IOException e) {
            System.out.println(e);
            tabs.setData(new Page());
            tabs.setRecordsTotal(0);
            tabs.setRecordsFiltered(0);
            tabs.setDraw(draw);
            return tabs;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static PageTab getASWResult(String fileName, int start, int length, Integer draw){
        PageTab tabs = new PageTab();
        Page<Readfile> list = new Page<>();
        PageHelper.startPage(start / length + 1, length);
        File file = new File(fileName);
        BufferedReader reader = null;
        Readfile filerow = null;
        try {
            int startRow = start + 1;  //计算开始行数
            int endRow = start + length; //计算结束行数
            reader = new BufferedReader(new FileReader(file));
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));
            lineNumberReader.skip(Long.MAX_VALUE);
            int lineNumber = lineNumberReader.getLineNumber() + 1;   //获取文件里面的总行数
            System.out.println(lineNumber);
            System.out.println(endRow);

            if(endRow >= lineNumber){
                endRow = lineNumber-1;
            }
            String tempString = "";
            int line = 0;
            // 一次读入一行，直到读入null为文件结束
            while (tempString != null) {
                line++;
                tempString = reader.readLine();
                if(line >= startRow && line <= endRow) {
                    String arr[] = tempString.split(" ");
                    if (!arr[0].equals("chr")){
                        filerow = new Readfile();
                        filerow.setC1(arr[0]);
                        filerow.setC2(arr[1]);
                        filerow.setC3(arr[2]);
                        filerow.setC4(arr[3]);
                        filerow.setC5(arr[4]);
                        filerow.setC6(arr[5]);
                        list.add(filerow);
                    }
                }
            }
            reader.close();
            tabs.setData(list.getResult());
            tabs.setRecordsTotal(lineNumber);
            tabs.setRecordsFiltered(lineNumber);
            tabs.setDraw(draw);
            return tabs;
        } catch (IOException e) {
            System.out.println(e);
            tabs.setData(new Page());
            tabs.setRecordsTotal(0);
            tabs.setRecordsFiltered(0);
            tabs.setDraw(draw);
            return tabs;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static Map getLoLaLines(String fileName, int start, int length, Integer draw){
        Map map = new HashMap();
        List<Readfile> list = new ArrayList<>();
        File file = new File(fileName);
        BufferedReader reader = null;
        Readfile filerow = null;
        try {
            int startRow = start + 1;  //计算开始行数
            int endRow = start + length; //计算结束行数
            reader = new BufferedReader(new FileReader(file));
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));
            lineNumberReader.skip(Long.MAX_VALUE);
            int lineNumber = lineNumberReader.getLineNumber() + 1;   //获取文件里面的总行数
            if(endRow >= lineNumber){
                endRow = lineNumber;
            }
            String tempString = "";
            String sampleid = "";
            int line = 0;
            // 一次读入一行，直到读入null为文件结束
            while (tempString != null) {
                line++;
                tempString = reader.readLine();
                if(line >= startRow && line <= endRow) {
                    String arr[] = tempString.split("\t");

                    filerow = new Readfile();
                    if (!arr[0].equals("userSet")){
                        filerow.setC1(arr[2]);
                        filerow.setC2(arr[3]);
                        filerow.setC3(arr[4]);
                        sampleid = arr[20].substring(7,14);
                        filerow.setC4(sampleid);
                        filerow.setC5(arr[5]);
                        filerow.setC6(arr[21]);
                        list.add(filerow);
                    }
                }
            }
            reader.close();
            map.put("lineNumber",lineNumber);
            map.put("list",list);
            return map;
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return map;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static PageTab getLines(String fileName, int start, int length, Integer draw){
        PageTab tabs = new PageTab();
        Page<Readfile> list = new Page<>();
        PageHelper.startPage(start / length + 1, length);
        File file = new File(fileName);
        BufferedReader reader = null;
        Readfile filerow = null;
        try {
            int startRow = start + 1;  //计算开始行数
            int endRow = start + length; //计算结束行数
            reader = new BufferedReader(new FileReader(file));
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));
            lineNumberReader.skip(Long.MAX_VALUE);
            int lineNumber = lineNumberReader.getLineNumber() + 1;   //获取文件里面的总行数
            if(endRow >= lineNumber){
                endRow = lineNumber;
            }
            String tempString = "";
            int line = 0;
            // 一次读入一行，直到读入null为文件结束
            while (tempString != null) {
                line++;
                tempString = reader.readLine();
                if(line >= startRow && line <= endRow) {
                    String arr[] = tempString.split("\t");

                    filerow = new Readfile();
                    filerow.setC1(arr[0]);
                    filerow.setC2(arr[1]);
                    filerow.setC3(arr[2]);
                    filerow.setC4(arr[3]);
                    filerow.setC5(arr[10]);
                    filerow.setC6(arr[11]);
                    filerow.setC7(arr[12]);
                    filerow.setC8(arr[13]);
                    filerow.setC9(arr[14]);
                    filerow.setC10(arr[21]);
                    list.add(filerow);
                }
            }
            reader.close();
            tabs.setData(list.getResult());
            tabs.setRecordsTotal(lineNumber);
            tabs.setRecordsFiltered(lineNumber);
            tabs.setDraw(draw);
            return tabs;
        } catch (IOException e) {
            System.out.println(e);
            tabs.setData(new Page());
            tabs.setRecordsTotal(0);
            tabs.setRecordsFiltered(0);
            tabs.setDraw(draw);
            return tabs;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String getHeatLines(String fileName,String gene){
        File file = new File(fileName);
        BufferedReader reader = null;
        Readfile filerow = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = "";
            int line = 0;
            // 一次读入一行，直到读入null为文件结束
            while (tempString != null) {
                line++;
                tempString = reader.readLine();
//                list.add(tempString);
                if (tempString != null){
                    if (!tempString.equals("V1")){
                        String[] arr = tempString.split("\t");
                        if (gene==""){
                            return arr[1];
                        }
                        if (arr[0].equals(gene)){
                            return arr[1];
                        }
                    }
                }
            }
            reader.close();
            return "";
        } catch (IOException e) {
            System.out.println(e);
            return "";
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String fileUpload(MultipartFile file,String path,String fileName) {
        if (file.isEmpty()) {
            return "false";
        }
        File dest = new File(new File(path).getAbsolutePath()+ "/" + fileName);
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        try {
            file.transferTo(dest); // 保存文件
            return "true";
        } catch (Exception e) {
            e.printStackTrace();
            return "false";
        }
    }

    //创建shell
    public static void createInputFile(String path, String... strs) throws Exception {

        if (strs == null) {
            System.out.println("strs is null");
            return;
        }

        File sh = new File(path);
        if (sh.exists()) {
            sh.delete();
        }

        sh.createNewFile();
        sh.setExecutable(true);
        FileWriter fw = new FileWriter(sh);
        BufferedWriter bf = new BufferedWriter(fw);

        for (int i = 0; i < strs.length; i++) {
            bf.write(strs[i]);

            if (i < strs.length - 1) {
                bf.newLine();
            }
        }
        bf.flush();
        bf.close();
    }
    public static void createInputFile2(String path, List<String> strs) throws Exception {

        if (strs == null) {
            System.out.println("strs is null");
            return;
        }

        File sh = new File(path);
        if (sh.exists()) {
            sh.delete();
        }

        sh.createNewFile();
        sh.setExecutable(true);
        FileWriter fw = new FileWriter(sh);
        BufferedWriter bf = new BufferedWriter(fw);

        for (int i = 0; i < strs.size(); i++) {
            bf.write(strs.get(i));

            if (i < strs.size() - 1) {
                bf.newLine();
            }
        }
        bf.flush();
        bf.close();
    }

    public static void createFloder(String path) throws Exception {
        File file=new File(path);
        if(!file.exists()){//如果文件夹不存在
            file.mkdir();//创建文件夹
        }
    }

    //执行shell
    public static String runShell(String shpath) throws Exception {

        if (shpath == null || shpath.equals("")) {
            return "shpath is empty";
        }
        Process ps = Runtime.getRuntime().exec(shpath);
        int exitVal = ps.waitFor();
        System.out.println("this is exitVal:"+exitVal);
        BufferedReader br = new BufferedReader(new InputStreamReader(ps.getInputStream()));
        StringBuffer sb = new StringBuffer();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append("\n");
        }
        String result = sb.toString();
        System.out.println(result);
        return result;
    }

    //执行shell
    public static String rundifferentShell(String shpath) throws Exception {

        if (shpath == null || shpath.equals("")) {
            return "shpath is empty";
        }
        try{
            Process ps = Runtime.getRuntime().exec(new String[]{"/bin/sh", "-c",shpath});
            int exitVal = ps.waitFor();
            System.out.println(exitVal == 0 ? "success" : "fail");

            return "result";
        }catch (Exception e){
            System.out.println(e.getMessage());
            return "";
        }
    }

}