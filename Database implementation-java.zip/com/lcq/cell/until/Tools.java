package com.lcq.cell.until;

import com.lcq.cell.pojo.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Tools {
    private Double r1 = 50.0;
    private Double r2 = 100.0;
    private Double r3 = 120.0;
    private Double r4 = 170.0;
    private Double minc = -r2;
    private Double maxc = r2;
    private Double minb = -r4;
    private Double maxb = r4;

    public void DownloadTool(String t, HttpServletResponse response){

        BufferedOutputStream buff = null;
        ServletOutputStream out = null;
        FileInputStream in = null;

        try {
            //自动判断下载文件类型
            response.setContentType("multipart/form-data");
            System.out.println(t);
            //设置文件头：最后一个参数是设置下载文件名
            response.setHeader("Content-Disposition", "attachment;fileName="+"hello.txt");
            out = response.getOutputStream();
            buff = new BufferedOutputStream(out);
            buff.write(t.getBytes("UTF-8"));
            buff.flush();
            buff.close();
        } catch (Exception e) {
        } finally {
            try {
                buff.close();
                out.close();
            } catch (NullPointerException e) {
            } catch (Exception e) {
            }
        }
    }

    public String Fileunload(MultipartFile file,String inputpath,String inputfilename) throws IOException {
        /*文件上传*/
        File newfile = File.createTempFile("input", ".txt");
        // MultipartFile to File
        file.transferTo(newfile);
        //你的业务逻辑
        InputStreamReader isr = new InputStreamReader(new FileInputStream(newfile), "utf-8");
        BufferedReader br = new BufferedReader(isr);
        String lineTxt = null;
        int sum = 1;

        while ((lineTxt = br.readLine()) != null) {
            System.out.println(lineTxt);
            if (sum>5)break;
            if (lineTxt.split("\t").length<3)
                throw new NullPointerException("输入数据格式有误");
            sum++;
        }
        br.close();

        return "success";
        /*文件上传*/
    }

    public String[] readInputRegion(String region) throws IOException {
        if (region!=null){
            region = region.replace(" ","\t");
            String arr[] = region.split("\\r?\\n");
            if(arr.length<=0)
                throw new NullPointerException("输入数据为null");
            if (arr[0].split("\t").length<3)
                throw new NullPointerException("输入数据格式有误");
            /*判断输入数据格式是否有问题，无问题则返回数据*/
            return arr;
        }else {
            throw new NullPointerException("输入数据为null");
        }
        /*文件上传*/
    }

    public List<Readfile> readInputFile(MultipartFile file) throws IOException {
        List<Readfile> list = new ArrayList<>();
        /*文件上传*/
        File newfile = File.createTempFile("file", ".txt");
        // MultipartFile to File
        file.transferTo(newfile);
        //你的业务逻辑
        InputStreamReader isr = new InputStreamReader(new FileInputStream(newfile), "utf-8");
        BufferedReader br = new BufferedReader(isr);
        String lineTxt = null;
        Readfile peakFile = null;
        while ((lineTxt = br.readLine()) != null) {
            System.out.println(lineTxt);
            list.add(peakFile);
        }
        br.close();
        return list;
        /*文件上传*/
    }




    public Map getStrandPeakByPeak(String peak){
        Map map = new HashMap();
        String[] chrAndcoor = peak.split(":");
        String[] coor = chrAndcoor[1].split("-");
        String chrome = chrAndcoor[0];
        String start = coor[0];
        String end = coor[1];
        map.put("chrome",chrome);
        map.put("start",start);
        map.put("end",end);
        return map;
    }

    public List<String> getroseGeneName(String genes){
        List<String> list = new ArrayList<>();
        if (genes!=null) {
            String[] genearr = genes.split(",");
            list = Arrays.asList(genearr);
        }
        return list;
    }

    public List<String> getotherdbSource(List<String> genes){
        List<String> list = new ArrayList<>();
        if (!genes.isEmpty()) {
            for (int i = 0; i < genes.size(); i++) {
                String[] genearr = genes.get(i).split(",");
                list.addAll(Arrays.asList(genearr));
            }
        }
        return list;
    }

    public List<String> gethancerSource(List<String> genes){
        List<String> list = new ArrayList<>();
        if (!genes.isEmpty()) {
            for (int i = 0; i < genes.size(); i++) {
                if (!genes.get(i).equals("NA")) {
                    list.addAll(Arrays.asList(genes.get(i).split(",")));
                }
            }
        }
        return list;
    }
}
