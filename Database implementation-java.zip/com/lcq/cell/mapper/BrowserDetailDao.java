package com.lcq.cell.mapper;

import com.github.pagehelper.Page;
import com.lcq.cell.pojo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BrowserDetailDao {
    @Select({
            "<script>",
            "SELECT id AS c1,SampleInfo2 AS c2,SampleInfo AS c3,CellType2 AS c4,GSM AS c5,V_gene AS c6,D_gene AS c7,J_gene AS c8,C_gene AS c9,cdr3 AS c10,cdr3_nt AS c11 FROM ${table} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (id LIKE CONCAT('%',#{searchValue},'%') or SampleInfo2 LIKE CONCAT('%',#{searchValue},'%') or SampleInfo LIKE CONCAT('%',#{searchValue},'%') or CellType2 LIKE CONCAT('%',#{searchValue},'%') or V_gene LIKE CONCAT('%',#{searchValue},'%') or cdr3 LIKE CONCAT('%',#{searchValue},'%') or cdr3_nt LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by id ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by SampleInfo2 ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by SampleInfo ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by CellType2 ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by GSM ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by V_gene ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by D_gene ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by J_gene ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by cdr3 ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by cdr3_nt ${dir}",
            " </when> ",
            "</script>"
    })
    Page<Readfile> getCdr3Table(String table, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "select majorCluster as name, GROUP_CONCAT(${diversityOptions}) as value FROM ${table} GROUP BY majorCluster",
            "</script>"
    })
    List<NameValue> diversityImgData(String table,String diversityOptions);

    @Select({
            "<script>",
            "SELECT * FROM browseTable WHERE idenSignal=#{gse} limit 1",
            "</script>"
    })
    BrowseTable sampleinfo(String gse);

    @Select({
            "<script>",
            "SELECT DISTINCT Disease_Status FROM ${table}",
            "</script>"
    })
    List<String> getDiseaseBySampleID(String table);

    @Select({
            "<script>",
            "SELECT samplename FROM TRUST4_sample WHERE samplename=#{gse}",
            "</script>"
    })
    String determineTRUST4(String gse);

    @Select({
            "<script>",
            "SELECT DISTINCT biosampleType FROM browseTable WHERE idenSignal=#{gse} limit 1",
            "</script>"
    })
    String getIntegratedType(String gse);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType_A AS id, cellType_A AS name, (ClonoType_A/ClonoType_NUM)*200 AS symbolSize, CellType_A AS category FROM ${table} WHERE sampleInfo=#{gsm}",
            "</script>"
    })
    List<Node> celltypeForceNode(String table,String gsm);

    @Select({
            "<script>",
            "SELECT cellType2 AS c1, MAX(TRIM(clusterAllCellNum)) AS c2,MAX(TRIM(clusterColonCellNum)) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} GROUP BY cellType2",
            "</script>"
    })
    List<Readfile> clonoBulkBarFreg(String table,String gsm);

    @Select({
            "<script>",
            "SELECT cellType2 AS c1, MAX(TRIM(clusterAllCellNum)) AS c2,MAX(TRIM(clusterColonCellNum)) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} GROUP BY cellType2",
            "</script>"
    })
    List<Readfile> TRUST4clonoBulkBarFreg(String table,String gsm);

    @Select({
            "<script>",
            "SELECT cellType AS c1, MAX(clusterAllCellNum_BCR) AS c2,MAX(clusterColonCellNum_BCR) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} GROUP BY cellType",
            "</script>"
    })
    List<Readfile> bcrBulkBarFreg(String table,String gsm);

    @Select({
            "<script>",
            "SELECT CellType_A AS source, CellType_B AS target, ClonoType_co/10 AS width FROM ${table} WHERE sampleInfo=#{gsm}",
            "</script>"
    })
    List<Edge> celltypeForceEdge(String table,String gsm);

    @Select({
            "<script>",
            "SELECT count(cellType) AS value, cellType AS name FROM ${table} group by cellType",
            "</script>"
    })
    List<NameValue> getCellTypeStatus(String table);
    @Select({
            "<script>",
            "SELECT count(otherInfo) AS value, otherInfo AS name FROM ${table} group by otherInfo",
            "</script>"
    })
    List<NameValue> getOtherInfoStatus(String table);

    @Select({
            "<script>",
            "SELECT cellType FROM ${table} WHERE sampleInfo2=#{gsm}",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion1(String table,String gsm);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType2 as celltype, TRIM(clusterAllCellNum) as clusterAllCellNum, TRIM(clusterColonCellNum) as clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm}",
            "</script>"
    })
    List<CelltypeCellNum> getBarByGSM(String table,String gsm);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType2 as celltype, TRIM(clusterAllCellNum) as clusterAllCellNum, TRIM(clusterColonCellNum) as clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm}",
            "</script>"
    })
    List<CelltypeCellNum> TRUST4getBarByGSM(String table,String gsm);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType2 as cellType, clusterAllCellNum_BCR AS clusterAllCellNum, TRIM(clusterColonCellNum_BCR) AS clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm}",
            "</script>"
    })
    List<CelltypeCellNum> bcrclusterCellNum(String table,String gsm);

    @Select({
            "<script>",
            "SELECT cellColonNum FROM ${table}",
            "</script>"
    })
    List<String> getClonoCellNum(String table);

    @Select({
            "<script>",
            "SELECT cellColonNum FROM ${table}",
            "</script>"
    })
    List<String> TRUST4getClonoCellNum(String table);

    @Select({
            "<script>",
            "SELECT cellColonNum_BCR FROM ${table}",
            "</script>"
    })
    List<String> getBcrCellNum(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType2 as celltype, clonotype, clusterColonTypeFreg AS clusterClonoTypeFreg FROM ${table} WHERE sampleInfo=#{gsm} AND clonoType = #{clono}",
            "</script>"
    })
    List<ClonotypeFreg> getClonoBarByGSM(String table,String gsm,String clono);

    @Select({
            "<script>",
            "SELECT MeanExp FROM ${table} WHERE sampleInfo2=#{gsm} ",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion2(String table,String gsm);
    @Select({
            "<script>",
            "SELECT DISTINCT biosampleName FROM browseTable WHERE idenSignal=#{sample}",
            "</script>"
    })
    List<String> getCellTypeBysample(String sample);

    @Select({
            "<script>",
            "SELECT DISTINCT celltype2 FROM ${table}",
            "</script>"
    })
    List<String> getCellTypesBysample(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT clonotype FROM ${table} where sampleInfo=#{gsm}",
            "</script>"
    })
    List<String> getClonoTypeByGSM(String table, String gsm);
    @Select({
            "<script>",
            "SELECT DISTINCT clonotype FROM ${table} where sampleInfo=#{gsm}",
            "</script>"
    })
    List<String> getbcrClonoTypeByGSM(String table, String gsm);
    @Select({
            "<script>",
            "SELECT DISTINCT sampleinfo FROM ${table} where sampleInfo2=#{gsm}",
            "</script>"
    })
    String getbcrClonoTypeSampleInfoByGSM(String table, String gsm);

    @Select({
            "<script>",
            "SELECT CellType2 AS name, round(counts/ total * 100, 2 ) AS value FROM (SELECT CellType2, count(CellType2) as counts FROM ${table} group by CellType2) AS t1 LEFT JOIN (SELECT COUNT(CellType2) AS total FROM ${table}) AS t2 ON 1=1",
            "</script>"
    })
    List<NameValue> getCellTypeAndFregBysample(String table);

    @Select({
            "<script>",
            "SELECT `Axis.x` as x, `Axis.y` as y, CellType2 as celltype,disease_status FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getSample(String table);

    @Select({
            "<script>",
            "SELECT `Axis.x` as x, `Axis.y` as y, CellType2 as celltype,disease_status FROM ${table} WHERE 1=1",
            " <when test='chosenCelltype !=\"ALL\"'> ",
            " AND celltype = #{chosenCelltype}",
            " </when> ",
            " <when test='disease_status !=\"ALL\"'> ",
            " AND disease_status = #{disease_status}",
            " </when> ",
            "</script>"
    })
    List<SampleUmap> getSampleByCelltypeAndDisease(String table,String chosenCelltype,String disease_status);

    @Select({
            "<script>",
            "SELECT UMAP1_X as x, UMAP1_Y as y, CellType2, disease_status as celltype FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getSample_ATAC(String table);

    @Select({
            "<script>",
            "SELECT `Axis.x` as x, `Axis.y` as y, PseudoTime as celltype FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getPseudoData(String table);


    @Select({
            "<script>",
            "SELECT `Axis.x` as x, `Axis.y` as y, ${method} as celltype FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getCytoTRACE2Data(String table,String method);

    @Select({
            "<script>",
            "SELECT sampleInfo2 FROM ${table} group by sampleInfo2",
            "</script>"
    })
    List<String> getGSMBySample(String table);

    @Select({
            "<script>",
            "SELECT sampleInfo2 FROM ${table} group by sampleInfo2",
            "</script>"
    })
    List<String> TRUST4getGSMBySample(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType2 FROM ${table}",
            "</script>"
    })
    List<String> getCelltype_BCR(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT Description, Count, `p.adjust` as padjust FROM ${table} where pathway='GO' and cluster=#{cluster} and `p.adjust` &lt; ${padjustCut} order by `p.adjust` asc",
            "</script>"
    })
    List<FunAnn> getPathwayGo(String table,String cluster,String padjustCut);

    @Select({
            "<script>",
            "SELECT DISTINCT Description, Count, padjust FROM ${table} where celltype2=#{cluster} and padjust &lt; ${padjustCut} order by padjust asc",
            "</script>"
    })
    List<FunAnn> getPathwayHallmark(String table,String cluster,String padjustCut);

    @Select({
            "<script>",
            "SELECT DISTINCT Description, CAST(SUBSTRING_INDEX(GeneRatio, '/', 1) AS DECIMAL) / CAST(SUBSTRING_INDEX(GeneRatio, '/', -1) AS DECIMAL) AS GeneRatio, TRIM(Count) AS Count, pvalue FROM ${table} where pathway='Pathway' and cluster=#{cluster} and `p.adjust` &lt; ${padjustCut} order by pvalue asc",
            "</script>"
    })
    List<FunAnn> getPathwayKEGG(String table,String cluster,String padjustCut);

    @Select({
            "<script>",
            "SELECT DISTINCT Description, CAST(SUBSTRING_INDEX(GeneRatio, '/', 1) AS DECIMAL) / CAST(SUBSTRING_INDEX(GeneRatio, '/', -1) AS DECIMAL) AS GeneRatio, TRIM(Count) AS Count, pvalue FROM ${table} where cluster=#{cluster} and `p.adjust` &lt; ${padjustCut} order by pvalue asc",
            "</script>"
    })
    List<FunAnn> getPathwayImmSignature(String table,String cluster,String padjustCut);

    @Select({
            "<script>",
            "SELECT DISTINCT cluster FROM ${table}",
            "</script>"
    })
    List<String> getpathwaycelltype(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType2 as name, CellType2 as category FROM ${table}",
            "</script>"
    })
    List<Nodes> getCellChatNode(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType2 as name FROM ${table}",
            "</script>"
    })
    List<Categories> getCellChatCategorie(String table);

    @Select({
            "<script>",
            "SELECT CellType1 as source, CellType2 as target, Weight * 2 as width FROM ${table}",
            "</script>"
    })
    List<Links> getCellChatLink(String table);

    @Select({
            "<script>",
            "SELECT umap1,umap2,gene,module,color,hub,kme FROM ${sample} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (gene LIKE CONCAT('%',#{searchValue},'%') or color LIKE CONCAT('%',#{searchValue},'%') or module LIKE CONCAT('%',#{searchValue},'%') or hub LIKE CONCAT('%',#{searchValue},'%') or kME LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by umap1 ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by umap2 ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by gene ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by module ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by color ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by hub ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by kme ${dir}",
            " </when> ",
            "</script>"
    })
    Page<HdWGCNAumap> hdWGCNAumap(String sample, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT gene1,gene2,score FROM ${sample} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (gene1 LIKE CONCAT('%',#{searchValue},'%') or gene2 LIKE CONCAT('%',#{searchValue},'%') or score LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by gene1 ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by gene2 ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by score ${dir}",
            " </when> ",
            "</script>"
    })
    Page<HdWGCNA2> hdWGCNA2(String sample, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT * FROM ${sample} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (source LIKE CONCAT('%',#{searchValue},'%') or target LIKE CONCAT('%',#{searchValue},'%') or ligand LIKE CONCAT('%',#{searchValue},'%') or receptor LIKE CONCAT('%',#{searchValue},'%') or pathway_name LIKE CONCAT('%',#{searchValue},'%') or annotation LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by source ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by target ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by ligand ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by receptor ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by prob ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by pval ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by interaction_name ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by interaction_name_2 ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by pathway_name ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by annotation ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by evidence ${dir}",
            " </when> ",
            "</script>"
    })
    Page<CellChatInfo> cellChatInfo(String sample, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT genename as name FROM ${table}",
            "</script>"
    })
    List<Genename> getmarkerset(String table);

    @Select({
            "<script>",
            "SELECT p_val,avg_log2FC,`pct.1` as pct1,`pct.2` as pct2,p_val_adj,cluster,gene FROM ${sample} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (gene LIKE CONCAT('%',#{searchValue},'%') or p_val LIKE CONCAT('%',#{searchValue},'%') or avg_log2FC LIKE CONCAT('%',#{searchValue},'%') or `pct.1` LIKE CONCAT('%',#{searchValue},'%') or `pct.2` LIKE CONCAT('%',#{searchValue},'%') or p_val_adj LIKE CONCAT('%',#{searchValue},'%') or cluster LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by gene ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by p_val ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by avg_log2FC ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by `pct.1` ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by `pct.2` ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by p_val_adj ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by cluster ${dir}",
            " </when> ",
            "</script>"
    })
    Page<Deg> degTab(String sample, String searchValue, String order, String dir);
}