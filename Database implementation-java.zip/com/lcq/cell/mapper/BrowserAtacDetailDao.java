package com.lcq.cell.mapper;

import com.github.pagehelper.Page;
import com.lcq.cell.pojo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BrowserAtacDetailDao {

    @Select({
            "<script>",
            "SELECT UMAP1_X AS x, UMAP1_Y AS y, celltype2 as celltype FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getSample_atac(String table);

    @Select({
            "<script>",
            "SELECT cellType2 AS name, round(counts/ total * 100, 2 ) AS value FROM (SELECT celltype2, count(celltype2) as counts FROM ${table} group by celltype2) AS t1 LEFT JOIN (SELECT COUNT(cellType2) AS total FROM ${table}) AS t2 ON 1=1",
            "</script>"
    })
    List<NameValue> getCellTypeAndFregBysample_atac(String table);

    @Select({
            "<script>",
            "SELECT * FROM ${tablename} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (chr LIKE CONCAT('%',#{searchValue},'%') or startposi LIKE CONCAT('%',#{searchValue},'%') or endposi LIKE CONCAT('%',#{searchValue},'%') or pvalue LIKE CONCAT('%',#{searchValue},'%') or log2fc LIKE CONCAT('%',#{searchValue},'%') or pct1 LIKE CONCAT('%',#{searchValue},'%') or pct2 LIKE CONCAT('%',#{searchValue},'%') or adjust LIKE CONCAT('%',#{searchValue},'%') or fdr LIKE CONCAT('%',#{searchValue},'%') or cluster LIKE CONCAT('%',#{searchValue},'%') or gene LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by chr ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by startposi ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by endposi ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by pvalue ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by log2fc ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by pct1 ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by pct2 ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by adjust ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by fdr ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by cluster ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by gene ${dir}",
            " </when> ",
            "</script>"
    })
    Page<DAPeak> getDApeak(String tablename, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT * FROM ${tablename} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (coaccess LIKE CONCAT('%',#{searchValue},'%') or peak1 LIKE CONCAT('%',#{searchValue},'%') or peak2 LIKE CONCAT('%',#{searchValue},'%') or peak1gene LIKE CONCAT('%',#{searchValue},'%') or peak2gene LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by peak1 ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by peak1gene ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by peak2 ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by peak2gene ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by coaccess ${dir}",
            " </when> ",
            "</script>"
    })
    Page<Cicero> cicerotab(String tablename, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT * FROM ${tablename} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (feature LIKE CONCAT('%',#{searchValue},'%') or cluster LIKE CONCAT('%',#{searchValue},'%') or mean1 LIKE CONCAT('%',#{searchValue},'%') or mean2 LIKE CONCAT('%',#{searchValue},'%') or pv_adjust LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by feature ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by cluster ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by mean1 ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by mean2 ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by pv ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by pv_adjust ${dir}",
            " </when> ",
            "</script>"
    })
    Page<DiffTFMotif> getTFmotif(String tablename, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "Select Tissue as tissueType,GROUP_CONCAT(UMAP1_X) AS x,GROUP_CONCAT(UMAP1_Y) AS y from ${table} group by Tissue",
            "</script>"
    })
    List<SampleTable> getTissueTypePlot(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT cluster FROM ${sample}",
            "</script>"
    })
    List<String> getpathwaycelltype_atac(String sample);

    @Select({
            "<script>",
            "SELECT DISTINCT f_description, f_count, f_p_adjust FROM t_go where f_sample_id = #{sample} AND f_cluster=#{cluster} AND f_p_adjust &lt;= ${count} order by f_count desc",
            "</script>"
    })
    List<PathwayTable> getPathwayGo_atac(String sample,String cluster,String count);

    @Select({
            "<script>",
            "SELECT DISTINCT description as f_description, generatio as f_gene_ratio, trim(count) as f_count, pvalue as f_p_value FROM ${table} where pathway = 'Pathway' AND celltype2=#{cluster} AND padjust &lt;= ${padjust}",
            "</script>"
    })
    List<PathwayTable> getPathwayKEGG_atac(String table,String cluster,String padjust);

    @Select({
            "<script>",
            "SELECT * FROM ${tablename} WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (peak LIKE CONCAT('%',#{searchValue},'%') or p_value LIKE CONCAT('%',#{searchValue},'%') or avg_log2fc LIKE CONCAT('%',#{searchValue},'%') or pct1 LIKE CONCAT('%',#{searchValue},'%') or pct2 LIKE CONCAT('%',#{searchValue},'%') or p_value_adj LIKE CONCAT('%',#{searchValue},'%') or celltype LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by peak ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by p_value ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by avg_log2fc ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by pct1 ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by pct2 ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by p_value_adj ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by celltype ${dir}",
            " </when> ",
            "</script>"
    })
    Page<HistoneDAPeak> dapeakhistone(String tablename, String searchValue, String order, String dir);

}