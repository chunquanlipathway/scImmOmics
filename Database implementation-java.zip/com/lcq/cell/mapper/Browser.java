package com.lcq.cell.mapper;

import com.github.pagehelper.Page;
import com.lcq.cell.pojo.BrowseParamTotal;
import com.lcq.cell.pojo.BrowseTable;
import com.lcq.cell.pojo.BrowserParam;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface Browser {

    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,pmid,journal,article,`year`,platform,orderid FROM browseTable WHERE 1=1",
            " <when test='dataSource !=\"\"'> ",
            " AND disease = #{dataSource}",
            " </when> ",
            " <when test='biosampleType !=\"\"'> ",
            " AND biosampleType = #{biosampleType}",
            " </when> ",
            " <when test='tissueType !=\"\"'>",
            " AND tissueType = #{tissueType}",
            " </when> ",
            " <when test='biosampleName !=\"\"'>",
            " AND biosampleName = #{biosampleName}",
            " </when> ",
            " <when test='idenSignal !=\"\"'>",
            " AND sapiens = #{idenSignal}",
            " </when> ",
            " <when test='searchValue !=\"\"'>",
            " AND (disease LIKE CONCAT('%',#{searchValue},'%') or idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by platform ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by article ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by journal ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by year ${dir}",
            " </when> ",
            " <when test='order ==\"11\"'>",
            " order by pmid ${dir}",
            " </when> ",
            " <when test='order ==\"12\"'>",
            " order by orderid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getBrowseTable(String idenSignal, String dataSource, String biosampleType, String tissueType, String biosampleName, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT COUNT(sapiens) as sum , sapiens as name FROM browseTable WHERE 1=1",
            " <when test='dataSourceParam !=\"\"'> ",
            " AND disease = #{dataSourceParam}",
            " </when> ",
            " <when test='biosampleTypeParam !=\"\"'> ",
            " AND biosampleType = #{biosampleTypeParam}",
            " </when> ",
            " <when test='tissueTypeParam !=\"\"'>",
            " AND tissueType = #{tissueTypeParam}",
            " </when> ",
            " <when test='biosampleNameParam !=\"\"'>",
            " AND biosampleName = #{biosampleNameParam}",
            " </when> ",
            " <when test='idenSignalParam !=\"\"'>",
            " AND sapiens = #{idenSignalParam}",
            " </when> ",
            " GROUP BY sapiens",
            "</script>"
    })
    List<BrowseParamTotal> getIdenSignalParam(BrowserParam param);

    @Select({
            "<script>",
            "SELECT COUNT(disease) as sum , disease as name FROM browseTable WHERE 1=1",
            " <when test='dataSourceParam !=\"\"'> ",
            " AND disease = #{dataSourceParam}",
            " </when> ",
            " <when test='biosampleTypeParam !=\"\"'> ",
            " AND biosampleType = #{biosampleTypeParam}",
            " </when> ",
            " <when test='tissueTypeParam !=\"\"'>",
            " AND tissueType = #{tissueTypeParam}",
            " </when> ",
            " <when test='biosampleNameParam !=\"\"'>",
            " AND biosampleName = #{biosampleNameParam}",
            " </when> ",
            " <when test='idenSignalParam !=\"\"'>",
            " AND sapiens = #{idenSignalParam}",
            " </when> ",
            " GROUP BY disease",
            "</script>"
    })
    List<BrowseParamTotal> getDataSourceParam(BrowserParam param);

    @Select({
            "<script>",
            "SELECT COUNT(biosampleType) as sum , biosampleType as name FROM browseTable WHERE 1=1",
            " <when test='dataSourceParam !=\"\"'> ",
            " AND disease = #{dataSourceParam}",
            " </when> ",
            " <when test='biosampleTypeParam !=\"\"'> ",
            " AND biosampleType = #{biosampleTypeParam}",
            " </when> ",
            " <when test='tissueTypeParam !=\"\"'>",
            " AND tissueType = #{tissueTypeParam}",
            " </when> ",
            " <when test='biosampleNameParam !=\"\"'>",
            " AND biosampleName = #{biosampleNameParam}",
            " </when> ",
            " <when test='idenSignalParam !=\"\"'>",
            " AND sapiens = #{idenSignalParam}",
            " </when> ",
            " GROUP BY biosampleType",
            "</script>"
    })
    List<BrowseParamTotal> getBiosampleTypeParam(BrowserParam param);

    @Select({
            "<script>",
            "SELECT COUNT(tissueType) as sum , tissueType as name FROM browseTable WHERE 1=1",
            " <when test='dataSourceParam !=\"\"'> ",
            " AND disease = #{dataSourceParam}",
            " </when> ",
            " <when test='biosampleTypeParam !=\"\"'> ",
            " AND biosampleType = #{biosampleTypeParam}",
            " </when> ",
            " <when test='tissueTypeParam !=\"\"'>",
            " AND tissueType = #{tissueTypeParam}",
            " </when> ",
            " <when test='biosampleNameParam !=\"\"'>",
            " AND biosampleName = #{biosampleNameParam}",
            " </when> ",
            " <when test='idenSignalParam !=\"\"'>",
            " AND sapiens = #{idenSignalParam}",
            " </when> ",
            " GROUP BY tissueType",
            "</script>"
    })
    List<BrowseParamTotal> getTissueTypeParam(BrowserParam param);

    @Select({
            "<script>",
            "SELECT COUNT(biosampleName) as sum , biosampleName as name FROM browseTable WHERE 1=1",
            " <when test='dataSourceParam !=\"\"'> ",
            " AND disease = #{dataSourceParam}",
            " </when> ",
            " <when test='biosampleTypeParam !=\"\"'> ",
            " AND biosampleType = #{biosampleTypeParam}",
            " </when> ",
            " <when test='tissueTypeParam !=\"\"'>",
            " AND tissueType = #{tissueTypeParam}",
            " </when> ",
            " <when test='biosampleNameParam !=\"\"'>",
            " AND biosampleName = #{biosampleNameParam}",
            " </when> ",
            " <when test='idenSignalParam !=\"\"'>",
            " AND sapiens = #{idenSignalParam}",
            " </when> ",
            " GROUP BY biosampleName",
            "</script>"
    })
    List<BrowseParamTotal> getBiosampleNameParam(BrowserParam param);

}
