package com.lcq.cell.mapper;

import com.github.pagehelper.Page;
import com.lcq.cell.pojo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Mapper
public interface AnalysisDao {
    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,orderid FROM browseTable WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by orderid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getAllSampleInfo(String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,orderid FROM integrative_scRNA WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by orderid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getIntegrativeRNA(String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,orderid FROM integrative_scATAC WHERE 1=1",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by orderid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getIntegrativeATAC(String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT Family as family,GROUP_CONCAT(Cytokine SEPARATOR ',') as cytokine,indexid FROM Cytokine_Info GROUP BY Family,indexid ORDER BY indexid",
            "</script>"
    })
    List<Cytokine> getCytokineInfo();

    @Select({
            "<script>",
            "SELECT celltype2 as name,GROUP_CONCAT(aucell SEPARATOR ', ') AS value FROM ${table} GROUP BY celltype2",
            "</script>"
    })
    List<NameValue> getAuCellBoxBySampleAndCytokine(String table);

    @Select({
            "<script>",
            "SELECT family,cytokine,celltype2,aucell_mean*100 as celltype2_DiffValue,(case WHEN celltype2_DiffValue &lt; 1 THEN 1 WHEN celltype2_DiffValue BETWEEN 1 AND 1.5 THEN 2 WHEN celltype2_DiffValue &gt; 1.5 THEN 3 END) as aucell_mean FROM ${table}",
            "</script>"
    })
    List<AUCell_Bubble> bubbleAucellImg(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT idenSignal,pmid,article,journal,year,platform FROM browseTable WHERE idenSignal=#{sample}",
            "</script>"
    })
    BrowseTable sampletabGetSample(String sample);

    @Select({
            "<script>",
            "SELECT DISTINCT sapiens FROM browseTable",
            "</script>"
    })
    List<String> getSpiensAna();

    @Select({
            "<script>",
            "SELECT DISTINCT sapiens FROM AUCell_Info3 WHERE Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getSpiensAnaByCytokine(String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT tissueType FROM browseTable WHERE sapiens=#{sapien}",
            "</script>"
    })
    List<String> getTissueBySapien(String sapien);

    @Select({
            "<script>",
            "SELECT DISTINCT Tissue FROM AUCell_Info3 WHERE sapiens=#{sapien} and Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getTissueBySapienAndCytokine(String sapien, String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT Family FROM AUCell_Info3 WHERE SampleID=#{sample} and Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getFamilyBysampleAndCytokine(String sample, String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT Cytokine FROM AUCell_Info3 WHERE SampleID=#{sample} and Family=#{family} and Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getCytokineBysampleAndCytokine(String sample,String family, String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT Cytokine FROM AUCell_Info3 WHERE SampleID=#{sample} and Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getCytokineBySampleAndCytokine(String sample, String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT idenSignal FROM browseTable WHERE sapiens=#{sapien} and tissueType=#{tissue}",
            "</script>"
    })
    List<String> getSampleBySapienAndTissue(String sapien,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT SampleID FROM AUCell_Info3 WHERE sapiens=#{sapien} and Tissue=#{tissue} and Cytokine in ",
            "<foreach collection='cytokineList' item='item' open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<String> getSampleBySapienAndTissueCytokine(String sapien,String tissue, String[] cytokineList);

    @Select({
            "<script>",
            "SELECT DISTINCT set_celltype FROM ${table}",
            "</script>"
    })
    List<String> cytokineFun(String table);

    @Select({
            "<script>",
            "SELECT axis_x,axis_y,aucell FROM ${table} where set_celltype=#{celltype}",
            "</script>"
    })
    List<AUCellUmap> getAuCellUmap(String table,String celltype);

    @Select({
            "<script>",
            "SELECT Family FROM AUCell_Info2 where SampleID=#{sample}",
            "</script>"
    })
    List<String> getCytokineFun(String sample);


    @Select({
            "<script>",
            "SELECT genename as name FROM ${table}",
            "</script>"
    })
    List<Genename> getmarkerset_integana(String table);

    @Select({
            "<script>",
            "SELECT DISTINCT Disease_Status FROM ${table}",
            "</script>"
    })
    List<String> getDiseaseBySampleID_integana(String table);


    @Select({
            "<script>",
            "SELECT `Axis.x` as x, `Axis.y` as y, CellType2 as celltype,disease_status FROM ${table}",
            "</script>"
    })
    List<SampleUmap> getSample(String table);


    @Select({
            "<script>",
            "SELECT CellType2 AS name, round(counts/ total * 100, 2 ) AS value FROM (SELECT CellType2, count(CellType2) as counts FROM ${table} group by CellType2) AS t1 LEFT JOIN (SELECT COUNT(CellType2) AS total FROM ${table}) AS t2 ON 1=1",
            "</script>"
    })
    List<NameValue> getCellTypeAndFregBysample(String table);


    @Select({
            "<script>",
            "SELECT GROUP_CONCAT(`Axis.x` SEPARATOR ',') as x, GROUP_CONCAT(`Axis.y` SEPARATOR ',') as y, DataType as celltype FROM ${table} GROUP BY DataType",
            "</script>"
    })
    List<SampleUmap> getdataTypeData(String table);

    @Select({
            "<script>",
            "SELECT GROUP_CONCAT(`Axis.x` SEPARATOR ',') as x, GROUP_CONCAT(`Axis.y` SEPARATOR ',') as y, DataType as celltype FROM ${table} where DataType=#{option} GROUP BY DataType",
            "</script>"
    })
    List<SampleUmap> getdataTypeDataByType(String table,String option);



    @Select({
            "<script>",
            "SELECT GROUP_CONCAT(`Axis.x` SEPARATOR ',') as x, GROUP_CONCAT(`Axis.y` SEPARATOR ',') as y, celltype2 as celltype FROM ${table} where dataType='scRNA-seq' GROUP BY celltype2",
            "</script>"
    })
    List<SampleUmap> getRnaData(String table);



    @Select({
            "<script>",
            "SELECT GROUP_CONCAT(`Axis.x` SEPARATOR ',') as x, GROUP_CONCAT(`Axis.y` SEPARATOR ',') as y, celltype2 as celltype FROM ${table} where dataType='scATAC-seq' GROUP BY celltype2",
            "</script>"
    })
    List<SampleUmap> getAtacData(String table);
}

