package com.lcq.cell.mapper;

import com.github.pagehelper.Page;
import com.lcq.cell.pojo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface SearchDao {

    @Select({
            "<script>",
            "SELECT DISTINCT tissueType FROM browseTable",
            "</script>"
    })
    List<String> getTissue();

    @Select({
            "<script>",
            "SELECT DISTINCT Tissue FROM browseTable WHERE idenSignal=#{sample}",
            "</script>"
    })
    String getTissueBysample(String sample);

    @Select({
            "<script>",
            "SELECT DISTINCT Disease_Status FROM browseTable WHERE idenSignal=#{sample}",
            "</script>"
    })
    String getDiseaseBysample(String sample);

    @Select({
            "<script>",
            "SELECT DISTINCT disease FROM browseTable",
            "</script>"
    })
    List<String> getDisease();

    @Select({
            "<script>",
            "SELECT DISTINCT idenSignal FROM browseTable WHERE tissueType like CONCAT('%',#{tissue},'%')",
            "</script>"
    })
    List<String> getSampleByTissue(String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT idenSignal FROM browseTable WHERE disease like CONCAT('%',#{disease},'%')",
            "</script>"
    })
    List<String> getSampleByDisease(String disease);

    @Select({
            "<script>",
            "SELECT DISTINCT biosampleName FROM browseTable",
            "</script>"
    })
    List<String> getCelltype();

    @Select({
            "<script>",
            "SELECT DISTINCT idenSignal FROM browseTable WHERE biosampleName like CONCAT('%',#{celltype},'%')",
            "</script>"
    })
    List<String> getSampleByCelltype(String celltype);

    @Select({
            "<script>",
            "SELECT x, y, celltype FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<SampleUmap> getSampleByTissuePosi(String table,String tissue);

    @Select({
            "<script>",
            "SELECT cellType AS name, round(counts/ total * 100, 2 ) AS value FROM (SELECT celltype, count(celltype) as counts FROM ${table} WHERE Tissue=#{tissue} group by celltype) AS t1 LEFT JOIN (SELECT COUNT(cellType) AS total FROM ${table}  WHERE Tissue=#{tissue}) AS t2 ON 1=1",
            "</script>"
    })
    List<NameValue> getCellTypeAndFregBysample(String table,String tissue);

    @Select({
            "<script>",
            "SELECT cellColonNum FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getClonoCellNum(String table,String tissue);

    @Select({
            "<script>",
            "SELECT sampleInfo2 FROM ${table} WHERE Tissue=#{tissue} group by sampleInfo2",
            "</script>"
    })
    List<String> getGSMBySample(String table,String tissue);

    @Select({
            "<script>",
            "SELECT cellType FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue}",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion1(String table,String gsm,String tissue);

    @Select({
            "<script>",
            "SELECT MeanExp FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue}",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion2(String table,String gsm,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT celltype FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getCellTypeBysample(String table,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType, clusterAllCellNum, clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue}",
            "</script>"
    })
    List<CelltypeCellNum> getBarByGSM(String table,String gsm,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT sampleinfo FROM ${table} where sampleInfo2=#{gsm} AND Tissue=#{tissue}",
            "</script>"
    })
    String getbcrClonoTypeSampleInfoByGSM(String table, String gsm, String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT clonotype FROM ${table} where sampleInfo=#{gsm}",
            "</script>"
    })
    List<String> getClonoTypeByGSM(String table, String gsm);

    @Select({
            "<script>",
            "SELECT DISTINCT celltype FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getCellTypesBysample(String table,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType, clonotype, clusterColonTypeFreg AS clusterClonoTypeFreg FROM ${table} WHERE sampleInfo=#{gsm} AND clonoType = #{clono}",
            "</script>"
    })
    List<ClonotypeFreg> getClonoBarByGSM(String table,String gsm,String clono);

    @Select({
            "<script>",
            "SELECT cellType AS c1, MAX(clusterAllCellNum) AS c2,MAX(clusterColonCellNum) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue} GROUP BY cellType",
            "</script>"
    })
    List<Readfile> clonoBulkBarFreg(String table,String gsm,String tissue);
    @Select({
            "<script>",
            "SELECT count(otherInfo) AS value, otherInfo AS name FROM ${table} WHERE Tissue=#{tissue} group by otherInfo",
            "</script>"
    })
    List<NameValue> getOtherInfoStatus(String table,String tissue);

    @Select({
            "<script>",
            "SELECT count(cellType) AS value, cellType AS name FROM ${table} WHERE Tissue=#{tissue} group by cellType",
            "</script>"
    })
    List<NameValue> getCellTypeStatus(String table,String tissue);

    @Select({
            "<script>",
            "SELECT cellColonNum_BCR FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getBcrCellNum(String table,String tissue);

    @Select({
            "<script>",
            "SELECT cellType AS c1, MAX(clusterAllCellNum_BCR) AS c2,MAX(clusterColonCellNum_BCR) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue} GROUP BY cellType",
            "</script>"
    })
    List<Readfile> bcrBulkBarFreg(String table,String gsm,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType, clusterAllCellNum_BCR AS clusterAllCellNum, clusterColonCellNum_BCR AS clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm} AND Tissue=#{tissue}",
            "</script>"
    })
    List<CelltypeCellNum> bcrclusterCellNum(String table,String gsm,String tissue);

    @Select({
            "<script>",
            "SELECT DISTINCT clonotype FROM ${table} where sampleInfo=#{gsm}",
            "</script>"
    })
    List<String> getbcrClonoTypeByGSM(String table, String gsm);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getCelltype_BCR(String table,String tissue);

    @Select({
            "<script>",
            "SELECT `index` FROM ${table} WHERE Tissue=#{tissue}",
            "</script>"
    })
    List<String> getCellIndexByTissue(String table,String tissue);



    /*
    * Search Disease
    *
    * */
    @Select({
            "<script>",
            "SELECT x, y, celltype FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<SampleUmap> getSampleByDiseasePosi(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellType AS name, round(counts/ total * 100, 2 ) AS value FROM (SELECT celltype, count(celltype) as counts FROM ${table} WHERE Disease_Status=#{Disease} group by celltype) AS t1 LEFT JOIN (SELECT COUNT(cellType) AS total FROM ${table}  WHERE Disease_Status=#{Disease}) AS t2 ON 1=1",
            "</script>"
    })
    List<NameValue> getCellTypeAndFregBysampleDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellColonNum FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getClonoCellNumDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT sampleInfo2 FROM ${table} WHERE Disease_Status=#{Disease} group by sampleInfo2",
            "</script>"
    })
    List<String> getGSMBySampleDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellType FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion1Disease(String table,String gsm,String Disease);

    @Select({
            "<script>",
            "SELECT MeanExp FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getbarcodeMeanExpersion2Disease(String table,String gsm,String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT celltype FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getCellTypeBysampleDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType, clusterAllCellNum, clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease}",
            "</script>"
    })
    List<CelltypeCellNum> getBarByGSMDisease(String table,String gsm,String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT sampleinfo FROM ${table} where sampleInfo2=#{gsm} AND Disease_Status=#{Disease}",
            "</script>"
    })
    String getbcrClonoTypeSampleInfoByGSMDisease(String table, String gsm, String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT celltype FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getCellTypesBysampleDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellType AS c1, MAX(clusterAllCellNum) AS c2,MAX(clusterColonCellNum) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease} GROUP BY cellType",
            "</script>"
    })
    List<Readfile> clonoBulkBarFregDisease(String table,String gsm,String Disease);
    @Select({
            "<script>",
            "SELECT count(otherInfo) AS value, otherInfo AS name FROM ${table} WHERE Disease_Status=#{Disease} group by otherInfo",
            "</script>"
    })
    List<NameValue> getOtherInfoStatusDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT count(cellType) AS value, cellType AS name FROM ${table} WHERE Disease_Status=#{Disease} group by cellType",
            "</script>"
    })
    List<NameValue> getCellTypeStatusDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellColonNum_BCR FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getBcrCellNumDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT cellType AS c1, MAX(clusterAllCellNum_BCR) AS c2,MAX(clusterColonCellNum_BCR) AS c3 FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease} GROUP BY cellType",
            "</script>"
    })
    List<Readfile> bcrBulkBarFregDisease(String table,String gsm,String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT cellType, clusterAllCellNum_BCR AS clusterAllCellNum, clusterColonCellNum_BCR AS clusterColonCellNum FROM ${table} WHERE sampleInfo2=#{gsm} AND Disease_Status=#{Disease}",
            "</script>"
    })
    List<CelltypeCellNum> bcrclusterCellNumDisease(String table,String gsm,String Disease);

    @Select({
            "<script>",
            "SELECT DISTINCT CellType FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getCelltype_BCRDisease(String table,String Disease);

    @Select({
            "<script>",
            "SELECT `index` FROM ${table} WHERE Disease_Status=#{Disease}",
            "</script>"
    })
    List<String> getCellIndexByDisease(String table,String Disease);


    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,pmid,journal,article,`year`,platform FROM browseTable WHERE 1=1",
            " <when test='tissue !=\"\"'> ",
            " AND tissueType = #{tissue}",
            " </when> ",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by platform ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by article ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by journal ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by year ${dir}",
            " </when> ",
            " <when test='order ==\"11\"'>",
            " order by pmid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getSampleTabByTissue(String tissue, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,pmid,journal,article,`year`,platform FROM browseTable WHERE 1=1",
            " <when test='disease !=\"\"'> ",
            " AND disease = #{disease}",
            " </when> ",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by platform ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by article ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by journal ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by year ${dir}",
            " </when> ",
            " <when test='order ==\"11\"'>",
            " order by pmid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getSampleTabByDisease(String disease, String searchValue, String order, String dir);

    @Select({
            "<script>",
            "SELECT biosampleName,biosampleType,idenSignal,datasource,tissueType,disease,sapiens,pmid,journal,article,`year`,platform FROM browseTable WHERE 1=1",
            " <when test='celltype !=\"\"'> ",
            " AND biosampleName = #{celltype}",
            " </when> ",
            " <when test='searchValue !=\"\"'>",
            " AND (idenSignal LIKE CONCAT('%',#{searchValue},'%') or biosampleName LIKE CONCAT('%',#{searchValue},'%') or datasource LIKE CONCAT('%',#{searchValue},'%') or biosampleType LIKE CONCAT('%',#{searchValue},'%') or tissueType LIKE CONCAT('%',#{searchValue},'%'))",
            " </when> ",
            " <when test='order ==\"0\"'>",
            " order by idenSignal ${dir}",
            " </when> ",
            " <when test='order ==\"1\"'>",
            " order by sapiens ${dir}",
            " </when> ",
            " <when test='order ==\"2\"'>",
            " order by tissueType ${dir}",
            " </when> ",
            " <when test='order ==\"3\"'>",
            " order by biosampleName ${dir}",
            " </when> ",
            " <when test='order ==\"4\"'>",
            " order by biosampleType ${dir}",
            " </when> ",
            " <when test='order ==\"5\"'>",
            " order by disease ${dir}",
            " </when> ",
            " <when test='order ==\"6\"'>",
            " order by datasource ${dir}",
            " </when> ",
            " <when test='order ==\"7\"'>",
            " order by platform ${dir}",
            " </when> ",
            " <when test='order ==\"8\"'>",
            " order by article ${dir}",
            " </when> ",
            " <when test='order ==\"9\"'>",
            " order by journal ${dir}",
            " </when> ",
            " <when test='order ==\"10\"'>",
            " order by year ${dir}",
            " </when> ",
            " <when test='order ==\"11\"'>",
            " order by pmid ${dir}",
            " </when> ",
            "</script>"
    })
    Page<BrowseTable> getSampleTabByCelltype(String celltype, String searchValue, String order, String dir);

}
