package com.lcq.cell.controller;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.BrowserAtacDetailDao;
import com.lcq.cell.pojo.*;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class BrowserAtacDetail {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private BrowserAtacDetailDao detail;

    @GetMapping("atac_detail")
    public ModelAndView detail(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String sample = request.getParameter("sample");
        mv.addObject("sample",sample);
        mv.setViewName("messages/atac_detail");
        return mv;
    }

    @RequestMapping("getSample_atac")
    @ResponseBody
    public Map getSample_atac(HttpServletRequest request) {
        Map map = new HashMap();
        SampleTable table = new SampleTable();
        try{
            String sample = request.getParameter("sample");
            PageHelper.clearPage();
            List<SampleUmap> list = detail.getSample_atac(sample+"_metadata");
            List<NameValue> cellTypelist = new ArrayList<>();
            cellTypelist = detail.getCellTypeAndFregBysample_atac(sample+"_metadata");
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("listofCelltypes",cellTypelist);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("listofCelltypes",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getExpression_atac")
    @ResponseBody
    public Map getExpression_atac(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        String gene = request.getParameter("gene");
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath();
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+"scATAC_Data8/"+filename+"_cicero_gene_activity.rds";
            String metadata = workPath+"scATAC_Data8/"+filename+"_metadata.txt";
            c.assign("file", rdsfile);
            c.assign("outfile", "");
            c.assign("gene", gene);
            c.assign("metadata", metadata);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-getExpersion_atac(file,gene,metadata,outfile)").asList();
            REXPDouble x = (REXPDouble) result.get(0);
            REXPDouble y = (REXPDouble) result.get(1);
            REXPDouble v = (REXPDouble) result.get(2);
            c.close();
            List<String> xvalue = Arrays.asList(x.asStrings());
            List<String> yvalue = Arrays.asList(y.asStrings());
            List<String> vvalue = Arrays.asList(v.asStrings());
            map.put("x",xvalue);
            map.put("y",yvalue);
            map.put("v",vvalue);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("v",new String[0]);
            c.close();
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getExpression_value_atac")
    @ResponseBody
    public Map getExpression_value_atac(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        String gene = request.getParameter("gene");
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath();
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+"scATAC_Data8/"+filename+"_cicero_gene_activity.rds";
            String metadata = workPath+"scATAC_Data8/"+filename+"_metadata.txt";
            c.assign("file", rdsfile);
            c.assign("outfile", "");
            c.assign("gene", gene);
            c.assign("metadata", metadata);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-getExpersion_atac(file,gene,metadata,outfile)").asList();
            REXPDouble v = (REXPDouble) result.get(2);
            c.close();
            List<String> vvalue = Arrays.asList(v.asStrings());
            map.put("v",vvalue);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("v",new String[0]);
            c.close();
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getTFmotifList")
    @ResponseBody
    public Map getTFmotifList(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath()+"scATAC_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_chromVar_obj_zscores.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getTFList_atac(file)").asStrings();
            c.close();
            map.put("data",result);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            System.out.println(e.getMessage());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getTFmotifValue")
    @ResponseBody
    public Map getTFmotifValue(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        String tf = request.getParameter("tf");
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath()+"scATAC_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_chromVar_obj_zscores.rds";
            String metadata = workPath+filename+"_metadata.txt";
            c.assign("file", rdsfile);
            c.assign("outfile", "");
            c.assign("tf", tf);
            c.assign("metadata", metadata);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-getTFmotifValue_atac(file,tf,metadata,outfile)").asList();
            REXPDouble x = (REXPDouble) result.get(0);
            REXPDouble y = (REXPDouble) result.get(1);
            REXPDouble v = (REXPDouble) result.get(2);
            c.close();
            List<String> xvalue = Arrays.asList(x.asStrings());
            List<String> yvalue = Arrays.asList(y.asStrings());
            List<String> vvalue = Arrays.asList(v.asStrings());
            map.put("x",xvalue);
            map.put("y",yvalue);
            map.put("v",vvalue);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("v",new String[0]);
            c.close();
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getDApeak")
    @ResponseBody
    public PageTab getDApeak(Integer start, Integer draw, Integer length, HttpServletRequest request) throws RserveException, REXPMismatchException {
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        PageTab tabs = new PageTab();
        Page<DAPeak> list = new Page<>();
        String filename = request.getParameter("sample");
        try{
            String table = filename+"_DA_peak";
            list = detail.getDApeak(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }catch (Exception e){
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }
    }

    @RequestMapping("cicerotab")
    @ResponseBody
    public PageTab cicerotab(Integer start, Integer draw, Integer length, HttpServletRequest request) throws RserveException, REXPMismatchException {
        String sample = request.getParameter("sample");
        PageTab tabs = new PageTab();
        Page<Cicero> list = new Page<>();
        try{
            String searchValue = request.getParameter("search[value]");
            PageHelper.startPage(start / length + 1, length);
            String table = sample+"_cicero_interactions";
            list = detail.cicerotab(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }catch (Exception e){
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }
    }

    @RequestMapping("getTFmotif")
    @ResponseBody
    public PageTab getTFmotif(Integer start, Integer draw, Integer length, HttpServletRequest request) throws RserveException, REXPMismatchException {
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        PageTab tabs = new PageTab();
        Page<DiffTFMotif> list = new Page<>();
        String filename = request.getParameter("sample");
        try{
            String table = filename+"_differential_TF_motif_enriched_in_clusters";
            list = detail.getTFmotif(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }catch (Exception e){
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        }
    }

    @RequestMapping("canvasheat")
    @ResponseBody
    public ModelAndView canvasheat(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String sample = request.getParameter("sample");
        mv.setViewName("messages/canvasheat");
        mv.addObject("sample",sample);
        return mv;
    }

    @RequestMapping("getTFHeat")
    @ResponseBody
    public Map getTFHeat(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath()+"scATAC_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_TF1000.rds";
            String metafile = workPath+filename+"_metadata.txt";

            c.assign("file", rdsfile);
            c.assign("metafile", metafile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] tfname = c.eval("result<-getHeatTF_atac(file)").asStrings();
            String[] cellname = c.eval("result<-getHeatCell_atac(file)").asStrings();
            String[] result = c.eval("result<-getHeatData_atac(file)").asStrings();
            String[] celltype = c.eval("result<-getHeatCelltype_atac(file,metafile)").asStrings();
            c.close();
            int start = 0;
            int currentend = cellname.length;
            List<String[]> list = new ArrayList<>();
            for (int i=0;i< cellname.length;i++){
                String[] b = Arrays.copyOfRange(result, start, currentend);
                start+= tfname.length;
                currentend+=tfname.length;
                list.add(b);
            }

            map.put("tf",tfname);
            map.put("cell",cellname);
            map.put("celltype",celltype);
            map.put("data",list);
            return map;
        }catch (Exception e){
            c.close();
            map.put("tf",new String[0]);
            map.put("cell",new String[0]);
            map.put("celltype",new String[0]);
            List<String[]> list = new ArrayList<>();
            map.put("data",list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("setBubbleTissuePlot")
    @ResponseBody
    public Map setBubbleTissuePlot(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<SampleTable> list = detail.getTissueTypePlot(sample+"_metadata");
            map.put("data",list);
            return map;
        }catch (Exception e){
            List<SampleTable> list = new ArrayList<>();
            map.put("data",list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getpathwaycelltype_atac")
    @ResponseBody
    public Map getpathwaycelltype(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> data = detail.getpathwaycelltype_atac(sample+"_DEG_FunAnn");
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getPathwayGo_atac")
    @ResponseBody
    public Map getPathwayGo_atac(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String count = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            PageHelper.clearPage();
            List<PathwayTable> data = detail.getPathwayGo_atac(sample,cluster,count);
            List<List<String>> result = new ArrayList<>();
            List<String> header = new ArrayList<>();
            header.add("score");
            header.add("amount");
            header.add("product");
            result.add(header);
            for (int i=0;i<data.size();i++){
                List<String> body = new ArrayList<>();
                Double padjust = -Math.log10(Double.parseDouble(data.get(i).getF_p_adjust()));
                body.add(padjust.toString());
                body.add(data.get(i).getF_count());
                body.add(data.get(i).getF_description());
                result.add(body);
            }
            map.put("data",result);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList[0]);
            return map;
        }
    }

    @RequestMapping("getPathwayKEGG_atac")
    @ResponseBody
    public Map getPathwayKEGG_atac(HttpServletRequest request) {
        Map map = new HashMap();
//        try{
            System.out.println("aaaaaaaaaaaaaaaaaaaa------------------");
            System.out.println("aaaaaaaaaaaaaaaaaaaa------------------");
            String sample = request.getParameter("sample");
            String count = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            PageHelper.clearPage();
            List<PathwayTable> data = detail.getPathwayKEGG_atac(sample+"_DEG_FunAnn",cluster,count);
            List<List<String>> result = new ArrayList<>();
            int max = 0;
            int min = 10000;
            Double pvalueMax = 0.0;
            Double pvalueMin = 100.0;
            for (int i=0;i<data.size();i++){
                List<String> body = new ArrayList<>();
                Double pvalue = -Math.log10(Double.parseDouble(data.get(i).getF_p_value()));
                body.add(data.get(i).getF_gene_ratio());
                body.add(data.get(i).getF_description());
                body.add(pvalue.toString());
                body.add(data.get(i).getF_count());
                result.add(body);
                int countt = Integer.parseInt(data.get(i).getF_count());
                if (countt>max){
                    max = countt;
                }
                if (countt<min){
                    min = countt;
                }
                if (pvalue>pvalueMax){
                    pvalueMax = pvalue;
                }
                if (pvalue<pvalueMin){
                    pvalueMin = pvalue;
                }
            }
            map.put("data",result);
            map.put("countMin",min);
            map.put("countMax",max);
            map.put("pValueMin",pvalueMin);
            map.put("pValueMax",pvalueMax);
            return map;
        /*}catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }*/
    }
}

