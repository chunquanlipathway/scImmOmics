package com.lcq.cell.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.context.support.HttpRequestHandlerServlet;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

@Controller
public class UrlController {
    @GetMapping("/")
    public ModelAndView home() {
        return new ModelAndView("messages/index");
    }

    @GetMapping("home")
    public ModelAndView homeenid() {
        return new ModelAndView("messages/index");
    }

    @GetMapping("index")
    public ModelAndView index() {
        return new ModelAndView("messages/index");
    }

    @GetMapping("browse")
    public ModelAndView browse() {
        return new ModelAndView("messages/browse");
    }

    @GetMapping("search")
    public ModelAndView search() {
        return new ModelAndView("messages/search");
    }

    @GetMapping("help")
    public ModelAndView help() {
        return new ModelAndView("messages/help");
    }

    @GetMapping("contact")
    public ModelAndView contact() {
        return new ModelAndView("messages/contact");
    }

    @GetMapping("download")
    public ModelAndView download() {
        return new ModelAndView("messages/download");
    }

    @GetMapping("comparisonAna")
    public ModelAndView comparisonAna() {
        return new ModelAndView("messages/comparisonAna");
    }

    @GetMapping("aucellAna")
    public ModelAndView aucellAna() {
        return new ModelAndView("messages/AuCellAna");
    }

}
