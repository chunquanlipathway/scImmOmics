package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.BrowserDetailDao;
import com.lcq.cell.mapper.SearchDao;
import com.lcq.cell.pojo.*;
import com.lcq.cell.until.ShellUtil;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class SearchDetail {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private SearchDao search;

    @RequestMapping("getTissue")
    @ResponseBody
    public Map getTissue() {
        Map map = new HashMap();
        try {
            List<String> list = search.getTissue();
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getSampleByTissue")
    @ResponseBody
    public Map getSampleByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try {
            String tissue = request.getParameter("tissue");
            List<String> list = search.getSampleByTissue(tissue);
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getDisease")
    @ResponseBody
    public Map getDisease() {
        Map map = new HashMap();
        try {
            List<String> data = new ArrayList<>();
            List<String> list = search.getDisease();
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getSampleByDisease")
    @ResponseBody
    public Map getSampleByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try {
            String disease = request.getParameter("disease");
            List<String> list = search.getSampleByDisease(disease);
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getCelltypes")
    @ResponseBody
    public Map getCelltype() {
        Map map = new HashMap();
        try {
            List<String> list = search.getCelltype();
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getSampleByCelltype")
    @ResponseBody
    public Map getSampleByCelltype(HttpServletRequest request) {
        Map map = new HashMap();
        try {
            String celltype = request.getParameter("celltype");
            List<String> list = search.getSampleByCelltype(celltype);
            map.put("data",list);
            return map;
        } catch (Exception e) {
            map.put("data",new ArrayList<>());
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("getSampleByTissuePosi")
    @ResponseBody
    public Map getSampleByTissuePosi(HttpServletRequest request) {
        Map map = new HashMap();
        SampleTable table = new SampleTable();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<SampleUmap> list = search.getSampleByTissuePosi(sample+"_metadata",tissue);
            List<NameValue> cellTypelist = new ArrayList<>();
            cellTypelist = search.getCellTypeAndFregBysample(sample+"_metadata",tissue);
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("listofCelltypes",cellTypelist);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("listofCelltypes",new String[0]);
            return map;
        }
    }

    @RequestMapping("getClonoCellNumByTissue")
    @ResponseBody
    public Map getClonoCellNumByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<String> list = search.getClonoCellNum(sample+"_metadata",tissue);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getViolinByGSMByTissue")
    @ResponseBody
    public Map getViolinByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            List<String> celltypeMExpersion1 = search.getbarcodeMeanExpersion1(sample+"_metadata",gsm,tissue);
            List<String> celltypeMExpersion2 = search.getbarcodeMeanExpersion2(sample+"_metadata",gsm,tissue);
            List<String> celltype = search.getCellTypeBysample(sample+"_metadata",tissue);
            map.put("x",celltypeMExpersion1);
            map.put("y",celltypeMExpersion2);
            map.put("celltype",celltype);
            return map;
        }catch (Exception e){
            map.put("x",new ArrayList<>());
            map.put("y",new ArrayList<>());
            map.put("celltype",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBarByGSMByTissue")
    @ResponseBody
    public Map getBarByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            List<CelltypeCellNum> celltypeCellNum = search.getBarByGSM(sample+"_metadata",gsm,tissue);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("sumcell",0);
            map.put("sumclono",0);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getClonoTypeByGSMByTissue")
    @ResponseBody
    public Map getClonoTypeByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata",gsm,tissue);
            List<String> list = search.getClonoTypeByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("getClonoBarByGSMByTissue")
    @ResponseBody
    public Map getClonoBarByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = search.getCellTypesBysample(sample+"_metadata",tissue);
            List<List<String>> strlist = new ArrayList<>();
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata",gsm,tissue);
            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = search.getClonoBarByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("clonoBulkBarFregByTissue")
    @ResponseBody
    public Map clonoBulkBarFregByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            List<Readfile> list = search.clonoBulkBarFreg(sample+"_metadata",gsm,tissue);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("sampleStatusByTissue")
    @ResponseBody
    public Map sampleStatusByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<NameValue> otherInfoStatus = search.getOtherInfoStatus(sample+"_metadata",tissue);
            List<NameValue> cellTypeStatus = search.getCellTypeStatus(sample+"_metadata",tissue);
            map.put("otherInfoStatus",otherInfoStatus);
            map.put("cellTypeStatus",cellTypeStatus);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBcrCellNumByTissue")
    @ResponseBody
    public Map getBcrCellNumByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<String> list = search.getBcrCellNum(sample+"_metadata",tissue);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrBulkBarFregByTissue")
    @ResponseBody
    public Map bcrBulkBarFregByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            List<Readfile> list = search.bcrBulkBarFreg(sample+"_metadata",gsm,tissue);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrclusterCellNumByTissue")
    @ResponseBody
    public Map bcrclusterCellNumByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            List<CelltypeCellNum> celltypeCellNum = search.bcrclusterCellNum(sample+"_metadata",gsm,tissue);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getbcrClonoBarByGSMByTissue")
    @ResponseBody
    public Map getbcrClonoBarByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = search.getCellTypesBysample(sample+"_metadata",tissue);
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata",gsm,tissue);
            List<List<String>> strlist = new ArrayList<>();

            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = search.getClonoBarByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getbcrClonoTypeByGSMByTissue")
    @ResponseBody
    public Map getbcrClonoTypeByGSMByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String tissue = request.getParameter("tissue");
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata",gsm,tissue);
            List<String> list = search.getbcrClonoTypeByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("getGSMBySampleByTissue")
    @ResponseBody
    public Map getGSMBySampleByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<String> list = search.getGSMBySample(sample+"_metadata",tissue);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getCelltype_BCRByTissue")
    @ResponseBody
    public Map getCelltype_BCRByTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String tissue = request.getParameter("tissue");
            List<String> list = search.getCelltype_BCR(sample+"_metadata",tissue);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getExpressionByTissue")
    @ResponseBody
    public Map getExpressionByTissue(HttpServletRequest request) throws REngineException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        String gene = request.getParameter("gene");
        String tissue = request.getParameter("tissue");
        RConnection c = new RConnection();
        try {
            List<String> index = search.getCellIndexByTissue(filename+"_metadata",tissue);
            String[] arr = new String[index.size()];
            index.toArray(arr);
            String workPath = path.getWorkPath();
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_All.rds";
            c.assign("file", rdsfile);
            c.assign("outfile", "");
            c.assign("gene", gene);
            c.assign("index", arr);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getExpersionByTissue(file,gene,index)").asStrings();
            String[] data = result[0].split(",");
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("data",new String[0]);
            c.close();
            return map;
        }

    }










    /*
    * Search Disease
    *
    * */
    @RequestMapping("getSampleByDiseasePosi")
    @ResponseBody
    public Map getSampleByDiseasePosi(HttpServletRequest request) {
        Map map = new HashMap();
        SampleTable table = new SampleTable();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<SampleUmap> list = search.getSampleByDiseasePosi(sample+"_metadata",Disease);
            List<NameValue> cellTypelist = new ArrayList<>();
            cellTypelist = search.getCellTypeAndFregBysampleDisease(sample+"_metadata",Disease);
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("listofCelltypes",cellTypelist);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getClonoCellNumByDisease")
    @ResponseBody
    public Map getClonoCellNumByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<String> list = search.getClonoCellNumDisease(sample+"_metadata",Disease);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getViolinByGSMByDisease")
    @ResponseBody
    public Map getViolinByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            List<String> celltypeMExpersion1 = search.getbarcodeMeanExpersion1Disease(sample+"_metadata",gsm,Disease);
            List<String> celltypeMExpersion2 = search.getbarcodeMeanExpersion2Disease(sample+"_metadata",gsm,Disease);
            List<String> celltype = search.getCellTypeBysampleDisease(sample+"_metadata",Disease);
            map.put("x",celltypeMExpersion1);
            map.put("y",celltypeMExpersion2);
            map.put("celltype",celltype);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBarByGSMByDisease")
    @ResponseBody
    public Map getBarByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            List<CelltypeCellNum> celltypeCellNum = search.getBarByGSMDisease(sample+"_metadata",gsm,Disease);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getClonoTypeByGSMByDisease")
    @ResponseBody
    public Map getClonoTypeByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSMDisease(sample+"_metadata",gsm,Disease);
            List<String> list = search.getClonoTypeByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("getClonoBarByGSMByDisease")
    @ResponseBody
    public Map getClonoBarByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = search.getCellTypesBysampleDisease(sample+"_metadata",Disease);
            List<List<String>> strlist = new ArrayList<>();
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSMDisease(sample+"_metadata",gsm,Disease);
            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = search.getClonoBarByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("clonoBulkBarFregByDisease")
    @ResponseBody
    public Map clonoBulkBarFregByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            List<Readfile> list = search.clonoBulkBarFregDisease(sample+"_metadata",gsm,Disease);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("sampleStatusByDisease")
    @ResponseBody
    public Map sampleStatusByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<NameValue> otherInfoStatus = search.getOtherInfoStatusDisease(sample+"_metadata",Disease);
            List<NameValue> cellTypeStatus = search.getCellTypeStatusDisease(sample+"_metadata",Disease);
            map.put("otherInfoStatus",otherInfoStatus);
            map.put("cellTypeStatus",cellTypeStatus);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBcrCellNumByDisease")
    @ResponseBody
    public Map getBcrCellNumByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<String> list = search.getBcrCellNumDisease(sample+"_metadata",Disease);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrBulkBarFregByDisease")
    @ResponseBody
    public Map bcrBulkBarFregByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            List<Readfile> list = search.bcrBulkBarFregDisease(sample+"_metadata",gsm,Disease);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrclusterCellNumByDisease")
    @ResponseBody
    public Map bcrclusterCellNumByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            List<CelltypeCellNum> celltypeCellNum = search.bcrclusterCellNumDisease(sample+"_metadata",gsm,Disease);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getbcrClonoBarByGSMByDisease")
    @ResponseBody
    public Map getbcrClonoBarByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = search.getCellTypesBysampleDisease(sample+"_metadata",Disease);
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSMDisease(sample+"_metadata",gsm,Disease);
            List<List<String>> strlist = new ArrayList<>();

            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = search.getClonoBarByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getbcrClonoTypeByGSMByDisease")
    @ResponseBody
    public Map getbcrClonoTypeByGSMByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String Disease = request.getParameter("Disease");
            String sampleinfo2 = search.getbcrClonoTypeSampleInfoByGSMDisease(sample+"_metadata",gsm,Disease);
            List<String> list = search.getbcrClonoTypeByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("getGSMBySampleByDisease")
    @ResponseBody
    public Map getGSMBySampleByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<String> list = search.getGSMBySampleDisease(sample+"_metadata",Disease);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getCelltype_BCRByDisease")
    @ResponseBody
    public Map getCelltype_BCRByDisease(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String Disease = request.getParameter("Disease");
            List<String> list = search.getCelltype_BCRDisease(sample+"_metadata",Disease);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getExpressionByDisease")
    @ResponseBody
    public Map getExpressionByDisease(HttpServletRequest request) throws REngineException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try {
            SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
            String filename = request.getParameter("sample");
            String gene = request.getParameter("gene");
            String Disease = request.getParameter("Disease");
            List<String> index = search.getCellIndexByDisease(filename+"_metadata",Disease);
            String[] arr = new String[index.size()];
            index.toArray(arr);
            String workPath = path.getWorkPath();
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_All.rds";
            c.assign("file", rdsfile);
            c.assign("outfile", "");
            c.assign("gene", gene);
            c.assign("index", arr);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getExpersionByTissue(file,gene,index)").asStrings();
            String[] data = result[0].split(",");
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            return map;
        }

    }

    @GetMapping("detailbytissue")
    public ModelAndView detailbytissue(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String tissue = request.getParameter("tissue");
        mv.addObject("tissue",tissue);
        mv.setViewName("messages/detailbytissue");
        return mv;
    }

    @RequestMapping("getSampleTabByTissue")
    @ResponseBody
    public PageTab getSampleTabByTissue(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        Page<BrowseTable> list = search.getSampleTabByTissue(request.getParameter("tissue"),searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
        try {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @GetMapping("detailbydisease")
    public ModelAndView detailbydisease(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String disease = request.getParameter("disease");
        mv.addObject("disease",disease);
        mv.setViewName("messages/detailbydisease");
        return mv;
    }

    @RequestMapping("getSampleTabByDisease")
    @ResponseBody
    public PageTab getSampleTabByDisease(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        Page<BrowseTable> list = search.getSampleTabByDisease(request.getParameter("disease"),searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
        try {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }


    @GetMapping("detailbycelltype")
    public ModelAndView detailbycelltype(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String celltype = request.getParameter("celltype");
        mv.addObject("celltype",celltype);
        mv.setViewName("messages/detailbycelltype");
        return mv;
    }

    @RequestMapping("getSampleTabByCelltype")
    @ResponseBody
    public PageTab getSampleTabByCelltype(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        Page<BrowseTable> list = search.getSampleTabByCelltype(request.getParameter("celltype"),searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
        try {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }
}

