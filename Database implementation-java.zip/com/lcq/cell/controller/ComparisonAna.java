package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.AnalysisDao;
import com.lcq.cell.mapper.BrowserDetailDao;
import com.lcq.cell.pojo.*;
import com.lcq.cell.until.ShellUtil;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ComparisonAna {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private AnalysisDao analysis;

    @RequestMapping("getAllSampleInfo")
    @ResponseBody
    public PageTab getAllSampleInfo(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        Map map = new HashMap();
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            PageHelper.startPage(start / length + 1, length);
            Page<BrowseTable> list = analysis.getAllSampleInfo(searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("getIntegrativeRNA")
    @ResponseBody
    public PageTab getIntegrativeRNA(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        Map map = new HashMap();
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            PageHelper.startPage(start / length + 1, length);
            Page<BrowseTable> list = analysis.getIntegrativeRNA(searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("getIntegrativeATAC")
    @ResponseBody
    public PageTab getIntegrativeATAC(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        Map map = new HashMap();
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            PageHelper.startPage(start / length + 1, length);
            Page<BrowseTable> list = analysis.getIntegrativeATAC(searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

}

