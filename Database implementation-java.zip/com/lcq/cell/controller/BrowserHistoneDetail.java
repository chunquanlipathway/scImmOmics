package com.lcq.cell.controller;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.BrowserAtacDetailDao;
import com.lcq.cell.pojo.*;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class BrowserHistoneDetail {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private BrowserAtacDetailDao detail;

    @GetMapping("detail_histone")
    public ModelAndView detail_histone(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String sample = request.getParameter("sample");
        mv.addObject("sample",sample);
        mv.setViewName("messages/detail_histone");
        return mv;
    }

    @RequestMapping("getProteinList_Histone")
    @ResponseBody
    public Map getProteinList_Histone(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"Protein_Data7/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_Protein.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList(file)").asStrings();
            c.close();
            map.put("data",result);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getProtein_Histone")
    @ResponseBody
    public Map getProtein_Histone(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String protein = request.getParameter("protein");
            String workPath = path.getWorkPath()+"Protein_Data7/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_Protein.rds";
            if (protein==null)protein="";
            c.assign("file", rdsfile);
            c.assign("gene", protein);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            REXP result = c.eval("result<-getExpersion(file,gene)");
            double[] data = result.asDoubles();
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            return map;
        }
    }

    @RequestMapping("dapeakhistone")
    @ResponseBody
    public PageTab dapeakhistone(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            sample = sample + "_DA_peak";
            PageHelper.startPage(start / length + 1, length);
            Page<HistoneDAPeak> list = detail.dapeakhistone(sample,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<CellChatInfo> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }
}

