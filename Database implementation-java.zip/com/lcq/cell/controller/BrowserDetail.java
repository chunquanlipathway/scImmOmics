package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.BrowserDetailDao;
import com.lcq.cell.pojo.*;
import com.lcq.cell.until.ShellUtil;
import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class BrowserDetail {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private BrowserDetailDao detail;


    @RequestMapping("diversityImgData")
    @ResponseBody
    public Map diversityImgData(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String what = request.getParameter("what");
            String diversityOptions = request.getParameter("diversityOptions");
            List<NameValue> data = detail.diversityImgData(sample+"_StartracDiversity"+what,diversityOptions);
            map.put("data",data);
            return map;
        }catch (Exception e){
            List<NameValue> data = new ArrayList<>();
            map.put("data", data);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("cdr3Table")
    @ResponseBody
    public PageTab cdr3Table(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            String table = sample+"_Cdr3";
            PageHelper.startPage(start / length + 1, length);
            Page<Readfile> list = detail.getCdr3Table(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<Readfile> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("TRUST4cdr3Table")
    @ResponseBody
    public PageTab TRUST4cdr3Table(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            String table = sample+"_Cdr3";
            PageHelper.startPage(start / length + 1, length);
            Page<Readfile> list = detail.getCdr3Table(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<Readfile> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("cdr3BCRTable")
    @ResponseBody
    public PageTab cdr3BCRTable(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        Map map = new HashMap();
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            String table = sample+"_Cdr3_BCR";
            PageHelper.startPage(start / length + 1, length);
            Page<Readfile> list = detail.getCdr3Table(table,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<Readfile> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("sampleInfo")
    @ResponseBody
    public Map sampleInfo(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            BrowseTable data = detail.sampleinfo(sample);

            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("data",new BrowseTable());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getDiseaseBySampleID")
    @ResponseBody
    public Map getDiseaseBySampleID(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String table = sample + "_metadata3";
            List<String> data = detail.getDiseaseBySampleID(table);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("data",new BrowseTable());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("determineTRUST4")
    @ResponseBody
    public Map determineTRUST4(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String samplename = detail.determineTRUST4(sample);
            map.put("data",samplename);
            return map;
        }catch (Exception e){
            map.put("data","");
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getIntegratedType")
    @ResponseBody
    public Map getIntegratedType(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String data = detail.getIntegratedType(sample);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("data",new BrowseTable());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("celltypeForce")
    @ResponseBody
    public Map celltypeForce(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<Node> nodelist = detail.celltypeForceNode(sample+"_ClusterAndClusterColonFreg",gsm);
            List<Edge> edgelist = detail.celltypeForceEdge(sample+"_ClusterAndClusterColonFreg",gsm);
            LineStyle lineStyle = null;
            Category category = null;
            List<Category> categorys = new ArrayList<>();
            for (int i=0;i<nodelist.size();i++){
                category = new Category();
                category.setName(nodelist.get(i).getCategory());
                categorys.add(category);
            }
            for (int i=0;i<edgelist.size();i++){
                lineStyle = new LineStyle();
                lineStyle.setWidth(edgelist.get(i).getWidth());
                edgelist.get(i).setLineStyle(lineStyle);
            }
            map.put("nodelist",nodelist);
            map.put("edgelist",edgelist);
            map.put("categorys",categorys);
            return map;
        }catch (Exception e){
            map.put("nodelist",new ArrayList<>());
            map.put("edgelist",new ArrayList<>());
            map.put("categorys",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }
    @RequestMapping("celltypeForceBCR")
    @ResponseBody
    public Map celltypeForceBCR(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<Node> nodelist = detail.celltypeForceNode(sample+"_ClusterAndClusterColonFreg_BCR",gsm);
            List<Edge> edgelist = detail.celltypeForceEdge(sample+"_ClusterAndClusterColonFreg_BCR",gsm);
            LineStyle lineStyle = null;
            Category category = null;
            List<Category> categorys = new ArrayList<>();
            for (int i=0;i<nodelist.size();i++){
                category = new Category();
                category.setName(nodelist.get(i).getCategory());
                categorys.add(category);
            }
            for (int i=0;i<edgelist.size();i++){
                lineStyle = new LineStyle();
                lineStyle.setWidth(edgelist.get(i).getWidth());
                edgelist.get(i).setLineStyle(lineStyle);
            }
            map.put("nodelist",nodelist);
            map.put("edgelist",edgelist);
            map.put("categorys",categorys);
            return map;
        }catch (Exception e){
            map.put("nodelist",new ArrayList<>());
            map.put("edgelist",new ArrayList<>());
            map.put("categorys",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("clonoBulkBarFreg")
    @ResponseBody
    public Map clonoBulkBarFreg(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<Readfile> list = detail.clonoBulkBarFreg(sample+"_metadata3",gsm);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("celltypearr",new String[0]);
            map.put("chatarr",new String[0]);
            map.put("clonoarr",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("TRUST4clonoBulkBarFreg")
    @ResponseBody
    public Map TRUST4clonoBulkBarFreg(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<Readfile> list = detail.TRUST4clonoBulkBarFreg(sample+"_metadata3",gsm);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("celltypearr",new String[0]);
            map.put("chatarr",new String[0]);
            map.put("clonoarr",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrBulkBarFreg")
    @ResponseBody
    public Map bcrBulkBarFreg(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<Readfile> list = detail.bcrBulkBarFreg(sample+"_metadata3",gsm);
            int sum = 0;
            for (int i=0;i<list.size();i++){
                sum+=Integer.parseInt(list.get(i).getC2());
            }
            String[] celltypearr = new String[list.size()];
            Double[] chatarr = new Double[list.size()];
            Double[] clonoarr = new Double[list.size()];
            for (int i=0;i<list.size();i++){
                Double all = Double.parseDouble(list.get(i).getC2())/sum;
                Double clono = Double.parseDouble(list.get(i).getC3())/sum;
                celltypearr[i] = list.get(i).getC1();
                chatarr[i] = all-clono;
                clonoarr[i] = clono;
            }
            map.put("celltypearr",celltypearr);
            map.put("chatarr",chatarr);
            map.put("clonoarr",clonoarr);
            return map;
        }catch (Exception e){
            map.put("celltypearr",new String[0]);
            map.put("chatarr",new String[0]);
            map.put("clonoarr",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getClonoTypeByGSM")
    @ResponseBody
    public Map getClonoTypeByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            List<String> list = detail.getClonoTypeByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("TRUST4getClonoTypeByGSM")
    @ResponseBody
    public Map TRUST4getClonoTypeByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            List<String> list = detail.getClonoTypeByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getbcrClonoTypeByGSM")
    @ResponseBody
    public Map getbcrClonoTypeByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            List<String> list = detail.getbcrClonoTypeByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            System.out.println(e.getMessage());
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getClonoBarByGSM")
    @ResponseBody
    public Map getClonoBarByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = detail.getCellTypesBysample(sample+"_metadata3");
            List<List<String>> strlist = new ArrayList<>();
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = detail.getClonoBarByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            map.put("cellType",new ArrayList<>());
            System.out.println(e.getMessage());
            return map;
        }
    }

    @RequestMapping("TRUST4getClonoBarByGSM")
    @ResponseBody
    public Map TRUST4getClonoBarByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = detail.getCellTypesBysample(sample+"_metadata3");
            List<List<String>> strlist = new ArrayList<>();
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = detail.getClonoBarByGSM(sample+"_ClusterColonTypeFreg",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            map.put("cellType",new ArrayList<>());
            System.out.println(e.getMessage());
            return map;
        }
    }
    @RequestMapping("getbcrClonoBarByGSM")
    @ResponseBody
    public Map getbcrClonoBarByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            String clonoTypeParam = request.getParameter("clonoType");
            String[] clonoArr = clonoTypeParam.split(",");
            List<String> clonoType = new ArrayList<>();
            for (int i=0;i<clonoArr.length;i++){
                clonoType.add(clonoArr[i]);
            }
            List<String> cellType = detail.getCellTypesBysample(sample+"_metadata3");
            String sampleinfo2 = detail.getbcrClonoTypeSampleInfoByGSM(sample+"_metadata3",gsm);
            List<List<String>> strlist = new ArrayList<>();

            for (int i=0;i<clonoType.size();i++){
                List<ClonotypeFreg> list = detail.getClonoBarByGSM(sample+"_ClusterColonTypeFreg_BCR",sampleinfo2,clonoType.get(i));
                List<String> strlisttmp = new ArrayList<>();
                List<String> subcelltype = new ArrayList<>();
                for (int j=0;j<list.size();j++){
                    subcelltype.add(list.get(j).getCelltype());
                }
                for (int k=0;k<cellType.size();k++){
                    int index = subcelltype.indexOf(cellType.get(k));
                    if (index>=0){
                        strlisttmp.add(list.get(index).getClusterClonoTypeFreg());
                    }else {
                        strlisttmp.add("0");
                    }
                }
                strlisttmp.toString();
                strlist.add(strlisttmp);
            }
            map.put("data",strlist);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("cellType",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBarByGSM")
    @ResponseBody
    public Map getBarByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<CelltypeCellNum> celltypeCellNum = detail.getBarByGSM(sample+"_metadata3",gsm);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("sumcell",0);
            map.put("sumclono",0);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("TRUST4getBarByGSM")
    @ResponseBody
    public Map TRUST4getBarByGSM(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<CelltypeCellNum> celltypeCellNum = detail.TRUST4getBarByGSM(sample+"_metadata3",gsm);
            int sumcell = 0;
            int sumclono = 0;
            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("sumcell",0);
            map.put("sumclono",0);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("bcrclusterCellNum")
    @ResponseBody
    public Map bcrclusterCellNum(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String gsm = request.getParameter("gsm");
            List<CelltypeCellNum> celltypeCellNum = detail.bcrclusterCellNum(sample+"_metadata3",gsm);
            int sumcell = 0;
            int sumclono = 0;

            for (int i=0;i<celltypeCellNum.size();i++){
                sumcell+=Integer.parseInt(celltypeCellNum.get(i).getClusterAllCellNum());
                sumclono+=Integer.parseInt(celltypeCellNum.get(i).getClusterColonCellNum());
            }
            map.put("data",celltypeCellNum);
            map.put("sumcell",sumcell);
            map.put("sumclono",sumclono);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("sumcell",0);
            map.put("sumclono",0);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("TRUST4getClonoCellNum")
    @ResponseBody
    public Map TRUST4getClonoCellNum(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.TRUST4getClonoCellNum(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getClonoCellNum")
    @ResponseBody
    public Map getClonoCellNum(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.getClonoCellNum(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getBcrCellNum")
    @ResponseBody
    public Map getBcrCellNum(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.getBcrCellNum(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getHeatplot")
    @ResponseBody
    public Map getHeatplot(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        String filename = request.getParameter("sample");
        String gene = request.getParameter("gene");
        String workPath = path.getWorkPath();
        String file = workPath+filename+"_GeneClusterGSM.txt";
        String data = ShellUtil.getHeatLines(file,gene);
        List<String> gsm = detail.getGSMBySample(filename+"_metadata3");
        List<String> celltype = detail.getCellTypesBysample(filename+"_metadata3");
        map.put("data","["+data+"]");
        map.put("gsm",gsm);
        map.put("celltype",celltype);
        return map;
    }

    @RequestMapping("getExpression")
    @ResponseBody
    public Map getExpression(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath();
            String rdsfile = "";
            String filename = request.getParameter("sample");
            workPath = workPath + "ExpRDS_Data8/";
            rdsfile = workPath+filename+".rds";
            String gene = request.getParameter("gene");
            String getExpersion = path.getExpersionCodePath();
            System.out.println("---------getExpression---------");
            System.out.println("---"+gene+"---");
            System.out.println("---"+gene.trim()+"---");
            System.out.println(rdsfile);
            if (gene==null)gene="";
            c.assign("file", rdsfile);
            c.assign("gene", gene.trim());
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            REXP result = c.eval("result<-getExpersion(file,gene)");
            double[] data = result.asDoubles();
            System.out.println(data[0]+" "+data[1]+" "+data[2]+" "+data[3]+" "+data[4]+" "+data[5]+" "+data[6]+" "+data[7]+" "+data[8]+" "+data[9]+" "+data[10]);
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            return map;
        }
    }

    @RequestMapping("getProtein")
    @ResponseBody
    public Map getProtein(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        String filename = request.getParameter("sample");
        String protein = request.getParameter("protein");
        String workPath = path.getWorkPath()+"Protein_Data7/";
        String getExpersion = path.getExpersionCodePath();
        String rdsfile = workPath+filename+"_Protein.rds";
        try{
            if (protein==null)protein="";
            c.assign("file", rdsfile);
            c.assign("gene", protein);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            REXP result = c.eval("result<-getExpersion(file,gene)");
            double[] data = result.asDoubles();
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            c.close();
            System.out.println(rdsfile);
            System.out.println("---error---");
            map.put("data",new String[0]);
            return map;
        }
    }

    @RequestMapping("getCorExp")
    @ResponseBody
    public Map getCorExp(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"CorExp_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_CorExp.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-getCorExp(file)").asList();
            REXPDouble result1 = (REXPDouble) result.elementAt(0);
            double[][] array = result1.asDoubleMatrix();
            REXPString result2 = (REXPString) result.elementAt(1);
            String[] celltype = result2.asStrings();
            /*转换为echart格式*/
            double[][] arrayechart = new double[celltype.length*celltype.length][3];
            int k = 0;
            double min = 0;
            for (int i = 0; i < celltype.length; i++) {
                for (int j = 0; j < celltype.length; j++) {
                    double[] arr = new double[]{i, j, array[i][j]};
                    arrayechart[k] = arr;
                    k = k+1;
                    if (i==0&&j==0){
                        min = array[0][0];
                    }else {
                        if (array[i][j]<min){
                            min = array[i][j];
                        }
                    }
                }
            }
            map.put("data", arrayechart);
            map.put("min", min);
            /**/
//            map.put("data", array);
            map.put("celltype", celltype);
            c.close();
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0][0]);
            map.put("celltype",new String[0]);
            return map;
        }
    }

    @RequestMapping("getCellChat")
    @ResponseBody
    public Map getCellChat(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String selectWidth = request.getParameter("selectWidth");
            if (selectWidth.equals("width")){
                sample = sample + "_CellChat_weight";
            }else {
                sample = sample + "_CellChat_count";
            }
            List<Nodes> nodes = detail.getCellChatNode(sample);
            List<Categories> categories = detail.getCellChatCategorie(sample);
            List<Links> links = detail.getCellChatLink(sample);
            LineStyle lineStyle = null;
            for (int i=0;i<links.size();i++){
                lineStyle = new LineStyle();
                lineStyle.setWidth(links.get(i).getWidth());
                links.get(i).setLineStyle(lineStyle);
            }
            Graph graph = new Graph();
            graph.setCategories(categories);
            graph.setNodes(nodes);
            graph.setLinks(links);
            map.put("graph", graph);
            return map;
        }catch (Exception e){
            Graph graph = new Graph();
            map.put("graph", graph);
            return map;
        }
    }

    @RequestMapping("getPathwayGo")
    @ResponseBody
    public Map getPathwayGo(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String padjustCut = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            sample = sample + "_DEG_FunAnn";
            PageHelper.clearPage();
            List<FunAnn> data = detail.getPathwayGo(sample,cluster,padjustCut);
            List<List<String>> result = new ArrayList<>();
            List<String> header = new ArrayList<>();
            header.add("score");
            header.add("amount");
            header.add("product");
            result.add(header);
            int len = 0;
            if (data.size()>15){
                len = 15;
            }else {
                len = data.size();
            }
            for (int i=0;i<len;i++){
                List<String> body = new ArrayList<>();
                Double padjust = -Math.log10(Double.parseDouble(data.get(i).getPadjust()));
                body.add(padjust.toString());
                body.add(data.get(i).getCount());
                body.add(data.get(i).getDescription());
                result.add(body);
            }
            map.put("data",result);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList[0]);
            return map;
        }
    }

    @RequestMapping("getPathwayhallmark")
    @ResponseBody
    public Map getPathwayhallmark(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String padjustCut = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            sample = sample + "_DEG_Hallmark";
            PageHelper.clearPage();
            List<FunAnn> data = detail.getPathwayHallmark(sample,cluster,padjustCut);
            List<List<String>> result = new ArrayList<>();
            List<String> header = new ArrayList<>();
            header.add("score");
            header.add("amount");
            header.add("product");
            result.add(header);
            int len = 0;
            if (data.size()>15){
                len = 15;
            }else {
                len = data.size();
            }
            for (int i=0;i<len;i++){
                List<String> body = new ArrayList<>();
                Double padjust = -Math.log10(Double.parseDouble(data.get(i).getPadjust()));
                body.add(padjust.toString());
                body.add(data.get(i).getCount());
                body.add(data.get(i).getDescription());
                result.add(body);
            }
            map.put("data",result);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList[0]);
            return map;
        }
    }

    @RequestMapping("getPathwayKEGG")
    @ResponseBody
    public Map getPathwayKEGG(HttpServletRequest request) {
        Map map = new HashMap();
        List<List<String>> result = new ArrayList<>();
        int max = 0;
        int min = 10000;
        Double pvalueMax = 0.0;
        Double pvalueMin = 100.0;
        try{
            String sample = request.getParameter("sample");
            String padjustCut = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            PageHelper.clearPage();
            sample = sample + "_DEG_FunAnn";
            List<FunAnn> data = detail.getPathwayKEGG(sample,cluster,padjustCut);
            int len = 0;
            if (data.size()>15){
                len = 15;
            }else {
                len = data.size();
            }
            for (int i=0;i<len;i++){
                List<String> body = new ArrayList<>();
                Double pvalue = -Math.log10(Double.parseDouble(data.get(i).getPvalue()));
                body.add(data.get(i).getGeneRatio());
                body.add(data.get(i).getDescription());
                body.add(pvalue.toString());
                body.add(data.get(i).getCount());
                result.add(body);
                int countt = Integer.parseInt(data.get(i).getCount());
                if (countt>max){
                    max = countt;
                }
                if (countt<min){
                    min = countt;
                }
                if (pvalue>pvalueMax){
                    pvalueMax = pvalue;
                }
                if (pvalue<pvalueMin){
                    pvalueMin = pvalue;
                }
            }
            map.put("data",result);
            map.put("countMin",min);
            map.put("countMax",max);
            map.put("pValueMin",pvalueMin);
            map.put("pValueMax",pvalueMax);
            return map;
        }catch (Exception e){
            map.put("data",result);
            map.put("countMin",min);
            map.put("countMax",max);
            map.put("pValueMin",pvalueMin);
            map.put("pValueMax",pvalueMax);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getPathwayImmSignature")
    @ResponseBody
    public Map getPathwayImmSignature(HttpServletRequest request) {
        Map map = new HashMap();
        List<List<String>> result = new ArrayList<>();
        int max = 0;
        int min = 10000;
        Double pvalueMax = 0.0;
        Double pvalueMin = 100.0;
        try{
            String sample = request.getParameter("sample");
            String padjustCut = request.getParameter("count");
            String cluster = request.getParameter("cluster");
            PageHelper.clearPage();
            sample = sample + "_DEG_FunAnnC7";
            List<FunAnn> data = detail.getPathwayImmSignature(sample,cluster,padjustCut);
            int len = 0;
            if (data.size()>15){
                len = 15;
            }else {
                len = data.size();
            }
            for (int i=0;i<len;i++){
                List<String> body = new ArrayList<>();
                Double pvalue = -Math.log10(Double.parseDouble(data.get(i).getPvalue()));
                body.add(data.get(i).getGeneRatio());
                body.add(data.get(i).getDescription());
                body.add(pvalue.toString());
                body.add(data.get(i).getCount());
                result.add(body);
                int countt = Integer.parseInt(data.get(i).getCount());
                if (countt>max){
                    max = countt;
                }
                if (countt<min){
                    min = countt;
                }
                if (pvalue>pvalueMax){
                    pvalueMax = pvalue;
                }
                if (pvalue<pvalueMin){
                    pvalueMin = pvalue;
                }
            }
            map.put("data",result);
            map.put("countMin",min);
            map.put("countMax",max);
            map.put("pValueMin",pvalueMin);
            map.put("pValueMax",pvalueMax);
            return map;
        }catch (Exception e){
            map.put("data",result);
            map.put("countMin",min);
            map.put("countMax",max);
            map.put("pValueMin",pvalueMin);
            map.put("pValueMax",pvalueMax);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("cellChatInfo")
    @ResponseBody
    public PageTab cellChatInfo(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            sample = sample + "_CellChat_info";
            PageHelper.startPage(start / length + 1, length);
            Page<CellChatInfo> list = detail.cellChatInfo(sample,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<CellChatInfo> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("getpathwaycelltype")
    @ResponseBody
    public Map getpathwaycelltype(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            sample = sample + "_DEG_FunAnn";
            List<String> data = detail.getpathwaycelltype(sample);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("hdWGCNAumap")
    @ResponseBody
    public PageTab hdWGCNAumap(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            sample = sample + "_hdWGCNA_umap";
            PageHelper.startPage(start / length + 1, length);
            Page<HdWGCNAumap> list = detail.hdWGCNAumap(sample,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<HdWGCNAumap> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("hdWGCNA2")
    @ResponseBody
    public PageTab hdWGCNA2(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            sample = sample + "_hdWGCNA_graph2";
            PageHelper.startPage(start / length + 1, length);
            Page<HdWGCNA2> list = detail.hdWGCNA2(sample,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            Page<HdWGCNA2> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("sampleStatus")
    @ResponseBody
    public Map sampleStatus(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<NameValue> otherInfoStatus = detail.getOtherInfoStatus(sample+"_metadata3");
            List<NameValue> cellTypeStatus = detail.getCellTypeStatus(sample+"_metadata3");
            map.put("otherInfoStatus",otherInfoStatus);
            map.put("cellTypeStatus",cellTypeStatus);
            return map;
        }catch (Exception e){
            map.put("otherInfoStatus",new ArrayList<>());
            map.put("cellTypeStatus",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getSample")
    @ResponseBody
    public Map getSample(HttpServletRequest request) {
        Map map = new HashMap();
        List<NameValue> cellTypelist = new ArrayList<>();
        List<SampleUmap> list = new ArrayList<>();
        try{
            String sample = request.getParameter("sample");

            list = detail.getSample(sample+"_metadata3");
            cellTypelist = detail.getCellTypeAndFregBysample(sample+"_metadata3");
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            String[] disease_status = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
                disease_status[i] = list.get(i).getDisease_status();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("disease_status",disease_status);
            map.put("listofCelltypes",cellTypelist);
            return map;

        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("disease_status",new String[0]);
            map.put("listofCelltypes",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getUmapByCelltypeAndDisease")
    @ResponseBody
    public Map getUmapByCelltypeAndDisease(HttpServletRequest request) {
        Map map = new HashMap();
        List<NameValue> cellTypelist = new ArrayList<>();
        List<SampleUmap> list = new ArrayList<>();
        try{
            String sample = request.getParameter("sample");
            String chosenCelltype = request.getParameter("chosenCelltype");
            String disease_status = request.getParameter("disease_status");
            list = detail.getSampleByCelltypeAndDisease(sample+"_metadata3",chosenCelltype,disease_status);
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            String[] disease_statusarr = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
                disease_statusarr[i] = list.get(i).getDisease_status();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("disease_status",disease_statusarr);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("listofCelltypes",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getSample_ana")
    @ResponseBody
    public Map getSample_ana(HttpServletRequest request) {
        Map map = new HashMap();
        List<NameValue> cellTypelist = new ArrayList<>();
        List<SampleUmap> list = new ArrayList<>();
        try{
            String sample = request.getParameter("sample");
            String datatype = request.getParameter("datatype");
            if(datatype.contains("scATAC-seq")){
                list = detail.getSample_ATAC(sample+"_metadata");
                cellTypelist = detail.getCellTypeAndFregBysample(sample+"_metadata");
            }else {
                list = detail.getSample(sample+"_metadata3");
                cellTypelist = detail.getCellTypeAndFregBysample(sample+"_metadata3");
            }
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            String[] disease_status = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
                disease_status[i] = list.get(i).getDisease_status();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("disease_status",disease_status);
            map.put("listofCelltypes",cellTypelist);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("listofCelltypes",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getCelltype")
    @ResponseBody
    public Map getCelltype(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> cellType = detail.getCellTypeBysample(sample);
            map.put("cellType",cellType);
            return map;
        }catch (Exception e){
            map.put("cellType",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getPseudoData")
    @ResponseBody
    public Map getPseudoData(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<SampleUmap> list = detail.getPseudoData(sample+"_metadata3");
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] data = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                data[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getCytoTRACE2Data")
    @ResponseBody
    public Map getCytoTRACE2Data(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String method = request.getParameter("method");
            List<SampleUmap> list = detail.getCytoTRACE2Data(sample+"_CytoTRACE2",method);
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] data = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                data[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getCytoTRACE2Data_ATAC")
    @ResponseBody
    public Map getCytoTRACE2Data_ATAC(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String method = request.getParameter("method");
            List<SampleUmap> list = detail.getCytoTRACE2Data(sample+"_CytoTRACE2_ATAC",method);
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] data = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                data[i] = list.get(i).getCelltype();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getGeneList_atac")
    @ResponseBody
    public Map getGeneList_atac(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"scATAC_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_cicero_gene_activity.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList_atac(file)").asStrings();
            c.close();
            map.put("data",result);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getGeneList")
    @ResponseBody
    public Map getGeneList(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"ExpRDS_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+".rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList(file)").asStrings();
            c.close();
            map.put("data",result);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getProteinList")
    @ResponseBody
    public Map getProteinList(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"Protein_Data7/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_Protein.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList(file)").asStrings();
            c.close();
            map.put("data",result);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getProteinList_name")
    @ResponseBody
    public Map getProteinList_name(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        List<Genename> list = new ArrayList<>();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"Protein_Data7/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_Protein.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList(file)").asStrings();
            c.close();
            Genename name = null;
            for (int i=0;i<result.length;i++){
                name = new Genename();
                name.setName(result[i]);
                list.add(name);
            }
            System.out.println(name);
            System.out.println("name");
            map.put("data",list);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getProteinList_name_2")
    @ResponseBody
    public Map getProteinList_name_2(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        List<Genename> list = new ArrayList<>();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"Protein_Data7/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_Protein.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            String[] result = c.eval("result<-getGeneList(file)").asStrings();
            c.close();
            Genename name = null;
            for (int i=0;i<result.length;i++){
                name = new Genename();
                name.setName(result[i]);
                list.add(name);
            }
            map.put("data",list);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getGSMBySample")
    @ResponseBody
    public Map getGSMBySample(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.getGSMBySample(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("TRUST4getGSMBySample")
    @ResponseBody
    public Map TRUST4getGSMBySample(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.TRUST4getGSMBySample(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("getCelltype_BCR")
    @ResponseBody
    public Map getCelltype_BCR(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<String> list = detail.getCelltype_BCR(sample+"_metadata3");
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @GetMapping("detail")
    public ModelAndView detail(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String sample = request.getParameter("sample");
        mv.addObject("sample",sample);
        mv.setViewName("messages/detail");
        return mv;
    }


    @GetMapping("auto")
    public ModelAndView auto(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView();
        String sample = request.getParameter("sample");
        mv.addObject("sample",sample);
        mv.setViewName("messages/auto");
        return mv;
    }

    @RequestMapping("markerset")
    @ResponseBody
    public Map markerset(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            sample = sample + "_genename";
            String term = request.getParameter("term");
            List<Genename> list = detail.getmarkerset(sample);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }

    @RequestMapping("markerset_atac")
    @ResponseBody
    public Map markerset_atac(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            sample = sample + "_genename";
            String term = request.getParameter("term");
            List<Genename> list = detail.getmarkerset(sample);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("degTabBySamplename")
    @ResponseBody
    public PageTab degTabBySamplename(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
//        try {
            String searchValue = request.getParameter("search[value]");
            String sample = request.getParameter("sample");
            sample = sample + "_DEG";
            PageHelper.startPage(start / length + 1, length);
            Page<Deg> list = detail.degTab(sample,searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        /*} catch (Exception e) {
            Page<Deg> data = new Page<>();
            tabs.setData(data.getResult());
            tabs.setRecordsTotal((int) data.getTotal());
            tabs.setRecordsFiltered((int) data.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }*/
    }
}

