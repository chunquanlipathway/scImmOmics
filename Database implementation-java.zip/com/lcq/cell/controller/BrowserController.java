package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.mapper.Browser;
import com.lcq.cell.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BrowserController {
    @Autowired(required = false)
    private Browser browser;

    @RequestMapping("idenSignal")
    @ResponseBody
    public Map idenSignal(HttpServletRequest request) throws InterruptedException {
        BrowserParam param = new BrowserParam(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"), request.getParameter("biosampleTypeParam"), request.getParameter("tissueTypeParam"), request.getParameter("biosampleNameParam"));
        Map map = new HashMap();
        List<BrowseParamTotal> idenSignal = new ArrayList<>();
        try {
            idenSignal = browser.getIdenSignalParam(param);
            map.put("data", idenSignal);
            if (request.getParameter("idenSignalParam").equals("")){
                map.put("active", "");
            }else {
                map.put("active", "active");
            }
            return map;
        } catch (Exception e) {
            map.put("data", idenSignal);
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("dataSource")
    @ResponseBody
    public Map dataSource(HttpServletRequest request) throws InterruptedException {
        BrowserParam param = new BrowserParam(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"), request.getParameter("biosampleTypeParam"), request.getParameter("tissueTypeParam"), request.getParameter("biosampleNameParam"));
        Map map = new HashMap();
        List<BrowseParamTotal> dataSource = new ArrayList<>();
        try {
            dataSource = browser.getDataSourceParam(param);
            map.put("data", dataSource);
            if (request.getParameter("dataSourceParam").equals("")){
                map.put("active", "");
            }else {
                map.put("active", "active");
            }
            return map;
        } catch (Exception e) {
            map.put("data", dataSource);
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("biosampleType")
    @ResponseBody
    public Map biosampleType(HttpServletRequest request) throws InterruptedException {
        BrowserParam param = new BrowserParam(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"), request.getParameter("biosampleTypeParam"), request.getParameter("tissueTypeParam"), request.getParameter("biosampleNameParam"));
        Map map = new HashMap();

        List<BrowseParamTotal> biosampleType = new ArrayList<>();
        try {
            biosampleType = browser.getBiosampleTypeParam(param);
            map.put("data", biosampleType);
            if (request.getParameter("biosampleTypeParam").equals("")){
                map.put("active", "");
            }else {
                map.put("active", "active");
            }
            return map;
        } catch (Exception e) {
            map.put("data", biosampleType);
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("tissueType")
    @ResponseBody
    public Map tissueType(HttpServletRequest request) throws InterruptedException {
        BrowserParam param = new BrowserParam(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"), request.getParameter("biosampleTypeParam"), request.getParameter("tissueTypeParam"), request.getParameter("biosampleNameParam"));
        Map map = new HashMap();
        List<BrowseParamTotal> tissueType = new ArrayList<>();
        try {
            tissueType = browser.getTissueTypeParam(param);
            map.put("data", tissueType);
            if (request.getParameter("tissueTypeParam").equals("")){
                map.put("active", "");
            }else {
                map.put("active", "active");
            }
            return map;
        } catch (Exception e) {
            map.put("data", tissueType);
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }
    @RequestMapping("biosampleName")
    @ResponseBody
    public Map biosampleName(HttpServletRequest request) throws InterruptedException {
        BrowserParam param = new BrowserParam(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"), request.getParameter("biosampleTypeParam"), request.getParameter("tissueTypeParam"), request.getParameter("biosampleNameParam"));
        Map map = new HashMap();
        List<BrowseParamTotal> biosampleName = new ArrayList<>();
        try {
            biosampleName = browser.getBiosampleNameParam(param);
            map.put("data", biosampleName);
            if (request.getParameter("biosampleNameParam").equals("")){
                map.put("active", "");
            }else {
                map.put("active", "active");
            }
            return map;
        } catch (Exception e) {
            map.put("data", biosampleName);
            System.out.println("e.getMessage=" + e.getMessage());
            return map;
        }
    }

    @RequestMapping("browseTable")
    @ResponseBody
    public PageTab browseTable(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        PageTab tabs = new PageTab();
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        Page<BrowseTable> list = browser.getBrowseTable(request.getParameter("idenSignalParam"), request.getParameter("dataSourceParam"),request.getParameter("biosampleTypeParam"),request.getParameter("tissueTypeParam"),request.getParameter("biosampleNameParam"),searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
        try {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }

    @RequestMapping("browasedownload")
    @ResponseBody
    public PageTab browasedownload(Integer start, Integer draw, Integer length, HttpServletRequest request) throws InterruptedException {
        Map map = new HashMap();
        PageTab tabs = new PageTab();
        String searchValue = request.getParameter("search[value]");
        PageHelper.startPage(start / length + 1, length);
        Page<BrowseTable> list = browser.getBrowseTable("", "","","","",searchValue,request.getParameter("order[0][column]"),request.getParameter("order[0][dir]"));
        try {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            return tabs;
        } catch (Exception e) {
            tabs.setData(list.getResult());
            tabs.setRecordsTotal((int) list.getTotal());
            tabs.setRecordsFiltered((int) list.getTotal());
            tabs.setDraw(draw);
            System.out.println("e.getMessage=" + e.getMessage());
            return tabs;
        }
    }
}
