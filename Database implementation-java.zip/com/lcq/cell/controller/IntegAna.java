package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.AnalysisDao;
import com.lcq.cell.pojo.*;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class IntegAna {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private AnalysisDao analysis;

    @GetMapping("integ_ana")
    public ModelAndView integ_ana(HttpServletRequest request) {
        try{
            ModelAndView mv = new ModelAndView();
            String id = request.getParameter("id");
            String aidenSignal = request.getParameter("aidenSignal");
            String asapiens = request.getParameter("asapiens");
            String atissue = request.getParameter("atissue");
            String acelltype = request.getParameter("acelltype");
            String abiotype = request.getParameter("abiotype");
            String adisease = request.getParameter("adisease");
            String ridenSignal = request.getParameter("ridenSignal");
            String rsapiens = request.getParameter("rsapiens");
            String rtissue = request.getParameter("rtissue");
            String rcelltype = request.getParameter("rcelltype");
            String rbiotype = request.getParameter("rbiotype");
            String rdisease = request.getParameter("rdisease");
            List<BrowseTable> table = new ArrayList<>();
            BrowseTable rnaTable = new BrowseTable();
            rnaTable.setIdenSignal(ridenSignal);
            rnaTable.setSapiens(rsapiens);
            rnaTable.setTissue(rtissue);
            rnaTable.setBiosampleName(rcelltype);
            rnaTable.setBiosampleType(rbiotype);
            rnaTable.setDisease(rdisease);
            table.add(rnaTable);
            BrowseTable atacTable = new BrowseTable();
            atacTable.setIdenSignal(aidenSignal);
            atacTable.setSapiens(asapiens);
            atacTable.setTissue(atissue);
            atacTable.setBiosampleName(acelltype);
            atacTable.setBiosampleType(abiotype);
            atacTable.setDisease(adisease);
            table.add(atacTable);
            mv.addObject("id",id);
            mv.addObject("sampleinfo",table);
            mv.setViewName("messages/integ_detail");
            return mv;
        }catch (Exception e) {
            System.out.println(e.getMessage());
            ModelAndView mv = new ModelAndView();
            mv.addObject("error","error");
            mv.setViewName("messages/integ_detail");
            return mv;
        }
    }


    @RequestMapping("getSample_integana")
    @ResponseBody
    public Map getSample_integana(HttpServletRequest request) {
        Map map = new HashMap();
        List<NameValue> cellTypelist = new ArrayList<>();
        List<SampleUmap> list = new ArrayList<>();
        try{
            String sample = request.getParameter("sample");
            list = analysis.getSample(sample+"_metadata");
            cellTypelist = analysis.getCellTypeAndFregBysample(sample+"_metadata");
            int len = list.size();
            String[] x = new String[len];
            String[] y = new String[len];
            String[] cellType = new String[len];
            String[] disease_status = new String[len];
            for (int i=0;i<len;i++){
                x[i] = list.get(i).getX();
                y[i] = list.get(i).getY();
                cellType[i] = list.get(i).getCelltype();
                disease_status[i] = list.get(i).getDisease_status();
            }
            map.put("x",x);
            map.put("y",y);
            map.put("cellType",cellType);
            map.put("disease_status",disease_status);
            map.put("listofCelltypes",cellTypelist);
            return map;

        }catch (Exception e){
            map.put("x",new String[0]);
            map.put("y",new String[0]);
            map.put("cellType",new String[0]);
            map.put("disease_status",new String[0]);
            map.put("listofCelltypes",new String[0]);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getDiseaseBySampleID_integana")
    @ResponseBody
    public Map getDiseaseBySampleID_integana(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String table = sample + "_metadata";
            List<String> data = analysis.getDiseaseBySampleID_integana(table);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("data",new BrowseTable());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getExpression_integana")
    @ResponseBody
    public Map getExpression_integana(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath();
            String rdsfile = "";
            String filename = request.getParameter("sample");
            workPath = workPath + "ExpRDS_Data8/";
            rdsfile = workPath+filename+".rds";
            String gene = request.getParameter("gene");
            String getExpersion = path.getExpersionCodePath();
            if (gene==null)gene="";
            c.assign("file", rdsfile);
            c.assign("gene", gene.trim());
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            REXP result = c.eval("result<-getExpersion(file,gene)");
            double[] data = result.asDoubles();
            c.close();
            map.put("data",data);
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0]);
            return map;
        }
    }

    @RequestMapping("markerset_integana")
    @ResponseBody
    public Map markerset_integana(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            sample = sample + "_genename";
            String term = request.getParameter("term");
            List<Genename> list = analysis.getmarkerset_integana(sample);
            map.put("data",list);
            return map;
        }catch (Exception e){
            map.put("data",new ArrayList<>());
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getCorExp_integana")
    @ResponseBody
    public Map getCorExp_integana(HttpServletRequest request) throws RserveException, REXPMismatchException {
        Map map = new HashMap();
        RConnection c = new RConnection();
        try{
            String filename = request.getParameter("sample");
            String workPath = path.getWorkPath()+"CorExp_Data8/";
            String getExpersion = path.getExpersionCodePath();
            String rdsfile = workPath+filename+"_CorExp.rds";
            c.assign("file", rdsfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-getCorExp_integana(file)").asList();
            REXPDouble result1 = (REXPDouble) result.elementAt(0);
            double[][] array = result1.asDoubleMatrix();
            REXPString atac = (REXPString) result.elementAt(1);
            REXPString rna = (REXPString) result.elementAt(2);
            String[] ataccelltype = atac.asStrings();
            String[] rnacelltype = rna.asStrings();
            /*转换为echart格式*/
            double[][] arrayechart = new double[ataccelltype.length*rnacelltype.length][3];
            int k = 0;
            double min = 0;
            for (int i = 0; i < ataccelltype.length; i++) {
                for (int j = 0; j < rnacelltype.length; j++) {
                    double[] arr = new double[]{i, j, array[i][j]};
                    arrayechart[k] = arr;
                    k = k+1;
                    if (i==0&&j==0){
                        min = array[0][0];
                    }else {
                        if (array[i][j]<min){
                            min = array[i][j];
                        }
                    }
                }
            }
            map.put("data", arrayechart);
            map.put("min", min);
            map.put("celltypeatac", ataccelltype);
            map.put("celltyperna", rnacelltype);
            c.close();
            return map;
        }catch (Exception e){
            c.close();
            map.put("data",new String[0][0]);
            map.put("celltype",new String[0]);
            return map;
        }
    }

    @RequestMapping("getdataTypeData")
    @ResponseBody
    public Map getdataTypeData(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String dataTypeOption = request.getParameter("dataTypeOption");
            List<SampleUmap> list = new ArrayList<>();
            if (dataTypeOption.equals("ALL")){
                list = analysis.getdataTypeData(sample+"_metadata");
            }else {
                list = analysis.getdataTypeDataByType(sample+"_metadata",dataTypeOption);
            }
            map.put("data",list);
            return map;
        }catch (Exception e){
            List<SampleUmap> list = new ArrayList<>();
            map.put("data", list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getRnaData")
    @ResponseBody
    public Map getRnaData(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<SampleUmap> list = analysis.getRnaData(sample+"_metadata");
            map.put("data",list);
            return map;
        }catch (Exception e){
            List<SampleUmap> list = new ArrayList<>();
            map.put("data", list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @RequestMapping("getAtacData")
    @ResponseBody
    public Map getAtacData(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            List<SampleUmap> list = analysis.getAtacData(sample+"_metadata");
            map.put("data",list);
            return map;
        }catch (Exception e){
            List<SampleUmap> list = new ArrayList<>();
            map.put("data", list);
            map.put("error","Server exception, please try again later!");
            return map;
        }
    }


    @GetMapping("integAna")
    public ModelAndView integAna() {
        return new ModelAndView("messages/integAna");
    }

}

