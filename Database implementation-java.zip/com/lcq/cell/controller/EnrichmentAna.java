package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.AnalysisDao;
import com.lcq.cell.mapper.Browser;
import com.lcq.cell.pojo.*;
import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.*;

@Controller
public class EnrichmentAna {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private AnalysisDao analysisDao;

    @GetMapping("enrichmentAna")
    public ModelAndView enrichmentAna() {
        return new ModelAndView("messages/enrichmentAna");
    }

    @PostMapping("enrichmentAnaRun")
    public ModelAndView enrichmentAnaRun(MultipartFile file, HttpServletRequest request) throws IOException, REngineException, REXPMismatchException {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("messages/enrichmentAnaRun");
        /*获取参数*/
        String inputgenelist = request.getParameter("inputgenelist");
        String threshold = request.getParameter("threshold");
        String adjust = request.getParameter("adjust");

        RConnection c = new RConnection();
        try{
            String workPath = path.getWorkPath();
            String getExpersion = path.getExpersionCodePath();
            String bgfile = workPath+"geneset.RData";
            if (adjust=="on"){
                adjust = "1";
            }else {
                adjust = "0";
            }
            System.out.println(getExpersion);
            System.out.println(bgfile);
            System.out.println(adjust);
            System.out.println(threshold);
            c.assign("x", inputgenelist.split("\r\n"));
            c.assign("adjust", adjust);
            c.assign("threshold", threshold);
            c.assign("bgfile", bgfile);
            c.assign("getExpersion", getExpersion);
            c.eval("source(getExpersion)");
            RList result = c.eval("result<-enrichment(x,adjust,threshold,bgfile)").asList();
            REXPString col0 = (REXPString) result.get(0);
            REXPString col1 = (REXPString) result.get(1);
            REXPString col2 = (REXPString) result.get(2);
            REXPString col3 = (REXPString) result.get(3);
            REXPString col4 = (REXPString) result.get(4);
            REXPString col5 = (REXPString) result.get(5);
            REXPString col6 = (REXPString) result.get(6);
            REXPString col7 = (REXPString) result.get(7);
            REXPString col8 = (REXPString) result.get(8);
            REXPString col9 = (REXPString) result.get(9);
            REXPString col10 = (REXPString) result.get(10);
            REXPString col11 = (REXPString) result.get(11);
            REXPString col12 = (REXPString) result.get(12);
            REXPString col13 = (REXPString) result.get(13);
            REXPString col14 = (REXPString) result.get(14);
            REXPString col15 = (REXPString) result.get(15);
            c.close();
            List<String> c0 = Arrays.asList(col0.asStrings());
            List<String> c1 = Arrays.asList(col1.asStrings());
            List<String> c2 = Arrays.asList(col2.asStrings());
            List<String> c3 = Arrays.asList(col3.asStrings());
            List<String> c4 = Arrays.asList(col4.asStrings());
            List<String> c5 = Arrays.asList(col5.asStrings());
            List<String> c6 = Arrays.asList(col6.asStrings());
            List<String> c7 = Arrays.asList(col7.asStrings());
            List<String> c8 = Arrays.asList(col8.asStrings());
            List<String> c9 = Arrays.asList(col9.asStrings());
            List<String> c10 = Arrays.asList(col10.asStrings());
            List<String> c11 = Arrays.asList(col11.asStrings());
            List<String> c12 = Arrays.asList(col12.asStrings());
            List<String> c13 = Arrays.asList(col13.asStrings());
            List<String> c14 = Arrays.asList(col14.asStrings());
            List<String> c15 = Arrays.asList(col15.asStrings());
            List<EnrichmentResult> results = new ArrayList<>();
            EnrichmentResult obj = null;
            for (int i = 0; i < c0.size(); i++){
                obj = new EnrichmentResult();
                obj.setSample(c0.get(i));
                obj.setSapiens(c1.get(i));
                obj.setTissue(c2.get(i));
                obj.setDisease(c3.get(i));
                obj.setStatus(c4.get(i));
                obj.setPmid(c5.get(i));
                obj.setArticle(c6.get(i));
                obj.setJournal(c7.get(i));
                obj.setYear(c8.get(i));
                obj.setSource(c9.get(i));
                obj.setPlatform(c10.get(i));
                obj.setIntegrated_Type(c11.get(i));
                obj.setCelltype2(c12.get(i));
                obj.setGenes(c13.get(i));
                obj.setPvalue(c14.get(i));
                obj.setPadjust(c15.get(i));
                results.add(obj);
            }
            mv.addObject("enrichmentResult", results);
            return mv;
        }catch (Exception e){
            c.close();
            mv.addObject("data",new String[0]);
            List<EnrichmentResult> results = new ArrayList<>();
            mv.addObject("enrichmentResult", results);
            return mv;
        }
    }

}
