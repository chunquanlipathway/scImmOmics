package com.lcq.cell.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.lcq.cell.config.Path;
import com.lcq.cell.mapper.AnalysisDao;
import com.lcq.cell.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class AuCellAna {
    @Autowired
    private Path path;

    @Autowired(required = false)
    private AnalysisDao analysis;

    @RequestMapping("getCytokineInfo")
    @ResponseBody
    public Map getpathwaycelltype(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            List<Cytokine> data = analysis.getCytokineInfo();
            map.put("data",data);
            return map;
        }catch (Exception e){
            List<NameValue> data = new ArrayList<NameValue>();
            map.put("error","Server exception, please try again later!");
            map.put("data",data);
            return map;
        }
    }

    @RequestMapping("getSpiensAna")
    @ResponseBody
    public Map getSpiensAna(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String cytokines = request.getParameter("cytokines");
            List<String> data = analysis.getSpiensAnaByCytokine(cytokines.split(","));
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getTissueBySapien")
    @ResponseBody
    public Map getTissueBySapien(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sapien = request.getParameter("sapien");
            String cytokines = request.getParameter("cytokines");
            List<String> data = analysis.getTissueBySapienAndCytokine(sapien,cytokines.split(","));
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getFamilyBysampleAndCytokine")
    @ResponseBody
    public Map getFamilyBysampleAndCytokine(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String cytokine = request.getParameter("cytokine");
            List<String> data = analysis.getFamilyBysampleAndCytokine(sample,cytokine.split(","));
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getCytokineBysampleAndCytokine")
    @ResponseBody
    public Map getCytokineBysampleAndCytokine(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String family = request.getParameter("family");
            String cytokine = request.getParameter("cytokine");
            List<String> data = analysis.getCytokineBysampleAndCytokine(sample,family,cytokine.split(","));
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getAuCellBoxBySampleAndCytokine")
    @ResponseBody
    public Map getAuCellBoxBySampleAndCytokine(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String cytokine = request.getParameter("cytokine");
            String table = sample+"_"+cytokine+"_AUCell";
            List<NameValue> data = analysis.getAuCellBoxBySampleAndCytokine(table);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            List<NameValue> data = new ArrayList<>();
            map.put("data",data);
            return map;
        }
    }

    @RequestMapping("bubbleAucellImg")
    @ResponseBody
    public Map bubbleAucellImg(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String table = sample+"_Cytokine_AUCell_Bubble";
            List<AUCell_Bubble> data = analysis.bubbleAucellImg(table);
            List<List<String>> result = new ArrayList<>();
            for (int i=0;i<data.size();i++){
                List<String> body = new ArrayList<>();
                body.add(data.get(i).getCytokine());
                body.add(data.get(i).getCelltype2());
                body.add(data.get(i).getAucell_mean());
                body.add(data.get(i).getCelltype2_DiffValue());
                result.add(body);
            }
            map.put("data",result);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            List<List<String>> result = new ArrayList<>();
            map.put("data",result);
            return map;
        }
    }

    @RequestMapping("getSampleBySapienAndTissue")
    @ResponseBody
    public Map getSampleBySapienAndTissue(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sapien = request.getParameter("sapien");
            String tissue = request.getParameter("tissue");
            String cytokines = request.getParameter("cytokines");
            List<String> data = analysis.getSampleBySapienAndTissueCytokine(sapien,tissue,cytokines.split(","));
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

//    @GetMapping("aucellAnaGo")
    @PostMapping("aucellAnaGo")
    ModelAndView aucellAnaGo(HttpServletRequest request,@RequestParam(value = "select", required = false) List<String> cytokines,
                             @RequestParam(value = "sapien", required = false) String sapien,
                             @RequestParam(value = "tissue", required = false) String tissue,
                             @RequestParam(value = "bioSelect", required = false) String sample) {
        ModelAndView mv = new ModelAndView();
        String result = String.join(",", cytokines);
        List<String> data = analysis.getCytokineBySampleAndCytokine(sample,result.split(","));
        String cytokinesdata = String.join(",", data);
        mv.setViewName("messages/aucellAnaGo");
        mv.addObject("sapien",sapien);
        mv.addObject("tissue",tissue);
        mv.addObject("sample",sample);
        mv.addObject("cytokines",cytokinesdata);
        return mv;
    }

    @RequestMapping("cytokineFun")
    @ResponseBody
    public Map cytokineFun(HttpServletRequest request) {
        Map map = new HashMap();
        try{
            String sample = request.getParameter("sample");
            String cytokine = request.getParameter("cytokine");
            String table = sample+"_"+cytokine+"_AUCell";
            List<String> data = analysis.cytokineFun(table);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",new ArrayList<>());
            return map;
        }
    }

    @RequestMapping("getAuCellUmap")
    @ResponseBody
    public Map getAuCellUmap(HttpServletRequest request) {
        Map map = new HashMap();
        List<String> x = new ArrayList<>();
        List<String> y = new ArrayList<>();
        List<String> v = new ArrayList<>();
        try{
            String sample = request.getParameter("sample");
            String cytokine = request.getParameter("cytokine");
            String celltype = request.getParameter("celltype");
            String table = sample+"_"+cytokine+"_AUCell";
            List<AUCellUmap> data = analysis.getAuCellUmap(table,celltype);
            for (int i=0;i<data.size();i++){
                x.add(data.get(i).getAxis_x());
                y.add(data.get(i).getAxis_y());
                v.add(data.get(i).getAucell());
            }
            map.put("x",x);
            map.put("y",y);
            map.put("v",v);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("x",x);
            map.put("y",y);
            map.put("v",v);
            return map;
        }
    }

    @RequestMapping("sampletabGetSample")
    @ResponseBody
    public Map sampletabGetSample(HttpServletRequest request) {
        Map map = new HashMap();
        BrowseTable data = new BrowseTable();
        try{
            String sample = request.getParameter("sample");
            data = analysis.sampletabGetSample(sample);
            map.put("data",data);
            return map;
        }catch (Exception e){
            map.put("error","Server exception, please try again later!");
            map.put("data",data);
            return map;
        }
    }

}

