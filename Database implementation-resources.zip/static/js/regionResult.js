function enBySampleregion(sampleid,chrome,start,end,checkh3k4me3) {
    $('#enhancerTab').DataTable({
        ajax: {
            url: "enBySampleRegion",
            type: "GET",
            async: true,
            data: {"sampleid": sampleid,"chrome":chrome,"start2":start,"end":end, "checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "logpvalue"},
            {"data": "interaction"},
            {"data": "methy450K"},
            {"data": "commonsnp"},
            {"data": "crisps"},
            {"data": "enhancer"},
            {"data": "eqtl"},
            {"data": "gwas"},
            {"data": "tad"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg38&lastVirtModeType=default&lastVirtModeExtraState=&virtModeType=default&virtMode=0&nonVirtPosition=&position="+row.chrome+"%3A"+row.start+"%2D"+row.end+"&hgsid=1334138285_q3d2baKSxBnqflr14dK9CRYkDtfA'>" + "UCSC</a>|<a>ENID"+"</a>";
                }
            }
        ],
        columnDefs:[{"orderable":false,"targets":4}],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}

function graph(sampleid,chrome,start,end,checkh3k4me3) {
    var chartDom = document.getElementById('main');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "chrPieByRegion",
        type: "get",
        data: {"sampleid": sampleid,"chrome":chrome,"start":start,"end":end,"checkh3k4me3":checkh3k4me3},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                title: {
                    text: '',
                    subtext: '',
                    left: 'center'
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left'
                },
                series: [
                    {
                        name: 'chrome number',
                        type: 'pie',
                        radius: '50%',
                        left: '20%',
                        data: res.data,
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}