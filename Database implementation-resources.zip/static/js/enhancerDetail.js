var olanguage = {
    // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
    "sProcessing": 'processing......',
    "loadingRecords": "Loading...",
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function celllineHeatmap(enid,peak) {
    $.ajax({
        url: "celllineHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            genes = res.genes;
            console.log(genes)
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["A549","AG04450","BE2C","BJ","GM12878","GM23248","GM23338","H1-hESC","HeLa-S3","HT1080","HUES64","IMR-90","Jurkat clone E61","K562","MCF-7","Panc1","PFSK-1","SK-MEL-5","U-87 MG","UCSF-4","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_cell', data, layout, config);
        },
        dataType: "json"
    });
}
function vitroHeatmap(enid,peak) {
    $.ajax({
        url: "vitroHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            console.log(res)
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["cardiac muscle cell","ectodermal cell","hepatocyte","mesenchymal stem cell","mesendoderm","mesodermal cell","neural stem progenitor cell","smooth muscle cell","trophoblast cell"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_vitro', data, layout, config);
        },
        dataType: "json"
    });
}
function primaryHeatmap(enid,peak) {
    $.ajax({
        url: "primaryHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["astrocyte","B cell","CD14-positive monocyte","CD4-positive, alpha-beta T cell","common myeloid progenitor, CD34-positive","endothelial cell of umbilical vein","fibroblast of breast","fibroblast of lung","foreskin fibroblast","foreskin keratinocyte","foreskin melanocyte","keratinocyte","luminal epithelial cell of mammary gland","mammary epithelial cell","mammary stem cell","myoepithelial cell of mammary gland","natural killer cell","neurosphere","peripheral blood mononuclear cell","Purkinje cell","skin fibroblast","T-cell","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_primary', data, layout, config);
        },
        dataType: "json"
    });
}
function gtexHeatmap(enid,peak) {
    $.ajax({
        url: "gtexHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["Adipose Tissue","Adrenal Gland","Blood Vessel","Bladder","Brain","Breast","Blood","Skin","Cervix Uteri","Colon","Esophagus","Fallopian Tube","Heart","Kidney","Liver","Lung","Salivary Gland","Muscle","Nerve","Ovary","Pancreas","Pituitary","Prostate","Small Intestine","Spleen","Stomach","Testis","Thyroid","Uterus","Vagina","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_gtex', data, layout, config);
        },
        dataType: "json"
    });
}
function ccleHeatmap(enid,peak) {
    $.ajax({
        url: "ccleHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["prostate","stomach","urinary_tract","glioma","ovary","leukemia_other","kidney","thyroid","melanoma","soft_tissue","upper_aerodigestive","lymphoma_DLBCL","lung_NSC","Ewings_sarcoma","mesothelioma","T.cell_ALL","AML","multiple_myeloma","endometrium","pancreas","breast","B.cell_lymphoma_other","B.cell_ALL","lymphoma_Burkitt","CML","colorectal","chondrosarcoma","meningioma","neuroblastoma","lung_small_cell","esophagus","medulloblastoma","T.cell_lymphoma_other","fibroblast_like","osteosarcoma","lymphoma_Hodgkin","cervix","liver","giant_cell_tumour","bile_duct","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_ccle', data, layout, config);
        },
        dataType: "json"
    });
}
function tcgaHeatmap(enid,peak) {
    $.ajax({
        url: "tcgaHeatmap",
        type: "get",
        data: {"enid": enid, "peak": peak},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["ACC","BLCA","CESC","CHOL","COAD","DLBC","ESCA","GBM","HNSC","KICH","KIRC","KIRP","LGG","LIHC","LUAD","LUSC","MESO","NBL","OV","PAAD","PCPG","PRAD","READ","SARC","SKCM","STAD","TGCT","THCA","THYM","UCEC","UCS","UVM","WT","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of E_' + enid + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('cancer_tcga', data, layout, config);
        },
        dataType: "json"
    });
}

function enhancerByOverlap(peak,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabByOverlap",
            type: "GET",
            async: true,
            data: {"peak":peak,"signal":singal}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "tissueType"},
            {
                "data": "biosampleName",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid+ "'>" + row.biosampleName + "</a>";
                }
            },
            {"data": "logpvalue"}
        ],
        oLanguage: olanguage
    });
}

function enhancercrmsByOverlap(peak,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabcrmsByOverlap",
            type: "GET",
            async: true,
            data: {"peak":peak,"signal":singal}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "tfs"},
            {"data": "numbers"}
        ],
        oLanguage: olanguage
    });
}

function force_graph(enid,peak,strategies,threshold) {
    var chartDom = document.getElementById('force');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "force_graph",
        type: "get",
        data: {"enid": enid, "peak": peak, "strategies": strategies, "threshold": threshold},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                legend: [
                    {
                        data: res.categories.map(function (a) {
                            return a.name;
                        })
                    }
                ],
                color:['#5470c6','#e91e63','#fac858','#ffd454','#ffa361','#d1d1d1'],
                series: [
                    {
                        name: 'Les Miserables',
                        type: 'graph',
                        layout: 'none',
                        data: res.nodes,
                        links: res.links,
                        categories: res.categories,
                        roam: true,
                        label: {
                            show: true,
                            position: 'right',
                            formatter: '{b}'
                        },
                        labelLayout: {
                            hideOverlap: true
                        },
                        itemStyle: {
                            normal: {
                                borderColor: '#fff',
                                borderWidth: 1,
                                shadowBlur: 10,
                                shadowColor: 'rgba(0, 0, 0, 0.3)'
                            }
                        },
                        emphasis: {
                            focus: 'adjacency',
                            lineStyle: {
                                width: 10
                            }
                        },
                        scaleLimit: {
                            min: 0.4,
                            max: 0.9
                        },
                        lineStyle: {
                            color: '#c2c2c2',
                            curveness: 0
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function count_graph(enid) {
    var chartDom = document.getElementById('count');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "count_graph",
        type: "get",
        data: {"enid": enid},
        async: true,
        success: function (res) {

            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    top: '3%',
                    left: '3%',
                    right: '5%',
                    bottom: '2%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLabel:{
                        interval: 0, rotate: 30
                    },
                    data: ['Interaction', 'methy450K', 'CommonSNP', 'Crisp/Cas9', 'Enhancer', 'eQTL', 'GWAS', 'TAD']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        data: [res.count.interaction, res.count.methy450K, res.count.commonsnp, res.count.crisps, res.count.enhancer, res.count.eqtl, res.count.gwas, res.count.tad],
                        type: 'line'
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}


function count_graphdemo() {
    var chartDom = document.getElementById('countdemo');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    myChart.hideLoading();

    /*diskData=[
        {
            "value": 10,
            "name": "Signals",
            "path": "Signals",
            "children": [
                {
                    "value": 1730,
                    "name": "H3K27ac",
                    "path": "Signals/H3K27ac",
                    "children": [
                        {
                            "value": 1560,
                            "name": "NCBI",
                            "path": "Signals/H3K27ac/NCBI"
                        },
                        {
                            "value": 100,
                            "name": "ENCODE",
                            "path": "Signals/H3K27ac/ENCODE"
                        },
                        {
                            "value": 55,
                            "name": "Roadmap",
                            "path": "Signals/H3K27ac/Roadmap"
                        },
                        {
                            "value": 14,
                            "name": "GGR",
                            "path": "Signals/H3K27ac/GGR"
                        },
                        {
                            "value": 10,
                            "name": "NGDC GSA",
                            "path": "Signals/H3K27ac/NGDC GSA"
                        }
                    ]
                },
                {
                    "value": 495,
                    "name": "H3K4me1",
                    "path": "Signals/H3K4me1",
                    "children": [
                        {
                            "value": 402,
                            "name": "NCBI",
                            "path": "Signals/H3K4me1/NCBI"
                        },
                        {
                            "value": 53,
                            "name": "ENCODE",
                            "path": "Signals/H3K4me1/ENCODE"
                        },
                        {
                            "value": 38,
                            "name": "Roadmap",
                            "path": "Signals/H3K4me1/Roadmap"
                        },
                        {
                            "value": 2,
                            "name": "GGR",
                            "path": "Signals/H3K4me1/GGR"
                        }
                    ]
                },
                {
                    "value": 1163,
                    "name": "H3K4me3",
                    "path": "Signals/H3K4me3",
                    "children": [
                        {
                            "value": 950,
                            "name": "NCBI",
                            "path": "Signals/H3K4me3/NCBI"
                        },
                        {
                            "value": 213,
                            "name": "ENCODE",
                            "path": "Signals/H3K4me3/ENCODE"
                        }
                    ]
                },
                {
                    "value": 2493,
                    "name": "ATAC-seq",
                    "path": "Signals/ATAC-seq",
                    "children": [
                        {
                            "value": 1493,
                            "name": "NCBI",
                            "path": "Signals/ATAC-seq/NCBI"
                        }
                    ]
                },
                {
                    "value": 1261,
                    "name": "DNase-seq",
                    "path": "Signals/DNase-seq",
                    "children": [
                        {
                            "value": 1261,
                            "name": "NCBI",
                            "path": "Signals/DNase-seq/NCBI"
                        }
                    ]
                },
                {
                    "value": 82,
                    "name": "MNase-seq",
                    "path": "Signals/MNase-seq",
                    "children": [
                        {
                            "value": 82,
                            "name": "NCBI",
                            "path": "Signals/MNase-seq/NCBI"
                        }
                    ]
                },
                {
                    "value": 37,
                    "name": "STARR-seq",
                    "path": "Signals/STARR-seq",
                    "children": [
                        {
                            "value": 4,
                            "name": "NCBI",
                            "path": "Signals/STARR-seq/NCBI"
                        },
                        {
                            "value": 33,
                            "name": "TRANSCRIPTOMIC",
                            "path": "Signals/STARR-seq/TRANSCRIPTOMIC"
                        }
                    ]
                },
                {
                    "value": 264,
                    "name": "FAIRE-seq",
                    "path": "Signals/FAIRE-seq",
                    "children": [
                        {
                            "value": 264,
                            "name": "NCBI",
                            "path": "Signals/FAIRE-seq/NCBI"
                        }
                    ]
                },
                {
                    "value": 198,
                    "name": "EP300",
                    "path": "Signals/EP300",
                    "children": [
                        {
                            "value": 187,
                            "name": "NCBI",
                            "path": "Signals/EP300/NCBI"
                        },
                        {
                            "value": 11,
                            "name": "GGR",
                            "path": "Signals/EP300/GGR"
                        }
                    ]
                },
                {
                    "value": 1067,
                    "name": "POLR2A",
                    "path": "Signals/POLR2A",
                    "children": [
                        {
                            "value": 1048,
                            "name": "NCBI",
                            "path": "Signals/POLR2A/NCBI"
                        },
                        {
                            "value": 17,
                            "name": "ENCODE",
                            "path": "Signals/POLR2A/ENCODE"
                        },
                        {
                            "value": 2,
                            "name": "TRANSCRIPTOMIC",
                            "path": "Signals/POLR2A/TRANSCRIPTOMIC"
                        }
                    ]
                }
            ]
        },
        {
            "value": 14,
            "name": "Annotated",
            "path": "Annotated",
            "children": [
                {
                    "value": 1,
                    "name": "Common SNP",
                    "path": "Annotated/Common SNP"
                },
                {
                    "value": 1,
                    "name": "eQTL",
                    "path": "Annotated/eQTL"
                },
                {
                    "value": 1,
                    "name": "Risk SNP",
                    "path": "Annotated/Risk SNP"
                },
                {
                    "value": 1,
                    "name": "LD SNP",
                    "path": "Annotated/LD SNP"
                },
                {
                    "value": 1,
                    "name": "CRISPR-cas9",
                    "path": "Annotated/CRISPR-cas9"
                },
                {
                    "value": 1,
                    "name": "Motif TF",
                    "path": "Annotated/Motif TF"
                },
                {
                    "value": 1,
                    "name": "DHS",
                    "path": "Annotated/DHS"
                },
                {
                    "value": 1,
                    "name": "3D Interaction",
                    "path": "Annotated/3D Interaction"
                },
                {
                    "value": 1,
                    "name": "TAD",
                    "path": "Annotated/TAD"
                },
                {
                    "value": 1,
                    "name": "ChromHMM",
                    "path": "Annotated/ChromHMM"
                },
                {
                    "value": 1,
                    "name": "Enhancer",
                    "path": "Annotated/Enhancer"
                },
            ]
        },
        {
            "value": 10,
            "name": "Gene",
            "path": "Gene",
            "children": [
                {
                    "value": 1,
                    "name": "Closest gene",
                    "path": "Gene/Closest gene"
                },
                {
                    "value": 1,
                    "name": "Proximal gene",
                    "path": "Gene/Proximal gene"
                },
                {
                    "value": 1,
                    "name": "Overlap gene",
                    "path": "Gene/Overlap gene"
                },
                {
                    "value": 1,
                    "name": "Pancan-meQTL gene",
                    "path": "Gene/Pancan-meQTL gene"
                },
                {
                    "value": 1,
                    "name": "GWAS gene",
                    "path": "Gene/GWAS gene"
                },
                {
                    "value": 1,
                    "name": "GTEx gene",
                    "path": "Gene/GTEx gene"
                },
                {
                    "value": 1,
                    "name": "EnhancerDB gene",
                    "path": "Gene/EnhancerDB gene"
                },
                {
                    "value": 1,
                    "name": "ENDB gene",
                    "path": "Gene/ENDB gene"
                },
                {
                    "value": 1,
                    "name": "HANCER FANTOM5 gene",
                    "path": "Gene/HANCER FANTOM5 gene"
                },
                {
                    "value": 1,
                    "name": "HANCER 4DGenome gene",
                    "path": "Gene/HANCER 4DGenome gene"
                }
            ]
        },
        {
            "value": 4,
            "name": "Expression",
            "path": "Expression",
            "children": [
                {
                    "value": 1,
                    "name": "ENCODE",
                    "path": "Expression/ENCODE",
                    "children": [
                        {
                            "value": 1,
                            "name": "Cell line",
                            "path": "Expression/ENCODE/Cell line"
                        },
                        {
                            "value": 1,
                            "name": "In vitro differentiated cell",
                            "path": "Expression/ENCODE/In vitro differentiated cell"
                        },
                        {
                            "value": 1,
                            "name": "Proximal cell",
                            "path": "Expression/ENCODE/Primary cell"
                        },
                    ]
                },
                {
                    "value": 1,
                    "name": "GTEx",
                    "path": "Expression/GTEx"
                },
                {
                    "value": 1,
                    "name": "CCLE",
                    "path": "Expression/CCLE"
                },
                {
                    "value": 1,
                    "name": "TCGA",
                    "path": "Expression/TCGA"
                }
            ]
        },
        {
            "value": 1,
            "name": "Diseases",
            "path": "Diseases"
        },
        {
            "value": 3,
            "name": "Other",
            "path": "Other",
            "children": [
                {
                    "value": 1,
                    "name": "Pathway",
                    "path": "Other/Pathway"
                },
                {
                    "value": 1,
                    "name": "Go term",
                    "path": "Other/Go term"
                },
                {
                    "value": 1,
                    "name": "Hall mark",
                    "path": "Other/Hall Mark"
                }
            ]
        }
    ]
    myChart.hideLoading();
    const formatUtil = echarts.format;
    function getLevelOption() {
        return [
            {
                itemStyle: {
                    borderWidth: 0,
                    gapWidth: 5
                }
            },
            {
                itemStyle: {
                    gapWidth: 1
                }
            },
            {
                colorSaturation: [0.35, 0.5],
                itemStyle: {
                    gapWidth: 1,
                    borderColorSaturation: 0.6
                }
            }
        ];
    }
    option = {
            title: {
                text: 'Disk Usage',
                left: 'center'
            },
            toolbox: {
                show: true,
                feature: {
                    saveAsImage: {title:"save"}
                }
            },
            tooltip: {
                formatter: function (info) {
                    var value = info.value;
                    var treePathInfo = info.treePathInfo;
                    var treePath = [];
                    for (var i = 1; i < treePathInfo.length; i++) {
                        treePath.push(treePathInfo[i].name);
                    }
                    return [
                        '<div class="tooltip-title">' +
                        formatUtil.encodeHTML(treePath.join('/')) +
                        '</div>',
                        'Disk Usage: ' + formatUtil.addCommas(value) + ' KB'
                    ].join('');
                }
            },
            series: [
                {
                    name: 'Disk Usage',
                    type: 'treemap',
                    visibleMin: 300,
                    label: {
                        show: true,
                        formatter: '{b}'
                    },
                    itemStyle: {
                        borderColor: '#fff'
                    },
                    levels: getLevelOption(),
                    data: diskData
                }
            ]
        }
*/


    /*const hours = [
        'UCSF-4','U-87-MG','SK-MEL-5','PFSK-1','Panc1','MCF-7','K562','Jurkat-clone-E61','IMR-90','HUES64','HT1080','HeLa-S3','H1-hESC','GM23338','GM23248','GM12878','BJ','BE2C','AG04450','A549'
    ];
    const days = [
        'TSPAN1', 'TRIM8', 'TRIM16',
        'TMED7','TMC7','TMC5','TLR6','TK2',
        'TIPIN','THSD4','TGM2','TGIF'
    ];
    const data = [[0, 0, 5], [0, 1, 1], [0, 2, 0], [0, 3, 3], [0, 4, 0], [0, 5, 0], [0, 6, 1],
        [0, 7, 0], [0, 8, 0], [0, 9, 0], [0, 10, 0], [0, 11, 2], [0, 12, 4], [0, 13, 1], [0, 14, 1],
        [0, 15, 3], [0, 16, 4], [0, 17, 6], [0, 18, 4], [0, 19, 4], [0, 20, 3], [0, 21, 3], [0, 22, 2],
        [0, 23, 5], [1, 0, 7], [1, 1, 0], [1, 2, 0], [1, 3, 0], [1, 4, 1], [1, 5, 0], [1, 6, 0], [1, 7, 1],
        [1, 8, 0], [1, 9, 0], [1, 10, 5], [1, 11, 2], [1, 12, 2], [1, 13, 6], [1, 14, 9], [1, 15, 11],
        [1, 16, 6], [1, 17, 7], [1, 18, 8], [1, 19, 12], [1, 20, 5], [1, 21, 5], [1, 22, 7], [1, 23, 2],
        [2, 0, 1], [2, 1, 1], [2, 2, 0], [2, 3, 0], [2, 4, 0], [2, 5, 0], [2, 6, 1], [2, 7, 0], [2, 8, 0],
        [2, 9, 0], [2, 10, 3], [2, 11, 2], [2, 12, 1], [2, 13, 9], [2, 14, 8], [2, 15, 10], [2, 16, 6],
        [2, 17, 5], [2, 18, 5], [2, 19, 5], [2, 20, 7], [2, 21, 4], [2, 22, 2], [2, 23, 4], [3, 0, 7],
        [3, 1, 3], [3, 2, 0], [3, 3, 0], [3, 4, 0], [3, 5, 0], [3, 6, 0], [3, 7, 0], [3, 8, 1], [3, 9, 0],
        [3, 10, 5], [3, 11, 4], [3, 12, 7], [3, 13, 14], [3, 14, 13], [3, 15, 12], [3, 16, 9], [3, 17, 5],
        [3, 18, 5], [3, 19, 10], [3, 20, 6], [3, 21, 4], [3, 22, 4], [3, 23, 1], [4, 0, 1], [4, 1, 3],
        [4, 2, 0], [4, 3, 0], [4, 4, 0], [4, 5, 1], [4, 6, 0], [4, 7, 0], [4, 8, 0], [4, 9, 2], [4, 10, 4],
        [4, 11, 4], [4, 12, 2], [4, 13, 4], [4, 14, 4], [4, 15, 14], [4, 16, 12], [4, 17, 1], [4, 18, 8],
        [4, 19, 5], [4, 20, 3], [4, 21, 7], [4, 22, 3], [4, 23, 0], [5, 0, 2], [5, 1, 1], [5, 2, 0], [5, 3, 3],
        [5, 4, 0], [5, 5, 0], [5, 6, 0], [5, 7, 0], [5, 8, 2], [5, 9, 0], [5, 10, 4], [5, 11, 1], [5, 12, 5],
        [5, 13, 10], [5, 14, 5], [5, 15, 7], [5, 16, 11], [5, 17, 6], [5, 18, 0], [5, 19, 5], [5, 20, 3],
        [5, 21, 4], [5, 22, 2], [5, 23, 0], [6, 0, 1], [6, 1, 0], [6, 2, 0], [6, 3, 0], [6, 4, 0], [6, 5, 0],
        [6, 6, 0], [6, 7, 0], [6, 8, 0], [6, 9, 0], [6, 10, 1], [6, 11, 0], [6, 12, 2], [6, 13, 1], [6, 14, 3],
        [6, 15, 4], [6, 16, 0], [6, 17, 0], [6, 18, 0], [6, 19, 0], [6, 20, 1], [6, 21, 2], [6, 22, 2], [6, 23, 6],
        [7,0,2],[7,1,3],[7,2,5],[7,3,1],[7,4,1],[7,5,2],[7,6,1],[7,7,3],[7,8,2],[7,9,4],[7,10,1],[7,11,2],[7,12,3],
        [7,13,1],[7,14,2],[7,15,5],[7,16,3],[7,17,2],[7,18,2],[7,19,3],
        [8,0,1],[8,1,0],[8,2,2],[8,3,1],[8,4,2],[8,5,2],[8,6,1],[8,7,1],[8,8,0],[8,9,2],[8,10,2],[8,11,0],[8,12,1],
        [8,13,0],[8,14,0],[8,15,1],[8,16,2],[8,17,1],[8,18,0],[8,19,2],
        [9,0,0],[9,1,1],[9,2,1],[9,3,2],[9,4,3],[9,5,1],[9,6,0],[9,7,2],[9,8,1],[9,9,0],[9,10,1],[9,11,3],[9,12,2],
        [9,13,5],[9,14,2],[9,15,8],[9,16,2],[9,17,3],[9,18,5],[9,19,0],
        [10,0,3],[10,1,2],[10,2,8],[10,3,0],[10,4,1],[10,5,3],[10,6,2],[10,7,0],[10,8,1],[10,9,4],[10,10,4],[10,11,2],[10,12,3],
        [10,13,1],[10,14,2],[10,15,8],[10,16,10],[10,17,4],[10,18,2],[10,19,3],
        [11,0,2],[11,1,0],[11,2,3],[11,3,1],[11,4,0],[11,5,6],[11,6,5],[11,7,1],[11,8,3],[11,9,2],[11,10,1],[11,11,4],[11,12,5],
        [11,13,2],[11,14,7],[11,15,4],[11,16,9],[11,17,1],[11,18,4],[11,19,7]]
        .map(function (item) {
            return [item[1], item[0], item[2] || '-'];
        });
    option = {
        tooltip: {
            position: 'top'
        },
        grid: {
            height: '50%',
            top: '10%'
        },
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        xAxis: {
            type: 'category',
            data: hours,
            splitArea: {
                show: true
            },
            axisLabel: {
                interval: 0,
                rotate: 90,
                //倾斜度 -90 至 90 默认为0
                margin: 8,
                textStyle: {
                    fontWeight: "bolder",
                    color: "#999999"
                }
            }
        },
        yAxis: {
            type: 'category',
            data: days,
            splitArea: {
                show: true
            }
        },
        visualMap: {
            min: 0,
            max: 10,
            calculable: true,
            orient: 'horizontal',
            left: 'center',
            bottom: '15%',
            inRange:{color:['#ffffff','#e91e63']}
        },
        series: [
            {
                name: 'Punch Card',
                type: 'heatmap',
                data: data,
                label: {
                    show: false
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };*/


    option = {
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        xAxis: {
            type: 'category',
            data: ['H3K27ac', 'H3K4me1', 'ATAC-seq', 'DNase-seq', 'MNase-seq', 'FAIRE-seq', 'STARR-seq', 'POLR2A', 'EP300','H3K4me3']
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                data: [1730, 495, 2493, 1263, 82, 264, 37, 1067, 198, 1163],
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(180, 180, 180, 0.2)'
                }
            }
        ]
    };


    /*option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        grid: {
            top: '3%',
            left: '3%',
            right: '5%',
            bottom: '2%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            axisLabel:{
                interval: 0, rotate: 30
            },
            data: ['Interaction', 'CRISP/Case9', 'Common SNP', 'methy450K', 'Other Enhancer', 'eQTL', 'GWAS','TAD','ChromHMM','Motif','DHS','Risk SNP'],
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                data: [28, 13, 15, 3, 1, 5, 2, 6,8,9,19,10],
                markPoint: {
                    data: [
                        { type: 'max', name: 'Max' },
                        { type: 'min', name: 'Min' }
                    ]
                },
                markLine: {
                    data: [{ type: 'average', name: 'Avg' }]
                },
                type: 'line'
            }
        ]
    };*/
    option && myChart.setOption(option);
}



function roseGene(enid,peak) {
    var chartDom = document.getElementById('main');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;

    $.ajax({
        url: "roseGene",
        type: "get",
        data: {"enid": enid,"peak":peak},
        async: true,
        success: function (res) {
            //左侧gene table 展示
            var overlapHtml = "";
            var proximalHtml = "";
            var closestHtml = "";
            var pancanmeqtlHtml = "";
            var gwasHtml = "";
            var gtexHtml = "";
            var enhancerdbHtml = "";
            var endbHtml = "";
            var hancer1Html = "";
            var hancer2Html = "";
            var hancer3Html = "";
            var hancer4Html = "";
            for (var i=0;i<res.overlaplist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.overlaplist[i]+'</a></span>'
                overlapHtml += gene;
            }
            for (var i=0;i<res.proximallist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.proximallist[i]+'</a></span>'
                proximalHtml += gene;
            }
            for (var i=0;i<res.closestlist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.closestlist[i]+'</a></span>'
                closestHtml += gene;
            }
            for (var i=0;i<res.pancanlist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.pancanlist[i]+'</a></span>'
                pancanmeqtlHtml += gene;
            }
            for (var i=0;i<res.gwaslist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.gwaslist[i]+'</a></span>'
                gwasHtml += gene;
            }
            for (var i=0;i<res.gtexlist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.gtexlist[i]+'</a></span>'
                gtexHtml += gene;
            }
            for (var i=0;i<res.enhancerdblist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.enhancerdblist[i]+'</a></span>'
                enhancerdbHtml += gene;
            }
            for (var i=0;i<res.endblist.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.endblist[i]+'</a></span>'
                endbHtml += gene;
            }
            for (var i=0;i<res.hancergene1list.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.hancergene1list[i]+'</a></span>'
                hancer1Html += gene;
            }
            for (var i=0;i<res.hancergene2list.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.hancergene2list[i]+'</a></span>'
                hancer2Html += gene;
            }
            for (var i=0;i<res.hancergene3list.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.hancergene3list[i]+'</a></span>'
                hancer3Html += gene;
            }
            for (var i=0;i<res.hancergene4list.length;i++){
                var gene = '<span class="badge rounded-pill bg-success"><a href="">'+res.hancergene4list[i]+'</a></span>'
                hancer4Html += gene;
            }
            if (overlapHtml=="")overlapHtml="--";
            if (proximalHtml=="")proximalHtml="--";
            if (closestHtml=="")closestHtml="--";
            if (pancanmeqtlHtml=="")pancanmeqtlHtml="--";
            if (gwasHtml=="")gwasHtml="--";
            if (gtexHtml=="")gtexHtml="--";
            if (enhancerdbHtml=="")enhancerdbHtml="--";
            if (endbHtml=="")endbHtml="--";
            if (hancer1Html=="")hancer1Html="--";
            if (hancer2Html=="")hancer2Html="--";
            if (hancer3Html=="")hancer3Html="--";
            if (hancer4Html=="")hancer4Html="--";
            $("#overlap").html(overlapHtml);
            $("#proximal").html(proximalHtml);
            $("#closest").html(closestHtml);
            $("#pancanmeQTL").html(pancanmeqtlHtml);
            $("#gwas").html(gwasHtml);
            $("#gtex").html(gtexHtml);
            $("#enhancerdb").html(enhancerdbHtml);
            $("#endb").html(endbHtml);
            $("#hancer1").html(hancer1Html);
            $("#hancer2").html(hancer2Html);
            $("#hancer3").html(hancer3Html);
            $("#hancer4").html(hancer4Html);
            //右侧target gene associated enhancer graph
            var graph = res.graph;
            myChart.hideLoading();
            graph.nodes.forEach(function (node) {
                node.label = {
                    show: node.symbolSize > 20
                };
            });
            option = {
                title: {
                    text: 'Network diagram of enhancer and associated genes',
                    subtext: 'Default layout',
                    top: 'bottom',
                    left: 'right'
                },
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                legend: [
                    {
                        // selectedMode: 'single',
                        data: graph.categories.map(function (a) {
                            return a.name;
                        })
                    }
                ],
                animationDuration: 1500,
                animationEasingUpdate: 'quinticInOut',
                series: [
                    {
                        name: 'target gene',
                        type: 'graph',
                        layout: 'circular',
                        data: graph.nodes,
                        links: graph.links,
                        categories: graph.categories,
                        roam: false,
                        label: {
                            position: 'center',
                            formatter: '{b}'
                        },
                        lineStyle: {
                            color: 'source',
                            curveness: 0.1
                        },
                        emphasis: {
                            focus: 'adjacency',
                            lineStyle: {
                                width: 1
                            }
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function commonsnp(peak) {
    $('#commonTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "commonsnp",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "snpid"},
            {"data": "chrome"},
            {"data": "position"},
            {"data": "afr"},
            {"data": "amr"},
            {"data": "eas"},
            {"data": "eur"},
            {"data": "sas"},
            {"data": "riskSNP"},
            {
                "data": "sampleid",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='http://www.licpathway.net/VARAdb/search/search_rsid_result.php?rs_sel_type=rsIDs&rs=" + row.snpid + "'>VARAdb" + "</a> | "+"<a class='link-info' target='_blank' href='http://licpathway.net/sedb/analysis_snp/snp_detail.php?snp_id=" + row.snpid + "'>sedb" + "</a> | "+"<a class='link-info' target='_blank' href='https://www.ncbi.nlm.nih.gov/snp/" + row.snpid + "'>dbsnp" + "</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function interaction(peak) {
    $('#interactionTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "interaction",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "c10"},
            {"data": "c4"},
            {"data": "c5"},
            {"data": "c6"},
            {"data": "c7"},
            {"data": "c8"},
            {"data": "c9"}
        ],
        oLanguage: olanguage
    });
}

function dhs(peak) {
    $('#dhsTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "dhs",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {
                "data": "sampleid",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid + "'>Sample_" + row.sampleid + "</a>";
                }
            },
            {"data": "source"},
            {"data": "biosampletype"},
            {"data": "tissuetype"},
            {"data": "biosamplename"}
        ],
        oLanguage: olanguage
    });
}

function eqtl(peak) {
    $('#eqtlTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getEqtl",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return  "AFR Population";
                }
            },
            {"data": "chrome"},
            {"data": "position"},
            {"data": "ref"},
            {"data": "alt"},
            {"data": "gene"},
            {"data": "disease"},
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function tad(peak) {
    $('#tadTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getTad",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "description"}
        ],
        oLanguage: olanguage
    });
}

function tfbs(peak) {
    $('#tfbsTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "tfbs",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "motif"},
            {"data": "tf"},
            {"data": "strand"},
            {"data": "qValue"},
            {"data": "pValue"},
            {"data": "seq"}
        ],
        oLanguage: olanguage
    });
}

function chromhmm(peak) {
    $('#ChromHMMTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "chromhmm",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "type"},
            {"data": "hmmid"},
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function enhancer(peak) {
    $('#enhancerTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "getEnhancer",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "Enhancer";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "human_permissive_enhancers";
                }
            },
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function risk(peak) {
    $('#risksnpTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "getRisk",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "snpid"},
            {"data": "chrome"},
            {"data": "position"},
            {"data": "ref"},
            {"data": "alt"},
            {"data": "gene"},
            {"data": "disease"},
            {"data": "type"},
            {"data": "pvalue"},
            {"data": "orvalue"},
            {"data": "pmid"}
        ],
        oLanguage: olanguage
    });
}

function crispr(peak) {
    $('#crisprTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "getCrispr",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "description"}
        ],
        oLanguage: olanguage
    });
}

function snpafr(peak) {
    $('#snpafrTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPafr",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "AFR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpamr(peak) {
    $('#snpamrTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPamr",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "AMR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpeas(peak) {
    $('#snpeasTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPeas",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "EAS Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpeur(peak) {
    $('#snpeurTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPeur",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "EUR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}


function snpsas(peak) {
    $('#snpsasTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPsas",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "SAS Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}
