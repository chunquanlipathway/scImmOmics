function DApeak(samplename) {
    $("#peakdownload").attr("href","scATAC_Data8/"+samplename+"_DA_peak.tsv");
    $("#DApeak").DataTable({
        ajax: {
            url: "getDApeak",
            type: "GET",
            async: true,
            data: {"sample":samplename}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        bLengthChange: false,
        lengthMenu: [[5, 10, 20, 100], [5, 10, 20, 100]],
        destroy: true,
        columns: [
            {"data": "chr"},
            {"data": "startposi"},
            {"data": "endposi"},
            {
                "data": "pvalue",
                "render": function (data, type, row, meta) {
                    if (row.pvalue!=""){
                        return Number(row.pvalue).toExponential(3);
                    }return "-";
                }
            },
            {
                "data": "log2fc",
                "render": function (data, type, row, meta) {
                    if (row.log2fc!=""){
                        return Number(row.log2fc).toExponential(3);
                    }return "-";
                }
            },
            {"data": "pct1"},
            {"data": "pct2"},
            {
                "data": "adjust",
                "render": function (data, type, row, meta) {
                    if (row.adjust!=""){
                        return Number(row.adjust).toExponential(3);
                    }return "-";
                }
            },
            {
                "data": "fdr",
                "render": function (data, type, row, meta) {
                    if (row.fdr!=""){
                        return Number(row.fdr).toExponential(3);
                    }return "-";
                }
            },
            {"data": "cluster"},
            {"data": "gene"}
        ],
        oLanguage: olanguage
    });
}