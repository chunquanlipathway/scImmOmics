function f(dataset) {

}

// 递归函数，用于搜索包含特定字符串的名称属性并添加新参数
function searchAndAddItemStyle(obj, searchString, itemStyleValue, path = []) {
    // 如果当前对象的名称属性包含搜索字符串，则输出匹配结果并添加新参数
    if (obj.name && obj.name===searchString) {
        // 添加 itemStyle 到匹配到的对象中
        obj.itemStyle = itemStyleValue;
    }
    if (obj.children) {
        obj.children.forEach(function(child, index) {
            searchAndAddItemStyle(child, searchString, itemStyleValue, [...path, obj.name + '[' + index + ']']);
        });
    }
}

function time() {
    let t = new Date();
    let h = t.getHours();
    let m = t.getMinutes();
    let s = t.getSeconds();
    let T = h+"时"+m+"分"+s+"秒"+"来自xxx";
    console.log(T)
}

/*sampleInfo*/
function getSampleInfoDetail(samplename) {
    $.ajax({
        url: "sampleInfo",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            if (res.data!=null){
                var datatype = ""
                if (res.data.biosampleType=="scRNA-seq+scTCR-seq+scATAC-seq"){
                    if (!samplename.includes("scATAC")){
                        datatype = "scRNA-seq+scTCR-seq+<a href='atac_detail?sample="+samplename+"_scATAC'>scATAC-seq</a>"
                    }
                }else {
                    datatype = res.data.biosampleType
                }
                var html = "<tr>" +
                    "<td>"+ res.data.idenSignal+"</td>" +
                    "<td>"+ res.data.sapiens+"</td>" +
                    "<td>"+ res.data.tissueType+"</td>" +
                    "<td>"+ res.data.disease+"</td>" +
                    "<td>"+ res.data.status+"</td>" +
                    "<td><a href='https://pubmed.ncbi.nlm.nih.gov/"+res.data.pmid+"'>"+res.data.pmid+"</a></td>" +
                    "<td>"+ res.data.article+"</td>" +
                    "<td>"+ res.data.journal+"</td>" +
                    "<td>"+ res.data.year+"</td>" +
                    "<td><a href='https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc="+res.data.dataSource+"'>"+res.data.dataSource+"</a></td>" +
                    "<td>"+ res.data.platform+"</td>" +
                    "<td>"+ datatype + "</td></tr>";
                $("#sampleInfo").append(html);
            }
        },
        dataType: "json"
    });
}

function getDiseaseBySampleID(samplename) {
    $.ajax({
        url: "getDiseaseBySampleID",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            if (res.data!=null){
                for (var i = 0; i < res.data.length; i++) {
                    $("#disease_status").append("<option>"+res.data[i]+"</option>");
                    $("#clonodisease_status").append("<option>"+res.data[i]+"</option>");
                    $("#bcrdisease_status").append("<option>"+res.data[i]+"</option>");
                    $("#TRUST4clonodisease_status").append("<option>"+res.data[i]+"</option>");
                    $("#TRUST4bcrdisease_status").append("<option>"+res.data[i]+"</option>");
                }
            }
        },
        dataType: "json"
    });
}

/*cell type tree*/
function getCelltype(samplename) {
    var dom = document.getElementById('tree');
    var myChart = echarts.init(dom, null, {
        renderer: 'canvas',
        useDirtyRect: false
    });
    var app = {};
    var option;
    myChart.showLoading();
    const data = {
        name: 'Lymphoid cell',
        children: [
            {
                name: 'T cell',
                children: [
                    {
                        name: 'CD4T cell',
                        children: [
                            { name: 'Naive CD4T cell'},
                            { name: 'Memory CD4T cell',
                                children: [{ name:'Central memory CD4T cell'},{ name:'Effector memory CD4T cell'},{ name:'Resident memory CD4T cell'},{ name:'Effector Memory-Expressing CD45RA CD4T cell'}]},
                            { name: 'Effector CD4T cell'},
                            { name: 'Regulatory CD4T cell'},
                            { name: 'Proliferating CD4T cell'},
                            { name: 'Exhausted CD4T cell'},
                            { name: 'Follicular helper T cell',
                                children: [{ name:'Exhausted Follicular helper T cell'}]},
                            { name: 'Dysfunctional CD4T cell'},
                            { name: 'Effector/Effector memory CD4T cell'},
                            { name: 'Naive/Central memory CD4T cell'},
                            { name: 'T helper cell',
                                children: [{ name:'T helper 1 cell'},
                                    { name:'T helper 17 cell'},
                                    { name:'T helper 1/17 cell'},
                                    { name:'T helper 2 cell'},
                                    { name:'Proliferating T helper cell'}]},
                            { name: 'CD4T interferon stimulated gene cell'}
                        ]
                    },
                    {
                        name: 'Naive T cell'
                    },
                    {
                        name: 'Cytotoxic T cell'
                    },
                    {
                        name: 'Conventional T cell'
                    },
                    {
                        name: 'Central memory T cell'
                    },
                    {
                        name: 'Effector memory T cell'
                    },
                    {
                        name: 'Exhausted T cell'
                    },
                    {
                        name: 'Memory T cell'
                    },
                    {
                        name: 'Progenitor T cell'
                    },
                    {
                        name: 'Regulatory T cell'
                    },
                    {
                        name: 'Proliferating regulatory T cell'
                    },
                    {
                        name: 'Proliferating T cell'
                    },
                    {
                        name: 'Natural Killer T cell'
                    },
                    {
                        name: 'Double Negative T cell'
                    },
                    {
                        name: 'Double Positive T cell'
                    },
                    {
                        name: 'CD8T cell',
                        children: [
                            { name: 'Naive CD8T cell'},
                            { name: 'Memory CD8T cell',
                                children: [{ name:'Central memory CD8T cell'},{ name:'Effector memory CD8T cell'},{ name:'Resident memory CD8T cell'},{ name:'Effector Memory-Expressing CD45RA CD8T cell'}]},
                            { name: 'Effector CD8T cell'},
                            { name: 'Proliferating CD8T cell'},
                            { name: 'Dysfunctional CD8T cell'},
                            { name: 'Effector/Effector memory CD8T cell'},
                            { name: 'Naive/Central memory CD8T cell'},
                            { name: 'Resident/Effector memory CD8T cell'},
                            { name: 'Exhausted CD8T cell'},
                            { name: 'Transitional effector CD8T cell'},
                            { name: 'Mucosal associated invariant CD8T cell'},
                            { name: 'CD8T helper cell'},
                            { name: 'CD8T interferon stimulated gene cell'},
                            { name: 'CD8 Cytotoxic T Lymphocyte',
                                children: [{ name:'CD8 Naive Cytotoxic T Lymphocyte'}]},
                        ]
                    }
                ]
            },
            {
                name: 'B cell',
                children: [
                    { name: 'Naive B cell'},
                    { name: 'Memory B cell'},
                    { name: 'Progenitor B cell'},
                    { name: 'Follicular B cell'},
                    { name: 'Plasmablasts'},
                    { name: 'Plasma cell',
                        children: [{ name:'IgG Plasma B cell'},
                            { name:'IgM Plasma B cell'},
                            { name:'IgA Plasma B cell'},
                            { name:'Proliferating IgG Plasma B cell'}]},
                    { name: 'Germinal Center B cell',
                        children: [{ name:'Pre-Germinal Center B cell'}]},
                    { name: 'GrB-secreting B cell'},
                    { name: 'Immature B cell'},
                    { name: 'GALTB cell'},
                    { name: 'Activated B cell'},
                    { name: 'Atypical B cell'},
                    { name: 'Classical Memory B cell'},
                    { name: 'Cycling Memory B cell'}
                ]
            },
            {name: 'Lymphoid Precursor cell'},
            {name: 'Lymphocyte progenitor cell'},
            {name: 'Proliferative Lymphocyte'}
        ]
    };
    var data2 = {
        name: 'Myeloid cell',
        children: [
            {name: 'Monocyte',
                children: [{ name:'Progenitor Monocyte'}]},
            {name: 'Macrophage',
                children: [{ name:'Macrophage M0'},
                    { name:'Macrophage M1'},
                    { name:'Macrophage M2'},
                    { name:'Alveolar Macrophage'},
                    { name:'Macrophage progenitor cell'},
                    { name:'Pleural Macrophage'},
                    { name:'Tissue Resident Macrophage'},
                    { name:'Tumor Associated Macrophage'},
                    { name:'Non-Inflammatory Macrophage'},
                    { name:'Inflammatory Macrophage'},
                    { name:'Proliferating Macrophage'}]},
            {name: 'Mast cell'},
            {name: 'Megakaryocyte'},
            {name: 'Neutrophil'},
            {name: 'Granulocyte'},
            {name: 'Basophil'},
            {name: 'Eosinophil'},
            {name: 'Dendritic cell',
                children: [{ name:'Conventional Dendritic cell'},
                    { name:'Plasmacytoid Dendritic cell'},
                    { name:'Mature regulatory Dendritic cell'},
                    { name:'Activated Sinusoidal Dendritic cell'}]},
            {name: 'Myeloid progenitor cell'},
            {name: 'Myeloid Dendritic cell'},
            {name: 'Proliferating myeloid cell'},
            {name: 'Myeloid progenitor cell'},
            {name: 'Inflammatory Macrophage and Monocyte'}
        ]
    };
    var data3 = {
        name: 'Innate Lymphoid cell',
        children: [
            {name: 'gdT cell',
                children: [{ name:'Proliferating gdT cell'}]},
            {name: 'Alpha beta T cell'},
            {name: 'Natural Killer cell'},
            {name: 'MAIT cell'},
            {name: 'Type 1 Innate Lymphoid cell'},
            {name: 'Type 2 Innate Lymphoid cell'},
            {name: 'Type 3 Innate Lymphoid cell'}
        ]
    };
    var itemStyleValue = {
        color: 'red',
        borderWidth: 2,
        borderColor: 'yellow'
    };
    $.ajax({
        url: "getCelltype",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            for (var i=0;i<res.cellType.length;i++){
                searchAndAddItemStyle(data, res.cellType[i], itemStyleValue);
                searchAndAddItemStyle(data2, res.cellType[i], itemStyleValue);
                searchAndAddItemStyle(data3, res.cellType[i], itemStyleValue);
            }
            myChart.hideLoading();
            myChart.setOption(
                (option = {
                    tooltip: {
                        trigger: 'item',
                        triggerOn: 'mousemove'
                    },
                    legend: {
                        top: '2%',
                        left: '3%',
                        orient: 'vertical',
                        data: [
                            {
                                name: 'tree1',
                                icon: 'rectangle'
                            },
                            {
                                name: 'tree2',
                                icon: 'rectangle'
                            },
                            {
                                name: 'tree3',
                                icon: 'rectangle'
                            }
                        ],
                        borderColor: '#c23531'
                    },
                    series: [
                        {
                            type: 'tree',
                            name: 'tree1',
                            data: [data],
                            top: '0%',
                            left: '10%',
                            bottom: '0%',
                            right: '60%',
                            symbolSize: 7,
                            edgeShape: 'polyline',
                            edgeForkPosition: '80%',
                            initialTreeDepth: 3,
                            lineStyle: {
                                width: 2
                            },
                            label: {
                                position: 'left',
                                verticalAlign: 'middle',
                                align: 'right'
                            },
                            leaves: {
                                label: {
                                    position: 'right',
                                    verticalAlign: 'middle',
                                    align: 'left'
                                }
                            },
                            emphasis: {
                                focus: 'descendant'
                            },
                            expandAndCollapse: true,
                            animationDuration: 550,
                            animationDurationUpdate: 750
                        },
                        {
                            type: 'tree',
                            name: 'tree2',
                            data: [data2],
                            top: '0%',
                            left: '70%',
                            bottom: '22%',
                            right: '20%',
                            symbolSize: 7,
                            edgeShape: 'polyline',
                            edgeForkPosition: '80%',
                            initialTreeDepth: 3,
                            lineStyle: {
                                width: 2
                            },
                            label: {
                                position: 'left',
                                verticalAlign: 'middle',
                                align: 'right'
                            },
                            leaves: {
                                label: {
                                    position: 'right',
                                    verticalAlign: 'middle',
                                    align: 'left'
                                }
                            },
                            expandAndCollapse: true,
                            emphasis: {
                                focus: 'descendant'
                            },
                            animationDuration: 550,
                            animationDurationUpdate: 750
                        },
                        {
                            type: 'tree',
                            name: 'tree3',
                            data: [data3],
                            top: '80%',
                            left: '70%',
                            bottom: '2%',
                            right: '20%',
                            symbolSize: 7,
                            edgeShape: 'polyline',
                            edgeForkPosition: '80%',
                            initialTreeDepth: 3,
                            lineStyle: {
                                width: 2
                            },
                            label: {
                                position: 'left',
                                verticalAlign: 'middle',
                                align: 'right'
                            },
                            leaves: {
                                label: {
                                    position: 'right',
                                    verticalAlign: 'middle',
                                    align: 'left'
                                }
                            },
                            expandAndCollapse: true,
                            emphasis: {
                                focus: 'descendant'
                            },
                            animationDuration: 550,
                            animationDurationUpdate: 750
                        }
                    ]
                })
            );
            if (option && typeof option === 'object') {
                myChart.setOption(option);
            }
            myChart.dispatchAction({
                type: 'highlight',
                seriesIndex: 0,
                dataIndex: 0
            });
            window.addEventListener('resize', myChart.resize);
        },
        dataType: "json"
    });
}

/*pseudo time*/
function getPseudoData(samplename) {
    $.ajax({
        url: "getPseudoData",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            setPseudoPlot(res.x,res.y,res.data)
        },
        dataType: "json"
    });
}
function getCytoTRACE2Data(samplename) {
    var CytoTRACE2Option = $("#CytoTRACE2Option option:checked").val();
    $.ajax({
        url: "getCytoTRACE2Data",
        type: "get",
        data: {"sample":samplename,"method":CytoTRACE2Option},
        async: true,
        success: function (res) {
            $("#CytoTRACE2Loading").hide();
            $("#CytoTRACE2Img").show();
            setCytoTRACE2Plot(res.x,res.y,res.data)
        },
        dataType: "json"
    });
}
function getCytoTRACE2Data_ATAC(samplename) {
    var CytoTRACE2Option = $("#CytoTRACE2Option option:checked").val();
    $.ajax({
        url: "getCytoTRACE2Data_ATAC",
        type: "get",
        data: {"sample":samplename,"method":CytoTRACE2Option},
        async: true,
        success: function (res) {
            $("#CytoTRACE2Loading").hide();
            $("#CytoTRACE2Img").show();
            setCytoTRACE2Plot(res.x,res.y,res.data)
        },
        dataType: "json"
    });
}

function getGeneList(samplename) {
    $.ajax({
        url: "getGeneList",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            $("#genelistOptions").empty();
            var len=res.data.length;
            for (var i=0;i<len;i++){
                var html = "<option>"+res.data[i]+"</option>";
                $("#genelistOptions").append(html)
            }
        },
        dataType: "json"
    });
}
function getProteinList(samplename) {
    $.ajax({
        url: "getProteinList",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            $("#proteinlistOptions").empty();
            var len=res.data.length;
            for (var i=0;i<len;i++){
                var html = "<option>"+res.data[i]+"</option>";
                $("#proteinlistOptions").append(html)
            }
        },
        dataType: "json"
    });
}
function getProteinList_Histone(samplename) {
    $.ajax({
        url: "getProteinList_Histone",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            $("#proteinlistOptions").empty();
            var len=res.data.length;
            for (var i=0;i<len;i++){
                var html = "<option>"+res.data[i]+"</option>";
                $("#proteinlistOptions").append(html)
            }
        },
        dataType: "json"
    });
}
/*cell type Cor expression*/
function getCorExp(samplename) {
    $.ajax({
        url: "getCorExp",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            console.log(res)
            var data = {
                "y" : {
                    "data" : res.data,
                    "smps" : res.celltype,
                    "vars" : res.celltype,
                    "smpTextRotate":"45"
                }
            }
            var config = {
                "smpTextRotate":"45",
                "graphType":"Heatmap",
                "showLogo": false
            }
            var cX = new CanvasXpress("getCorExp", data, config);
        },
        dataType: "json"
    });
}
function getCorExp_echart(samplename){
    var chartDom = document.getElementById('getCorExp');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "getCorExp",
        type: "get",
        data: {"sample":samplename},
        async: true,
        success: function (res) {
            option = {
                tooltip: {
                    position: 'top'
                },
                grid: {
                    height: '65%',
                    top: '6%',
                    left: '40%'
                },
                toolbox: {
                    show: true,
                    right: '50px',
                    feature: {
                        restore: {title: "Restore"},
                        saveAsImage: {title: "save"}
                    }
                },
                xAxis: {
                    type: 'category',
                    data: res.celltype,
                    splitArea: {
                        show: true
                    },
                    axisLabel: { interval: 0, rotate: 30 }
                },
                yAxis: {
                    type: 'category',
                    data: res.celltype,
                    splitArea: {
                        show: true
                    },
                    axisLabel: { interval: 0, rotate: 30 }
                },
                visualMap: {
                    min: res.min,
                    max: 1,
                    // calculable: true,
                    orient: 'vertical',//horizontal
                    left: 'right',
                    top: '25%',
                    text: ['High Score', 'Low Score'],
                    inRange: {
                        color: [
                            '#313695',
                            '#4575b4',
                            '#74add1',
                            '#abd9e9',
                            '#e0f3f8',
                            '#ffffbf',
                            '#fee090',
                            '#fdae61',
                            '#f46d43',
                            '#d73027',
                            '#a50026'
                        ]
                    }
                },
                series: [
                    {
                        name: 'Correlation coefficient',
                        type: 'heatmap',
                        data: res.data,
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            myChart.hideLoading();
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

/*pathway enrichment analysis*/
function getpathwaycelltype(sample) {
    $.ajax({
        url: "getpathwaycelltype",
        type: "get",
        data: {"sample":sample},
        async: true,
        success: function (res) {
            if (res.data!=null){
                $("#keggCellTypeList").empty();
                $("#goCellTypeList").empty();
                $("#hallmarkCellTypeList").empty();
                for (var i=0;i<res.data.length;i++){
                    $("#goCellTypeList").append("<option>"+res.data[i]+"</option>");
                    $("#hallmarkCellTypeList").append("<option>"+res.data[i]+"</option>");
                    $("#keggCellTypeList").append("<option>"+res.data[i]+"</option>");
                    $("#ImmSignatureCellTypeList").append("<option>"+res.data[i]+"</option>");
                }
                pathway_go(sample);
                pathway_kegg(sample);
                pathway_ImmSignature(sample);
                pathway_hallmark(sample);
            }
        },
        dataType: "json"
    });
}
function pathway_go_option(go_data){
    var option = {
        dataset: {
            source: go_data
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        grid: {
            containLabel: true,
            left: '2%',
            top: '10%',
            bottom: '12%'
        },
        xAxis: { name: 'Count' },
        yAxis: {
            type: 'category',
            axisLabel: {
                show: true,
                interval: 'auto',
                formatter: function (param) {
                    if (param.length>50){
                        return param.substring(0,50)+"...";
                    }else {return param}
                }
            },
        },
        toolbox: {
            show: true,
            right: '50px',
            feature: {
                restore: {title: "Restore"},
                saveAsImage: {title: "save"}
            }
        },
        visualMap: {
            orient: 'horizontal',
            left: 'center',
            min: 1,
            max: 3,
            text: ['High Score', 'Low Score'],
            // Map the score column to color
            dimension: 0,
            inRange: {
                color: ['#65B581', '#FFCE34', '#FD665F']
            }
        },
        dataZoom: [
            { type: 'slider', yAxisIndex: 0},
        ],
        series: [
            {
                type: 'bar',
                encode: {
                    // Map the "amount" column to X axis.
                    x: 'amount',
                    // Map the "product" column to Y axis
                    y: 'product'
                }
            }
        ]
    };
    return option;
}
function pathway_kegg_option(data){
    var option = {
        color: ['#fec42c'],
        grid: {
            containLabel: true,
            left: '2%',
            top: '10%',
            bottom: '10%'
        },
        toolbox: {
            show: true,
            right: '50px',
            feature: {
                restore: {title: "Restore"},
                saveAsImage: {title: "save"}
            }
        },
        tooltip: {
            backgroundColor: 'rgba(255,255,255,0.7)'
        },
        dataZoom: [
            { type: 'slider', yAxisIndex: 0},
        ],
        xAxis: {
            type: 'value',
            name: 'Gene ratio',
            nameGap: 20,
            position: 'bottom',
            nameLocation: 'middle',
            nameTextStyle: {
                fontSize: 16
            },
            splitLine: {
                show: false
            }
        },
        yAxis: {
            type: 'category',
            axisLabel: {
                show: true,
                interval: 'auto',
                formatter: function (param) {
                    if (param.length>50){
                        return param.substring(0,50)+"...";
                    }else {return param}
                }
            },
            name: 'Description',
            nameLocation: 'end',
            nameGap: 20,
            nameTextStyle: {
                fontSize: 16
            },
            splitLine: {
                show: false
            }
        },
        visualMap: [
            {
                left: 'right',
                top: '10%',
                dimension: 3,
                min: data.countMin,
                max: data.countMax,
                itemWidth: 30,
                itemHeight: 120,
                calculable: true,
                precision: 0.1,
                text: ['count'],
                textGap: 30,
                inRange: {
                    symbolSize: [10, 70]
                },
                outOfRange: {
                    symbolSize: [10, 70],
                    color: ['rgba(255,255,255,0.4)']
                },
                controller: {
                    inRange: {
                        color: ['#c23531']
                    },
                    outOfRange: {
                        color: ['#999']
                    }
                }
            },
            {
                left: 'right',
                bottom: '5%',
                dimension: 2,
                min: data.pValueMin,
                max: data.pValueMax,
                itemHeight: 120,
                text: ['-log10(pvalue)'],
                textGap: 30,
                inRange: {
                    colorLightness: [0.9, 0.5]
                },
                outOfRange: {
                    color: ['rgba(255,255,255,0.4)']
                },
                controller: {
                    inRange: {
                        color: ['#fec42c']
                    },
                    outOfRange: {
                        color: ['#999']
                    }
                }
            }
        ],
        series: [
            {
                type: 'scatter',
                itemStyle: {
                    opacity: 0.8,
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowOffsetY: 0,
                    shadowColor: 'rgba(0,0,0,0.3)'
                },
                data: data.data
            }
        ]
    };
    return option;
}
function pathway_hallmark_option(data){
    var option = {
        dataset: {
            source: data
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        grid: {
            containLabel: true,
            left: '2%',
            top: '10%',
            bottom: '12%'
        },
        xAxis: { name: 'Count' },
        yAxis: {
            type: 'category',
            axisLabel: {
                show: true,
                interval: 'auto',
                formatter: function (param) {
                    if (param.length>50){
                        return param.substring(0,50)+"...";
                    }else {return param}
                }
            },
        },
        toolbox: {
            show: true,
            right: '50px',
            feature: {
                restore: {title: "Restore"},
                saveAsImage: {title: "save"}
            }
        },
        visualMap: {
            orient: 'horizontal',
            left: 'center',
            min: 1,
            max: 3,
            text: ['High Score', 'Low Score'],
            // Map the score column to color
            dimension: 0,
            inRange: {
                color: ['#65B581', '#FFCE34', '#FD665F']
            }
        },
        dataZoom: [
            { type: 'slider', yAxisIndex: 0},
        ],
        series: [
            {
                type: 'bar',
                encode: {
                    // Map the "amount" column to X axis.
                    x: 'amount',
                    // Map the "product" column to Y axis
                    y: 'product'
                }
            }
        ]
    };
    return option;
}
function pathway_go(samplename) {
    var goNumber = $("#goNumberList option:checked").val();
    var cluster = $("#goCellTypeList option:checked").val();
    var chartDom = document.getElementById('goImg');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "getPathwayGo",
        type: "get",
        data: {"sample":samplename, "cluster":cluster, "count": goNumber},
        async: true,
        success: function (res) {
            if (res.data.length<1){
                $("#gostatus").text("No data!");
                myChart.hideLoading();
                myChart.clear();
            }else {
                $("#gostatus").text("");
                var option = pathway_go_option(res.data);
                myChart.hideLoading();
                option && myChart.setOption(option);
            }
        },
        dataType: "json"
    });
}
function pathway_kegg(samplename) {
    var keggNumber = $("#keggNumberList option:checked").val();
    var cluster = $("#keggCellTypeList option:checked").val();
    var chartDom = document.getElementById('keggImg');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "getPathwayKEGG",
        type: "get",
        data: {"sample":samplename, "cluster":cluster, "count": keggNumber},
        async: true,
        success: function (res) {
            if (res.data.length<1){
                $("#keggstatus").text("No data!");
                myChart.hideLoading();
                myChart.clear();
            }else {
                $("#keggstatus").text("");
                var data = res;
                var option = pathway_kegg_option(data);
                myChart.hideLoading();
                option && myChart.setOption(option);
            }
        },
        dataType: "json"
    });
}
function pathway_ImmSignature(samplename) {
    var ImmSignatureNumber = $("#ImmSignatureNumberList option:checked").val();
    var cluster = $("#ImmSignatureCellTypeList option:checked").val();
    var chartDom = document.getElementById('ImmSignatureImg');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "getPathwayImmSignature",
        type: "get",
        data: {"sample":samplename, "cluster":cluster, "count": ImmSignatureNumber},
        async: true,
        success: function (res) {
            if (res.data.length<1){
                $("#ImmSignaturestatus").text("No data!");
                myChart.hideLoading();
                myChart.clear();
            }else {
                $("#ImmSignaturestatus").text("");
                var data = res;
                var option = pathway_kegg_option(data);
                myChart.hideLoading();
                option && myChart.setOption(option);
            }
        },
        dataType: "json"
    });
}
function pathway_hallmark(samplename) {
    var hallmarkNumber = $("#hallmarkNumberList option:checked").val();
    var cluster = $("#hallmarkCellTypeList option:checked").val();
    var chartDom = document.getElementById('hallmarkImg');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    $.ajax({
        url: "getPathwayhallmark",
        type: "get",
        data: {"sample":samplename, "cluster":cluster, "count": hallmarkNumber},
        async: true,
        success: function (res) {
            if (res.data.length<1){
                $("#hallmarkstatus").text("No data!");
                myChart.hideLoading();
                myChart.clear();
            }else {
                $("#hallmarkstatus").text("");
                var option = pathway_hallmark_option(res.data);
                myChart.hideLoading();
                option && myChart.setOption(option);
            }
        },
        dataType: "json"
    });
}
/*cell chat*/
function cellChat(samplename, selectWidth) {
    $.ajax({
        url: "getCellChat",
        type: "get",
        data: {"sample":samplename, "selectWidth":selectWidth},
        async: true,
        success: function (res) {
            if (res.graph.nodes!=null){
                var chartDom = document.getElementById('cellChat');
                var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
                myChart.showLoading();
                graph = res.graph;
                myChart.hideLoading();
                option = {
                    tooltip: {},
                    legend: [
                        {
                            type: 'scroll',
                            orient: 'vertical', // 设置图例的布局方向为垂直horizontal,vertical
                            left: 1, // 设置图例距离容器右侧的距离
                            top: 1,
                            bottom: 20,
                            data: graph.categories.map(function (a) {
                                return a.name;
                            })
                        }
                    ],
                    toolbox: {
                        show: true,
                        right: '50px',
                        feature: {
                            restore: {title: "Restore"},
                            saveAsImage: {title: "save"}
                        }
                    },
                    animationDurationUpdate: 1500,
                    animationEasingUpdate: 'quinticInOut',
                    series: [
                        {
                            type: 'graph',
                            layout: 'circular',
                            symbolSize: 20,
                            left: 200,
                            circular: {
                                rotateLabel: true
                            },
                            data: graph.nodes,
                            links: graph.links,
                            categories: graph.categories,
                            roam: true,
                            label: {
                                position: 'right',
                                formatter: '{b}'
                            },
                            lineStyle: {
                                color: 'source',
                                curveness: 0.3
                            },
                            emphasis: {
                                focus: 'adjacency',
                                lineStyle: {
                                    width: 10
                                }
                            }
                        }
                    ]
                };
                myChart.setOption(option);
            }else {
                $("#cellChat").text("No data!");
            }
        },
        dataType: "json"
    });
}
function cellChatInfo(samplename) {
    $('#cellChatInfo').DataTable({
        ajax: {
            url: "cellChatInfo",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[5, 10, 20, 100], [5, 10, 20, 100]],
        destroy: true,
        columns: [
            {"data": "source"},
            {"data": "target"},
            {"data": "ligand"},
            {"data": "receptor"},
            {"data": "prob"},
            {"data": "pval"},
            {"data": "interaction_name"},
            {"data": "interaction_name_2"},
            {"data": "pathway_name"},
            {"data": "annotation"},
            {"data": "evidence"}
        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}

function degTab(samplename) {
    $('#degTab').DataTable({
        ajax: {
            url: "degTabBySamplename",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[5, 10, 20, 100], [5, 10, 20, 100]],
        destroy: true,
        columns: [
            {"data": "gene"},
            {"data": "p_val"},
            {"data": "avg_log2FC"},
            {"data": "pct1"},
            {"data": "pct2"},
            {"data": "p_val_adj"},
            {"data": "cluster"}
        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}

/*hdWGCNAumap*/
function hdWGCNAumap(samplename) {
    $('#hdWGCNAumap').DataTable({
        ajax: {
            url: "hdWGCNAumap",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[10, 20, 100], [10, 20, 100]],
        destroy: true,
        columns: [
            {"data": "umap1"},
            {"data": "umap2"},
            {"data": "gene"},
            {"data": "module"},
            {"data": "color"},
            {"data": "hub"},
            {"data": "kme"}
        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}
function hdWGCNA2(samplename) {
    $('#hdWGCNA2').DataTable({
        ajax: {
            url: "hdWGCNA2",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[10, 20, 100], [10, 20, 100]],
        destroy: true,
        columns: [
            {"data": "gene1"},
            {"data": "gene2"},
            {"data": "score"}
        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}

/*TCR cdr3 table*/
/*cdr3 table*/
function cdr3Table(samplename) {
    $('#cdr3').DataTable({
        ajax: {
            url: "cdr3Table",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        destroy: true,
        columns: [
            {"data": "c1"},
            {"data": "c2"},
            {"data": "c3"},
            {"data": "c4"},
            {"data": "c5"},
            {"data": "c6"},
            {"data": "c7"},
            {"data": "c8"},
            {"data": "c9"},
            {"data": "c10"},
            {"data": "c11"}

        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}
function TRUST4cdr3Table(samplename) {
    $('#TRUST4cdr3').DataTable({
        ajax: {
            url: "TRUST4cdr3Table",
            type: "GET",
            async: true,
            data: {"sample": samplename}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        destroy: true,
        columns: [
            {"data": "c1"},
            {"data": "c2"},
            {"data": "c3"},
            {"data": "c4"},
            {"data": "c5"},
            {"data": "c6"},
            {"data": "c7"},
            {"data": "c8"},
            {"data": "c9"},
            {"data": "c10"},
            {"data": "c11"}
        ],
        oLanguage: {
            // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
            "sProcessing": 'processing......',
            "sLengthMenu": "_MENU_ entries per page",
            "sZeroRecords": "No matching data found",
            "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
            "sInfoFiltered": "( Filter from _MAX_ records )",
            "sSearch": "Search: ",
            "oPaginate": {
                "sFirst": "home",
                "sPrevious": "‹",
                "sNext": "›",
                "sLast": "end"
            }
        }
    });
}