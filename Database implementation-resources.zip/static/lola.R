#执行lola analysis method时会调用次文件
lola <-function(input,universe,dataclass,subclass,resultfile) {
    args=commandArgs(T)
    input=args[1]
    universe=args[2]
    dataclass=args[3]
    subclass=args[4]
    resultfile=args[5]

    library(LOLA)
    queryA <- readBed(input)
    activeDHS <- readBed(universe)
    dbPath = system.file(dataclass, subclass, package="LOLA")
    regionDB = loadRegionDB(dbLocation=dbPath)
    result <- runLOLA(queryA, activeDHS,regionDB)
    write.table(result, resultfile, sep ="\t", row.names =F,quote=F)
}
lola(input,universe,dataclass,subclass,resultfile)