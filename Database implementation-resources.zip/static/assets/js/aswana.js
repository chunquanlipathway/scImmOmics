var olanguage = {
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function cat(samples) {
    $.ajax({
        url: "runcatpeak",
        type: "get",
        data: {"samples": samples},
        async: true,
        success: function (res) {
            $("#loading").attr("style","width:30%;");
            formatFile(res.data)
        },
        dataType: "json"
    });
}

function formatFile(floder) {
    $.ajax({
        url: "formatFile",
        type: "get",
        data: {"param": floder},
        async: true,
        success: function (res) {
            $("#loading").attr("style","width:50%;");
            clusterFile(res.data)
        },
        dataType: "json"
    });
}

function clusterFile(floder) {
    $.ajax({
        url: "clusterFile",
        type: "get",
        data: {"param": floder},
        async: true,
        success: function (res) {
            $("#loading").attr("style","width:70%;");
            aswFile(floder)
        },
        dataType: "json"
    });
}

function aswFile(floder) {
    $.ajax({
        url: "aswFile",
        type: "get",
        data: {"param": floder},
        async: true,
        success: function (res) {
            $("#loading").attr("style","width:90%;");
            readFile(res.data)
        },
        dataType: "json"
    });
}

function readFile(floder) {
    $("#aswResult").DataTable({
        ajax: {
            url: "readFile",
            type: "GET",
            async: true,
            data: {"param":floder}
        },
        initComplete: function( settings, json ) {
            $("#loading").attr("style","width:100%;");
            $("#loadingdiv").remove();
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "c1",
                "render": function (data, type, row, meta) {
                    return row.c1 + ":" + row.c2 + "-" + row.c3;
                }
            },
            {
                "data": "c1",
                "render": function (data, type, row, meta) {
                    return row.c3 - row.c2;
                }
            },
            {"data": "c4"},
            {"data": "c5"},
            {"data": "c6"}
        ],
        oLanguage: olanguage
    });
}
