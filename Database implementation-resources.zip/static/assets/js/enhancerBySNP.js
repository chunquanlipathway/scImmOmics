var olanguage = {
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function interactionBySNP(peak) {
    $('#interactionTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "interactionBySNP",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "c10"},
            {"data": "c4"},
            {"data": "c5"},
            {"data": "c6"},
            {"data": "c7"},
            {"data": "c8"},
            {"data": "c9"}
        ],
        oLanguage: olanguage
    });
}

function dhsBySNP(chrome,position) {
    $('#dhsTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "dhsBySNP",
            type: "GET",
            async: true,
            data: {"chrome": chrome,"position":position}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {
                "data": "sampleid",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid + "'>Sample_" + row.sampleid + "</a>";
                }
            },
            {"data": "source"},
            {"data": "biosampletype"},
            {"data": "tissuetype"},
            {"data": "biosamplename"}
        ],
        oLanguage: olanguage
    });
}

function eqtlBySNP(snpid) {
    $('#eqtlTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getEqtlBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {"data": "id"},
            {"data": "chrome"},
            {"data": "position"},
            {"data": "ref"},
            {"data": "alt"},
            {"data": "gene"},
            {"data": "disease"},
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function tadBySNP(chrome,position) {
    $('#tadTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getTadBySNP",
            type: "GET",
            async: true,
            data: {"chrome": chrome,"position":position}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "description"}
        ],
        oLanguage: olanguage
    });
}

function tfbsBySNP(chrome,position) {
    $('#tfbsTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "tfbsBySNP",
            type: "GET",
            async: true,
            data: {"chrome": chrome,"position":position}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "motif"},
            {"data": "tf"},
            {"data": "strand"},
            {"data": "qValue"},
            {"data": "pValue"},
            {"data": "seq"}
        ],
        oLanguage: olanguage
    });
}

function motifchange(snpid) {
    $('#motifchangeTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "motifchange",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {"data": "snp_id"},
            {"data": "motif_name"},
            {"data": "motif_log_lik_ref"},
            {"data": "motif_log_lik_snp"},
            {"data": "motif_log_reduce_odds"},
            {"data": "motif_ref_strand"},
            {"data": "motif_snp_strand"},
            {"data": "motif_p_rank"}
        ],
        oLanguage: olanguage
    });
}

function chromhmmBySNP(peak) {
    $('#ChromHMMTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "chromhmmBySNP",
            type: "GET",
            async: true,
            data: {"peak": peak}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "type"},
            {"data": "hmmid"},
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function idenenhancerBySNP(chrome,position) {
    $('#enhancerTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "getidenEnhancerBySNP",
            type: "GET",
            async: true,
            data: {"chrome": chrome,"position":position}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "Enhancer";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "human_permissive_enhancers";
                }
            },
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}

function riskBySNP(snpid) {
    $('#risksnpTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        destroy: true,
        ajax: {
            url: "getRiskBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {"data": "snpid"},
            {"data": "chrome"},
            {"data": "position"},
            {"data": "ref"},
            {"data": "alt"},
            {"data": "gene"},
            {"data": "disease"},
            {"data": "type"},
            {"data": "pvalue"},
            {"data": "orvalue"},
            {"data": "pmid"}
        ],
        oLanguage: olanguage
    });
}

function crisprBySNP(chrome,position) {
    $('#crisprTab').DataTable({
        processing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange:false,
        // destroy: true,
        ajax: {
            url: "getCrisprBySNP",
            type: "GET",
            async: true,
            data: {"chrome": chrome,"position":position}
        },
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"},
            {"data": "description"}
        ],
        oLanguage: olanguage
    });
}

function snpafrBySNP(snpid) {
    $('#snpafrTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPafrBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "AFR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpamrBySNP(snpid) {
    $('#snpamrTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPamrBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "AMR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpeasBySNP(snpid) {
    $('#snpeasTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPeasBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "EAS Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function snpeurBySNP(snpid) {
    $('#snpeurTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPeurBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "EUR Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}


function snpsasBySNP(snpid) {
    $('#snpsasTab').DataTable({
        processing: true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        // destroy: true,
        ajax: {
            url: "getSNPsasBySNP",
            type: "GET",
            async: true,
            data: {"snpid": snpid}
        },
        columns: [
            {
                "data": "snpid",
                "render": function (data, type, row, meta) {
                    return  "SAS Population";
                }
            },
            {"data": "snpid"},
            {"data": "snpchrome"},
            {"data": "snpposition"},
            {"data": "ldsnpid"},
            {"data": "r2"},
            {"data": "d"}
        ],
        oLanguage: olanguage
    });
}

function enhancerBySNP(snp,checkh3k4me3,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabBySNP",
            type: "GET",
            async: true,
            data: {"snpchrome":snp.chrome,"snpposition":snp.position,"singal":singal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "tissueType"},
            {
                "data": "biosampleName",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid+ "'>" + row.biosampleName + "</a>";
                }
            },
            {"data": "logpvalue"},
            {"data": "interaction"},
            {"data": "methy450K"},
            {"data": "commonsnp"},
            {"data": "crisps"},
            {"data": "enhancer"},
            {"data": "eqtl"},
            {"data": "gwas"},
            {"data": "tad"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg38&lastVirtModeType=default&lastVirtModeExtraState=&virtModeType=default&virtMode=0&nonVirtPosition=&position="+row.chrome+"%3A"+row.start+"%2D"+row.end+"&hgsid=1334138285_q3d2baKSxBnqflr14dK9CRYkDtfA'>" + "UCSC</a>|<a>ENID"+"</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function enhancercrmsBySNP(snp,checkh3k4me3,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabremapBySNP",
            type: "GET",
            async: true,
            data: {"snpchrome":snp.chrome,"snpposition":snp.position,"singal":singal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "tfs"},
            {"data": "numbers"}
        ],
        oLanguage: olanguage
    });
}

function enhancerBySNPasw(snp,checkh3k4me3,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabBySNP",
            type: "GET",
            async: true,
            data: {"snpchrome":snp.chrome,"snpposition":snp.position,"singal":singal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "signals"},
            {"data": "signalnum"},
            {"data": "interaction"},
            {"data": "methy450K"},
            {"data": "commonsnp"},
            {"data": "crisps"},
            {"data": "enhancer"},
            {"data": "eqtl"},
            {"data": "gwas"},
            {"data": "tad"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg38&lastVirtModeType=default&lastVirtModeExtraState=&virtModeType=default&virtMode=0&nonVirtPosition=&position="+row.chrome+"%3A"+row.start+"%2D"+row.end+"&hgsid=1334138285_q3d2baKSxBnqflr14dK9CRYkDtfA'>" + "UCSC</a>|<a>ENID"+"</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function snp_graph(snp) {
    var chartDom = document.getElementById('main');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    myChart.hideLoading();
    option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        grid: {
            top: '3%',
            left: '3%',
            right: '5%',
            bottom: '2%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            axisLabel:{
                interval: 0, rotate: 30
            },
            data: ['AFR-LD', 'AMR-LD', 'EAS-LD', 'EUR-LD', 'SAS-LD', 'Risk_SNP']
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                data: [snp.afr, snp.amr, snp.eas, snp.eur, snp.sas, snp.riskSNP],
                type: 'line'
            }
        ]
    };
    option && myChart.setOption(option);
}
