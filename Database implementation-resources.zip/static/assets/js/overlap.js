var olanguage = {
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

var subbool1=false;
var subbool2=false;
var diffbool=false;
var diffnum;
var subnum1;
var subnum2;
function overlapResult(random,sampleid,rate) {
    $("#overlap").DataTable({
        ajax: {
            url: "runoverlap",
            type: "GET",
            async: true,
            data: {"random":random,"sampleid":sampleid,"rate":rate}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "chrome"},
            {"data": "start"},
            {"data": "end"}
        ],
        oLanguage: olanguage
    });
}

function graph1(param1,param2) {
    var chartDom = document.getElementById('graph1');
    var myChart = echarts.init(chartDom);
    var option;

    option = {
        title: {
            left: 'center'
        },
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            left: 'left'
        },
        series: [
            {
                name: 'Statistic',
                type: 'pie',
                radius: '50%',
                data: [
                    { value: param1, name: 'diff_region' },
                    { value: param2, name: 'overlap_region' }
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };

    option && myChart.setOption(option);

}
function graph2(param1,param2) {
    var chartDom = document.getElementById('graph2');
    var myChart = echarts.init(chartDom);
    var option;

    option = {
        title: {
            left: 'center'
        },
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            left: 'left'
        },
        series: [
            {
                name: 'Statistic',
                type: 'pie',
                radius: '50%',
                data: [
                    { value: param1, name: 'diff_region' },
                    { value: param2, name: 'overlap_region' }
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };

    option && myChart.setOption(option);

}

function subtract1(sample1,sample2) {
    $("#subtract1").DataTable({
        ajax: {
            url: "subtract1run",
            type: "GET",
            async: true,
            data: {"sample1":sample1,"sample2":sample2}
        },
        initComplete: function( settings, json ) {
            subbool1=true
            subnum1=json.recordsTotal
            if (subbool1&&subbool2&&diffbool){
                graph1(subnum1,diffnum)
                graph2(subnum2,diffnum)
            }
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "c4",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.c4 + "'>E_" + row.c4 + "</a>";
                }
            },
            {"data":"c1"},
            {"data":"c2"},
            {"data":"c3"},
            {
                "data": "c3",
                "render": function (data, type, row, meta) {
                    return row.c3 - row.c2;
                }
            },
            {"data":"c5"},
            {"data":"c6"},
            {"data":"c7"},
            // {"data":"c13"},
            {"data":"c14"}
            // {"data":"c15"}
        ],
        oLanguage: olanguage
    });
}

function subtract2(sample1,sample2) {
    $("#subtract2").DataTable({
        ajax: {
            url: "subtract2run",
            type: "GET",
            async: true,
            data: {"sample1":sample1,"sample2":sample2}
        },
        initComplete: function( settings, json ) {
            subbool2=true
            subnum2=json.recordsTotal

            if (subbool1&&subbool2&&diffbool){
                graph1(subnum1,diffnum)
                graph2(subnum2,diffnum)
            }
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "c4",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.c4 + "'>E_" + row.c4 + "</a>";
                }
            },
            {"data":"c1"},
            {"data":"c2"},
            {"data":"c3"},
            {
                "data": "c3",
                "render": function (data, type, row, meta) {
                    return row.c3 - row.c2;
                }
            },
            {"data":"c5"},
            {"data":"c6"},
            {"data":"c7"},
            // {"data":"c13"},
            {"data":"c14"}
            // {"data":"c15"}
        ],
        oLanguage: olanguage
    });
}

function differentResult(sample1,sample2) {
    $("#diffoverlap").DataTable({
        ajax: {
            url: "differentrun",
            type: "GET",
            async: true,
            data: {"sample1":sample1,"sample2":sample2}
        },
        initComplete: function( settings, json ) {
            diffbool=true
            diffnum=json.recordsTotal
            if (subbool1&&subbool2&&diffbool){
                graph1(subnum1,diffnum)
                graph2(subnum2,diffnum)
            }
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "c4",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.c4 + "'>E_" + row.c4 + "</a>";
                }
            },
            {
                "data": "c1",
                "render": function (data, type, row, meta) {
                    return row.c1 + ":" + row.c2 + "-" + row.c3;
                }
            },
            {
                "data": "c1",
                "render": function (data, type, row, meta) {
                    return row.c3 - row.c2;
                }
            },
            {"data": "c14"},
            {
                "data": "c9",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.c9 + "'>E_" + row.c9 + "</a>";
                }
            },
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    return row.c6 + ":" + row.c7 + "-" + row.c8;
                }
            },
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    return row.c8 - row.c7;
                }
            },
            {"data": "c15"},
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    if (row.c7<row.c2<row.c8&row.c3>row.c8){ //a
                        return row.c8-row.c2;
                    }else if (row.c2<row.c7&row.c7<row.c3<row.c8){ //b
                        return row.c3-row.c7;
                    }else if (row.c2<row.c7&row.c3>row.c8){ //c
                        return row.c8-row.c7;
                    }else if (row.c7<row.c2<row.c8&row.c7<row.c3<row.c8){ //d
                        return row.c3-row.c2;
                    }
                }
            },
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    if (row.c7<row.c2<row.c8&row.c3>row.c8){ //a
                        return ((row.c8-row.c2)/(row.c3-row.c2)).toFixed(2);
                    }else if (row.c2<row.c7&row.c7<row.c3<row.c8){ //b
                        return ((row.c3-row.c7)/(row.c3-row.c2)).toFixed(2);
                    }else if (row.c2<row.c7&row.c3>row.c8){ //c
                        return ((row.c8-row.c7)/(row.c3-row.c2)).toFixed(2);
                    }else if (row.c7<row.c2<row.c8&row.c7<row.c3<row.c8){ //d
                        return ((row.c3-row.c2)/(row.c3-row.c2)).toFixed(2);
                    }
                }
            },
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    if (row.c7<row.c2<row.c8&row.c3>row.c8){ //a
                        return ((row.c8-row.c2)/(row.c8-row.c7)).toFixed(2);
                    }else if (row.c2<row.c7&row.c7<row.c3<row.c8){ //b
                        return ((row.c3-row.c7)/(row.c8-row.c7)).toFixed(2);
                    }else if (row.c2<row.c7&row.c3>row.c8){ //c
                        return ((row.c8-row.c7)/(row.c8-row.c7)).toFixed(2);
                    }else if (row.c7<row.c2<row.c8&row.c7<row.c3<row.c8){ //d
                        return ((row.c3-row.c2)/(row.c8-row.c7)).toFixed(2);
                    }
                }
            },
            {
                "data": "c6",
                "render": function (data, type, row, meta) {
                    if (row.c7<row.c2<row.c8&row.c3>row.c8){ //a
                        return "A";
                    }else if (row.c2<row.c7&row.c7<row.c3<row.c8){ //b
                        return "B";
                    }else if (row.c2<row.c7&row.c3>row.c8){ //c
                        return "C";
                    }else if (row.c7<row.c2<row.c8&row.c7<row.c3<row.c8){ //d
                        return "D";
                    }
                }
            }
        //    a1-c2;a2-c3    b1-c7;b2-c8
        ],
        oLanguage: olanguage
    });
}

function runlola(random,min,max,threshold,tissue,signal) {
    $("#lolatab").DataTable({
        ajax: {
            url: "lolarun",
            type: "GET",
            async: true,
            data: {"random":random,"min":min,"max":max,"threshold":threshold,"tissue":tissue,"signal":signal}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "c4",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.c4 + "'>Sample_" + row.c4 + "</a>";
                }
            },
            {"data":"c7"},
            {"data":"c1"},
            {"data":"c5"},
            {"data":"c6"},
            {
                "data": "c2",
                "render": function (data, type, row, meta) {
                    return parseFloat(row.c2).toFixed(2);
                }
            },
            {
                "data": "c3",
                "render": function (data, type, row, meta) {
                    return parseFloat(row.c3).toFixed(2);
                }
            }

        ],
        oLanguage: olanguage
    });
}

var fristnav = false
function insertsignal(H3K27ac,H3K4me1,ATAC,DNase,MNase,FAIRE,Starr,POLR2A,EP300) {
    if (H3K27ac!=null){
        for (var i = 0; i < H3K27ac.length; i++) {
            var htmlcol1 = "<button type='button' id='H3K27ac" +i+ "' onclick='func(\"" +H3K27ac[i]+ "\",\"H3K27ac\",this)' class='list-group-item list-group-item-action lab'>" + H3K27ac[i] + "</button>";
            $("#H3K27achtml").append(htmlcol1);
            if (!fristnav){
                var id = "#H3K27ac"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (H3K4me1!=null) {
        for (var i = 0; i < H3K4me1.length; i++) {
            var htmlcol1 = "<button type='button' id='H3K4me1" +i+ "' onclick='func(\"" +H3K4me1[i]+ "\",\"H3K4me1\",this)' class='list-group-item list-group-item-action lab'>" + H3K4me1[i] + "</button>";
            $("#H3K4me1html").append(htmlcol1);
            if (!fristnav){
                var id = "#H3K4me1"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (ATAC!=null) {
        for (var i = 0; i < ATAC.length; i++) {
            var htmlcol1 = "<button type='button' id='ATAC" +i+ "' onclick='func(\"" +ATAC[i]+ "\",\"ATAC\",this)' class='list-group-item list-group-item-action lab'>" + ATAC[i] + "</button>";
            $("#ATAChtml").append(htmlcol1);
            if (!fristnav){
                var id = "#ATAC"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (DNase!=null) {
        for (var i = 0; i < DNase.length; i++) {
            var htmlcol1 = "<button type='button' id='DNase" +i+ "' onclick='func(\"" +DNase[i]+ "\",\"DNase\",this)' class='list-group-item list-group-item-action lab'>" + DNase[i] + "</button>";
            $("#DNasehtml").append(htmlcol1);
            if (!fristnav){
                var id = "#DNase"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (MNase!=null) {
        for (var i = 0; i < MNase.length; i++) {
            var htmlcol1 = "<button type='button' id='MNase" +i+ "' onclick='func(\"" +MNase[i]+ "\",\"MNase\",this)' class='list-group-item list-group-item-action lab'>" + MNase[i] + "</button>";
            $("#MNasehtml").append(htmlcol1);
            if (!fristnav){
                var id = "#MNase"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (FAIRE!=null) {
        for (var i = 0; i < FAIRE.length; i++) {
            var htmlcol1 = "<button type='button' id='FAIRE" +i+ "' onclick='func(\"" +FAIRE[i]+ "\",\"FAIRE\",this)' class='list-group-item list-group-item-action lab'>" + FAIRE[i] + "</button>";
            $("#FAIREhtml").append(htmlcol1);
            if (!fristnav){
                var id = "#FAIRE"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (Starr!=null) {
        for (var i = 0; i < Starr.length; i++) {
            var htmlcol1 = "<button type='button' id='Starr" +i+ "' onclick='func(\"" +Starr[i]+ "\",\"Starr\",this)' class='list-group-item list-group-item-action lab'>" + Starr[i] + "</button>";
            $("#Starrhtml").append(htmlcol1);
            if (!fristnav){
                var id = "#Starr"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (POLR2A!=null) {
        for (var i = 0; i < POLR2A.length; i++) {
            var htmlcol1 = "<button type='button' id='POLR2A" +i+ "' onclick='func(\"" +POLR2A[i]+ "\",\"POLR2A\",this)' class='list-group-item list-group-item-action lab'>" + POLR2A[i] + "</button>";
            $("#POLR2Ahtml").append(htmlcol1);
            if (!fristnav){
                var id = "#POLR2A"+i
                $(id).click();
                fristnav = true
            }
        }
    }
    if (EP300!=null) {
        for (var i = 0; i < EP300.length; i++) {
            var htmlcol1 = "<button type='button' id='EP300" +i+ "' onclick='func(\"" +EP300[i]+ "\",\"EP300\",this)' class='list-group-item list-group-item-action lab'>" + EP300[i] + "</button>";
            $("#EP300html").append(htmlcol1);
            if (!fristnav){
                var id = "#EP300"+i
                $(id).click();
                fristnav = true
            }
        }
    }
}

function getinputfileName(){
    var file = $('#inputfile')[0].files[0];
    var fileName = file.name;
    $('#inputfilename').attr("value",fileName);
    $("#customRadio2").prop("checked",true);
}
function inputfilebtnaaa() {
    $("#inputfile").click();
}

function examplefun() {
    $("#min").val("0")
    $("#max").val("1")
    $("#threshold").val("1.0E-7")
    $("#Blood0").prop("checked",true);
    $("#Bone0").prop("checked",true);
    $("#Lung0").prop("checked",true);
    $("#customRadio1").prop("checked",true);
    $("#input").val("chr6\t83859315\t83859740\r\n"+
        "chr1\t204647527\t204647955\r\n"+
        "chr17\t52649037\t52649441\r\n"+
        "chr1\t153990448\t153990935\r\n"+
        "chr8\t38786902\t38787469\r\n"+
        "chr2\t84613037\t84613527\r\n"+
        "chr3\t185527388\t185527912\r\n"+
        "chr11\t36431626\t36432198\r\n"+
        "chr4\t26197315\t26197798\r\n"+
        "chr3\t101573826\t101574293\r\n"+
        "chr20\t51661571\t51662004\r\n"+
        "chr3\t149678328\t149678747\r\n"+
        "chr10\t118423660\t118424165\r\n"+
        "chr3\t64533534\t64533997\r\n"+
        "chr8\t6576742\t6577241\r\n"+
        "chr8\t111043711\t111044198\r\n"+
        "chr5\t39217605\t39218169\r\n"+
        "chr12\t27841357\t27841782\r\n"+
        "chr7\t6077157\t6077608\r\n"+
        "chr3\t141368154\t141368641\r\n"+
        "chr13\t73090246\t73090810\r\n"+
        "chr14\t89027062\t89027689\r\n"+
        "chr3\t128416767\t128417241\r\n"+
        "chr10\t52221934\t52222375\r\n"+
        "chr1\t39387484\t39387890\r\n"+
        "chr19\t9075505\t9076027\r\n"+
        "chr13\t34019887\t34020254\r\n"+
        "chr13\t113816927\t113817339\r\n"+
        "chr4\t30757354\t30757823\r\n"+
        "chr19\t44684939\t44685462\r\n"+
        "chr16\t66433664\t66434217\r\n"+
        "chr15\t52568841\t52569427\r\n"+
        "chr1\t222643877\t222644501\r\n"+
        "chr5\t157778113\t157778534\r\n"+
        "chr15\t74546046\t74546578\r\n"+
        "chr8\t11853888\t11854359\r\n"+
        "chr14\t103576616\t103577053\r\n"+
        "chr15\t62060279\t62060868\r\n"+
        "chr10\t31242847\t31243409\r\n"+
        "chr7\t156903406\t156903958\r\n"+
        "chr6\t125956574\t125957209\r\n"+
        "chr5\t171419117\t171419794\r\n"+
        "chr1\t156020849\t156021257\r\n"+
        "chr10\t4431301\t4431797\r\n"+
        "chr22\t17847395\t17847828\r\n"+
        "chr10\t102432216\t102432842\r\n"+
        "chr1\t234772264\t234772758\r\n"+
        "chr8\t8288266\t8288837\r\n"+
        "chr17\t56699218\t56700033\r\n"+
        "chr3\t31377049\t31377492\r\n"+
        "chr19\t46068504\t46068946\r\n"+
        "chr12\t75960037\t75960484\r\n"+
        "chr10\t22436574\t22437463\r\n"+
        "chr4\t158723193\t158723817\r\n"+
        "chr15\t29736589\t29736979\r\n"+
        "chr19\t11738707\t11739258\r\n"+
        "chr5\t37665811\t37666330\r\n"+
        "chr6\t28225067\t28225627\r\n"+
        "chr20\t4973527\t4973930\r\n"+
        "chr14\t100693152\t100693678\r\n"+
        "chr7\t104943522\t104944031\r\n"+
        "chr1\t93078948\t93079447\r\n"+
        "chr1\t45303882\t45304412\r\n"+
        "chr19\t7652035\t7652590\r\n"+
        "chr11\t13073541\t13073981\r\n"+
        "chr11\t64566401\t64566898\r\n"+
        "chr17\t81967761\t81968377\r\n"+
        "chr21\t32463825\t32464297\r\n"+
        "chr16\t71895039\t71895629\r\n"+
        "chr7\t105776092\t105776451\r\n"+
        "chr5\t102090775\t102091209\r\n"+
        "chr8\t42843066\t42843651\r\n"+
        "chr4\t4574842\t4575675\r\n"+
        "chr3\t49939875\t49940555\r\n"+
        "chr2\t230905361\t230905845\r\n"+
        "chr17\t60037056\t60037468\r\n"+
        "chr5\t175861304\t175862040\r\n"+
        "chr10\t75294791\t75295561\r\n"+
        "chr17\t40956753\t40957223\r\n"+
        "chr7\t151057942\t151058524\r\n"+
        "chr9\t21684858\t21685337\r\n"+
        "chr17\t43530705\t43531391\r\n"+
        "chr7\t92695297\t92696137\r\n"+
        "chr11\t44523536\t44523903\r\n"+
        "chr14\t77128321\t77128845\r\n"+
        "chr16\t68448320\t68448818\r\n"+
        "chr6\t137001283\t137001768\r\n"+
        "chr8\t37545426\t37545919\r\n"+
        "chr1\t151972879\t151973354\r\n"+
        "chr12\t124609069\t124609581\r\n"+
        "chr10\t74150578\t74151244\r\n"+
        "chr14\t26394418\t26394932\r\n"+
        "chr15\t92904020\t92904593\r\n"+
        "chr10\t112490510\t112491027\r\n"+
        "chr12\t89542976\t89543462\r\n"+
        "chr8\t100559306\t100559990\r\n"+
        "chr17\t49230589\t49231259\r\n"+
        "chr1\t55429051\t55429673\r\n"+
        "chr8\t90670927\t90671331\r\n"+
        "chr11\t73876540\t73877385\r\n"+
        "chr9\t6897856\t6898259\r\n"+
        "chr2\t223549068\t223549693\r\n"+
        "chr10\t70477645\t70478136\r\n"+
        "chr7\t4631635\t4632186\r\n"+
        "chr12\t75635590\t75636075\r\n"+
        "chr7\t13017057\t13017797\r\n"+
        "chr14\t89040445\t89041186\r\n"+
        "chr16\t15899492\t15900071\r\n"+
        "chrX\t54808740\t54809130\r\n"+
        "chr17\t67528900\t67529414\r\n"+
        "chr12\t65494510\t65495072\r\n"+
        "chr8\t19013971\t19014673\r\n"+
        "chr5\t71601271\t71602029\r\n"+
        "chr5\t74326848\t74327353\r\n"+
        "chr9\t108579871\t108580435\r\n"+
        "chr2\t133818128\t133818690\r\n"+
        "chr1\t41496206\t41496651\r\n"+
        "chr12\t42238272\t42238848\r\n"+
        "chr1\t235079380\t235079917\r\n"+
        "chr22\t28923748\t28924236\r\n"+
        "chr1\t23809740\t23810144\r\n"+
        "chr16\t87407541\t87408045\r\n"+
        "chr9\t5437653\t5438154\r\n"+
        "chr2\t100284151\t100284582\r\n"+
        "chr7\t73799355\t73799947\r\n"+
        "chr2\t216573059\t216573574\r\n"+
        "chr19\t2047318\t2047764\r\n"+
        "chr12\t12903777\t12904283\r\n"+
        "chr1\t31689658\t31690190\r\n"+
        "chr8\t125333934\t125334615\r\n"+
        "chr5\t149210151\t149210667\r\n"+
        "chr22\t46773860\t46774306\r\n"+
        "chr14\t24673433\t24673955\r\n"+
        "chr17\t73359978\t73360423\r\n"+
        "chr14\t68564964\t68565418\r\n"+
        "chr18\t3665698\t3666194\r\n"+
        "chr12\t31959005\t31959568\r\n"+
        "chr2\t97869235\t97869774\r\n"+
        "chr14\t35291959\t35292588\r\n"+
        "chr11\t120710353\t120710778\r\n"+
        "chr1\t192531094\t192531432\r\n"+
        "chr8\t127742860\t127743308\r\n"+
        "chr2\t226995575\t226996089\r\n"+
        "chr12\t2004285\t2004786\r\n"+
        "chr9\t124574871\t124575416\r\n"+
        "chr18\t48538740\t48539125\r\n"+
        "chr19\t17075078\t17075760\r\n"+
        "chr17\t68821798\t68822355\r\n"+
        "chr3\t4986777\t4987275\r\n"+
        "chr7\t150378913\t150379495\r\n"+
        "chr18\t9869783\t9870321\r\n"+
        "chr1\t84365508\t84366204\r\n"+
        "chr22\t28883418\t28883805\r\n"+
        "chr8\t41151597\t41152028\r\n"+
        "chr3\t142578507\t142579029\r\n"+
        "chr17\t39451080\t39451550\r\n"+
        "chr2\t234203123\t234203637\r\n"+
        "chr2\t27429024\t27429498\r\n"+
        "chr10\t24944809\t24945194\r\n"+
        "chr10\t102502650\t102503123\r\n"+
        "chr19\t2543562\t2543954\r\n"+
        "chr19\t511061\t511582\r\n"+
        "chrX\t23807328\t23807925\r\n"+
        "chr8\t121348704\t121349269\r\n"+
        "chr9\t137083280\t137083780\r\n"+
        "chr6\t12348562\t12349000\r\n"+
        "chr19\t41263725\t41264417\r\n"+
        "chr2\t20350759\t20351285\r\n"+
        "chr9\t22237499\t22238219\r\n"+
        "chr4\t98522510\t98522929\r\n"+
        "chr9\t94726443\t94726826\r\n"+
        "chr8\t132703505\t132704543\r\n"+
        "chr20\t31712615\t31713098\r\n"+
        "chr12\t12033410\t12033773\r\n"+
        "chr1\t94281318\t94281966\r\n"+
        "chr7\t87548539\t87548921\r\n"+
        "chr11\t44506417\t44506842\r\n"+
        "chr8\t109593533\t109593946\r\n"+
        "chr14\t60721222\t60721919\r\n"+
        "chr17\t32486186\t32486799\r\n"+
        "chr8\t93846507\t93847106\r\n"+
        "chr3\t11944035\t11944399\r\n"+
        "chr6\t30769115\t30769961\r\n"+
        "chr10\t90227211\t90227652\r\n"+
        "chr21\t17501233\t17501778\r\n"+
        "chr7\t34035903\t34036524\r\n"+
        "chr5\t135263117\t135263644\r\n"+
        "chr16\t55623000\t55623513\r\n"+
        "chr10\t122954025\t122954611\r\n"+
        "chr6\t151501815\t151502192\r\n"+
        "chr17\t82003492\t82004085\r\n"+
        "chr20\t58980899\t58981367\r\n"+
        "chr2\t20578987\t20579669\r\n"+
        "chr17\t40951174\t40951699\r\n"+
        "chr9\t129557337\t129557858\r\n"+
        "chr14\t54337307\t54337858\r\n"+
        "chr1\t94605647\t94606160\r\n"+
        "chr17\t58391365\t58391980\r\n"+
        "chr20\t54123503\t54124122\r\n"+
        "chr5\t101102521\t101102902\r\n"+
        "chr18\t3618054\t3618659\r\n"+
        "chr10\t10805334\t10805951\r\n"+
        "chr6\t21109687\t21110307\r\n"+
        "chr1\t226626509\t226626926\r\n"+
        "chr1\t14791610\t14792036\r\n"+
        "chr1\t9145236\t9145662\r\n"+
        "chr2\t55419711\t55420176\r\n"+
        "chr14\t68295267\t68295794\r\n"+
        "chr14\t68779818\t68780371\r\n"+
        "chr1\t43373050\t43373643\r\n"+
        "chr1\t228139753\t228140362\r\n"+
        "chr7\t74993926\t74994361\r\n"+
        "chr2\t234679750\t234680475\r\n"+
        "chr10\t99620317\t99621180\r\n"+
        "chr1\t59556800\t59557329\r\n"+
        "chr14\t32259673\t32260079\r\n"+
        "chr9\t136399994\t136400425\r\n"+
        "chr9\t33001430\t33002020\r\n"+
        "chr22\t35561750\t35562384\r\n"+
        "chr2\t62304798\t62305524\r\n"+
        "chr17\t41403878\t41404492\r\n"+
        "chr16\t1677909\t1678423\r\n"+
        "chr17\t58352167\t58352818\r\n"+
        "chr22\t37782356\t37782995\r\n"+
        "chr2\t234362951\t234363431\r\n"+
        "chr6\t34757200\t34757647\r\n"+
        "chr18\t9016871\t9017460\r\n"+
        "chr14\t61355849\t61356268\r\n"+
        "chr4\t6337454\t6337903\r\n"+
        "chr1\t115430819\t115431141\r\n"+
        "chr5\t115634687\t115634992\r\n"+
        "chr15\t79549180\t79549621\r\n"+
        "chr17\t78142055\t78142498\r\n"+
        "chr1\t202348380\t202348819\r\n"+
        "chr4\t30789056\t30789697\r\n"+
        "chr9\t38047705\t38048183\r\n"+
        "chr4\t145938657\t145939132\r\n"+
        "chr22\t29030442\t29031089\r\n"+
        "chr1\t67700642\t67701078\r\n"+
        "chr17\t35063533\t35063903\r\n"+
        "chr7\t50206397\t50206883\r\n"+
        "chr8\t126434706\t126435328\r\n"+
        "chr1\t12178972\t12179416\r\n"+
        "chr6\t142845831\t142846255\r\n"+
        "chr12\t6554110\t6554487\r\n"+
        "chr3\t57060398\t57060878\r\n"+
        "chr1\t16162198\t16162711\r\n"+
        "chr5\t174608720\t174609504\r\n"+
        "chr10\t58137754\t58138239\r\n"+
        "chr4\t123478768\t123479156\r\n"+
        "chr2\t62578015\t62578545\r\n"+
        "chr2\t145323470\t145323970\r\n"+
        "chr19\t36070366\t36070775\r\n"+
        "chr5\t399696\t400406\r\n"+
        "chr20\t371856\t372313\r\n"+
        "chr21\t43659321\t43659750\r\n"+
        "chr17\t1684715\t1685170\r\n"+
        "chr8\t48788733\t48789186\r\n"+
        "chr10\t31940837\t31941430\r\n"+
        "chr8\t123516808\t123517334\r\n"+
        "chr19\t49036757\t49037158\r\n"+
        "chr7\t23334523\t23335002\r\n"+
        "chr12\t51262713\t51263190\r\n"+
        "chr1\t23019156\t23019547\r\n"+
        "chrX\t1750194\t1750664\r\n"+
        "chr2\t226030704\t226031495\r\n"+
        "chr3\t134485665\t134486436\r\n"+
        "chrX\t39975366\t39975920\r\n"+
        "chr20\t54207617\t54208172\r\n"+
        "chr6\t57089887\t57090275\r\n"+
        "chr17\t76484449\t76485037\r\n"+
        "chr16\t15590859\t15591323\r\n"+
        "chr8\t41578011\t41578486\r\n"+
        "chr6\t43635566\t43636134\r\n"+
        "chr1\t226815103\t226815642\r\n"+
        "chr9\t91100083\t91100573\r\n"+
        "chr17\t65750639\t65751070\r\n"+
        "chr12\t65430960\t65431331\r\n"+
        "chr3\t111610195\t111610995\r\n"+
        "chr14\t53846196\t53846722\r\n"+
        "chr19\t40285437\t40285960\r\n"+
        "chr11\t27873495\t27874067\r\n"+
        "chr12\t132222415\t132222802\r\n"+
        "chr4\t31089826\t31090247\r\n"+
        "chr8\t37695469\t37695933\r\n"+
        "chr17\t59754533\t59754982\r\n"+
        "chr6\t7919817\t7920231\r\n"+
        "chr1\t234998368\t234998844\r\n"+
        "chr6\t87155281\t87155773\r\n"+
        "chr14\t53882778\t53883178\r\n"+
        "chr10\t112536598\t112537070\r\n"+
        "chr21\t29849682\t29850061\r\n"+
        "chr5\t142441539\t142442278\r\n"+
        "chr12\t122895967\t122896491\r\n"+
        "chr22\t16949554\t16949944\r\n"+
        "chr16\t50467772\t50468640\r\n"+
        "chr4\t34293443\t34293809\r\n"+
        "chr11\t29282080\t29282535\r\n"+
        "chr2\t241009772\t241010496\r\n"+
        "chr17\t81711867\t81712777\r\n"+
        "chr7\t23349494\t23350208\r\n"+
        "chr13\t44306449\t44307046\r\n"+
        "chr9\t129596744\t129597958\r\n"+
        "chr7\t138352480\t138352996\r\n"+
        "chr20\t1415853\t1416322\r\n"+
        "chr1\t150876062\t150876731\r\n"+
        "chr3\t134374274\t134375309\r\n"+
        "chr4\t181549043\t181549516\r\n"+
        "chr14\t54310139\t54310737\r\n"+
        "chr9\t121692597\t121692985\r\n"+
        "chr14\t63727954\t63728580\r\n"+
        "chr20\t57212538\t57212997\r\n"+
        "chr2\t26709756\t26710252\r\n"+
        "chr18\t2905944\t2906384\r\n"+
        "chr10\t79068675\t79069215\r\n"+
        "chr6\t36239640\t36240238\r\n"+
        "chr1\t8197750\t8198252\r\n"+
        "chr6\t90218511\t90219006\r\n"+
        "chr11\t9314685\t9315167\r\n"+
        "chr6\t7974962\t7975525\r\n"+
        "chr1\t24321572\t24322547\r\n"+
        "chr3\t183162352\t183162894\r\n"+
        "chr22\t29907778\t29908226\r\n"+
        "chr2\t9099314\t9099733\r\n"+
        "chr1\t39183615\t39184214\r\n"+
        "chr2\t218908904\t218909500\r\n"+
        "chr1\t16143837\t16144293\r\n"+
        "chr3\t140941441\t140942035\r\n"+
        "chr7\t27115058\t27115639\r\n"+
        "chr16\t89917792\t89918389\r\n"+
        "chr11\t118912035\t118912708\r\n"+
        "chr11\t102111508\t102112306\r\n"+
        "chr10\t56361024\t56361527\r\n"+
        "chr17\t50661794\t50662273\r\n"+
        "chr3\t139299398\t139299970\r\n"+
        "chr8\t121725776\t121726299\r\n"+
        "chr11\t10659513\t10660091\r\n"+
        "chr6\t14270953\t14271555\r\n"+
        "chr5\t44875642\t44876184\r\n"+
        "chr19\t5790494\t5790934\r\n"+
        "chr20\t4041768\t4042159\r\n"+
        "chr1\t68323101\t68323832\r\n"+
        "chr7\t33987308\t33987744\r\n"+
        "chr17\t82458130\t82459140\r\n"+
        "chr10\t3889902\t3890478\r\n"+
        "chr11\t110565219\t110565719\r\n"+
        "chr17\t21253119\t21253712\r\n"+
        "chr12\t62866009\t62866404\r\n"+
        "chr8\t63038718\t63039673\r\n"+
        "chr14\t28382794\t28383215\r\n"+
        "chr9\t129178093\t129178853\r\n"+
        "chr12\t114799605\t114800072\r\n"+
        "chr7\t47557946\t47558641\r\n"+
        "chr18\t3448165\t3448617\r\n"+
        "chr22\t39592694\t39593344\r\n"+
        "chr2\t157628517\t157629398\r\n"+
        "chr14\t105091558\t105092000\r\n"+
        "chr2\t27369798\t27370586\r\n"+
        "chr2\t20491969\t20492534\r\n"+
        "chr12\t52147309\t52147740\r\n"+
        "chr17\t68511659\t68512519\r\n"+
        "chr5\t139755968\t139756565\r\n"+
        "chr15\t55587715\t55588378\r\n"+
        "chr11\t111870917\t111871696\r\n"+
        "chr1\t15800135\t15800702\r\n"+
        "chr4\t6974416\t6974795\r\n"+
        "chr18\t3602857\t3603779\r\n"+
        "chr14\t54291833\t54292246\r\n"+
        "chr16\t85316306\t85316724\r\n"+
        "chr4\t74320515\t74321053\r\n"+
        "chr3\t111847986\t111848683\r\n"+
        "chr11\t72609442\t72609876\r\n"+
        "chr16\t56654218\t56654626\r\n"+
        "chrX\t106917641\t106918211\r\n"+
        "chr17\t81365598\t81366216\r\n"+
        "chr16\t74577977\t74578475\r\n"+
        "chr1\t108865559\t108865976\r\n"+
        "chr5\t181260874\t181261313\r\n"+
        "chr6\t29965942\t29966411\r\n"+
        "chr2\t111117938\t111118322\r\n"+
        "chr15\t62254304\t62254673\r\n"+
        "chr7\t34339114\t34339618\r\n"+
        "chr11\t2526923\t2527323\r\n"+
        "chr6\t11093374\t11094332\r\n"+
        "chr3\t50260039\t50260783\r\n"+
        "chr19\t47190114\t47190861\r\n"+
        "chr3\t126260938\t126261327\r\n"+
        "chr12\t70449207\t70449873\r\n"+
        "chr15\t23039412\t23039868\r\n"+
        "chr4\t173252194\t173252722\r\n"+
        "chr8\t128554784\t128555493\r\n"+
        "chr1\t15152352\t15153067\r\n"+
        "chr12\t117105867\t117106236\r\n"+
        "chr18\t49656048\t49656533\r\n"+
        "chr13\t44281628\t44281991\r\n"+
        "chr1\t3320495\t3320909\r\n"+
        "chr1\t181310454\t181310880\r\n"+
        "chr22\t40636385\t40637103\r\n"+
        "chr19\t38374373\t38374997\r\n"+
        "chr7\t149028439\t149029035\r\n"+
        "chr2\t113818462\t113818994\r\n"+
        "chr19\t48558144\t48558678\r\n"+
        "chr19\t6199161\t6199776\r\n"+
        "chr15\t66701896\t66702448\r\n"+
        "chr17\t39753848\t39754609\r\n"+
        "chr4\t108247663\t108248111\r\n"+
        "chr19\t45584702\t45585114\r\n"+
        "chr1\t202283294\t202283843\r\n"+
        "chr10\t86365655\t86366270\r\n"+
        "chr2\t219522051\t219522425\r\n"+
        "chr2\t181810765\t181811173\r\n"+
        "chr8\t125498238\t125498616\r\n"+
        "chr7\t50446591\t50447054\r\n"+
        "chr7\t98822488\t98822977\r\n"+
        "chr16\t87777631\t87778135\r\n"+
        "chr12\t116497014\t116497530\r\n"+
        "chr3\t11136839\t11137614\r\n"+
        "chr17\t59154732\t59155468\r\n"+
        "chr10\t75498349\t75498864\r\n"+
        "chr18\t24076226\t24076588\r\n"+
        "chr15\t67065348\t67065950\r\n"+
        "chr8\t29348550\t29349054\r\n"+
        "chr4\t55346129\t55346779\r\n"+
        "chr5\t174571795\t174572281\r\n"+
        "chr7\t121298702\t121299178\r\n"+
        "chr10\t124380935\t124381498\r\n"+
        "chr5\t91314024\t91314664\r\n"+
        "chr9\t127388350\t127388746\r\n"+
        "chr4\t15906031\t15906521\r\n"+
        "chrX\t96684439\t96684915\r\n"+
        "chr17\t77002113\t77002825\r\n"+
        "chr21\t29187725\t29188313\r\n"+
        "chr10\t113007252\t113007671\r\n"+
        "chr10\t11684642\t11685143\r\n"+
        "chr3\t189132238\t189132811\r\n"+
        "chr12\t55956044\t55956424\r\n"+
        "chr16\t9160036\t9160456\r\n"+
        "chr2\t226063681\t226064184\r\n"+
        "chr2\t100291128\t100291663\r\n"+
        "chr15\t62066768\t62067148\r\n"+
        "chr6\t157428783\t157429177\r\n"+
        "chr1\t60281424\t60282028\r\n"+
        "chr17\t38703698\t38704390\r\n"+
        "chr7\t155965051\t155965569\r\n"+
        "chr2\t170714543\t170715822\r\n"+
        "chr19\t1028379\t1029022\r\n"+
        "chr8\t86703317\t86703718\r\n"+
        "chrGL000219.1\t42292\t42790\r\n"+
        "chr6\t79631099\t79631580\r\n"+
        "chr17\t57867990\t57868695\r\n"+
        "chr10\t17029561\t17029987\r\n"+
        "chr11\t34685159\t34685666\r\n"+
        "chr16\t88455522\t88456315\r\n"+
        "chr10\t42782526\t42782973\r\n"+
        "chr19\t48354508\t48354975\r\n"+
        "chr11\t15074577\t15075189\r\n"+
        "chr21\t31354498\t31355269\r\n"+
        "chr12\t95942763\t95943600\r\n"+
        "chr5\t139138819\t139139175\r\n"+
        "chr12\t109695959\t109696442\r\n"+
        "chr6\t135497446\t135497936\r\n"+
        "chr4\t4856264\t4857112\r\n"+
        "chr4\t121376103\t121376478\r\n"+
        "chr14\t44316900\t44317283\r\n"+
        "chr3\t50171622\t50172059\r\n"+
        "chr10\t112950020\t112950513\r\n"+
        "chr10\t101191004\t101191415\r\n"+
        "chr2\t172253209\t172254056\r\n"+
        "chr1\t55572891\t55573501\r\n"+
        "chr2\t156339425\t156339853\r\n"+
        "chr3\t93470265\t93470878\r\n"+
        "chr6\t44073069\t44073543\r\n"+
        "chr12\t116528044\t116528481\r\n"+
        "chr17\t17042095\t17042457\r\n"+
        "chr1\t95384526\t95384925\r\n"+
        "chr17\t71071012\t71071450\r\n"+
        "chr19\t49987151\t49987562\r\n"+
        "chr1\t51284439\t51284812\r\n"+
        "chr9\t113884943\t113885283\r\n"+
        "chr2\t37376552\t37377126\r\n"+
        "chr11\t27753909\t27754501\r\n"+
        "chr4\t100299079\t100299965\r\n"+
        "chr1\t204493461\t204494501\r\n"+
        "chr17\t17900593\t17901325\r\n"+
        "chr9\t130499868\t130500229\r\n"+
        "chr5\t137833486\t137833853\r\n"+
        "chr14\t53613545\t53614278\r\n"+
        "chr12\t75766673\t75767095\r\n"+
        "chr17\t58007104\t58007824\r\n"+
        "chr10\t52376746\t52377218\r\n"+
        "chr6\t15132834\t15133605\r\n"+
        "chr4\t11505380\t11506059\r\n"+
        "chr14\t53458207\t53458873\r\n"+
        "chr8\t22693408\t22693818\r\n"+
        "chr6\t44041589\t44042106\r\n"+
        "chr11\t2463128\t2463930\r\n"+
        "chr12\t26114274\t26114772\r\n"+
        "chr8\t125644251\t125644785\r\n"+
        "chr1\t164748206\t164748882\r\n"+
        "chr13\t44243087\t44243895\r\n"+
        "chr17\t933356\t933802\r\n"+
        "chr9\t132857602\t132858062\r\n"+
        "chr1\t77024531\t77024867\r\n"+
        "chr13\t22793475\t22794100\r\n"+
        "chr11\t78030466\t78030918\r\n"+
        "chr12\t91804462\t91804908\r\n"+
        "chr13\t20419680\t20420364\r\n"+
        "chr3\t57450784\t57451192\r\n"+
        "chr3\t72661011\t72661400\r\n"+
        "chr11\t75035922\t75036438\r\n"+
        "chr12\t93570131\t93571060\r\n"+
        "chr2\t46967901\t46968319\r\n"+
        "chr1\t56688430\t56689029\r\n"+
        "chr9\t129488524\t129489060\r\n"+
        "chr1\t94310307\t94310996\r\n"+
        "chr12\t88878259\t88878965\r\n"+
        "chr4\t56436940\t56437443\r\n"+
        "chr8\t143597037\t143597791\r\n"+
        "chr19\t41176048\t41176625\r\n"+
        "chr1\t236471654\t236472022\r\n"+
        "chr2\t218659274\t218659859\r\n"+
        "chr9\t110016175\t110016673\r\n"+
        "chr5\t37370758\t37371482\r\n"+
        "chr5\t82386987\t82387875\r\n"+
        "chr11\t108897037\t108897664\r\n"+
        "chr1\t206470730\t206471365\r\n"+
        "chr15\t80989920\t80990255\r\n"+
        "chr1\t200040544\t200040922\r\n"+
        "chr8\t103372135\t103372591\r\n"+
        "chr11\t28146123\t28146503\r\n"+
        "chr7\t92835296\t92835823\r\n"+
        "chr8\t125679928\t125680560\r\n"+
        "chr7\t50962892\t50963518\r\n"+
        "chr8\t125655524\t125656240\r\n"+
        "chr2\t52082745\t52083740\r\n"+
        "chr11\t85815402\t85815813\r\n"+
        "chr10\t110372733\t110373192\r\n"+
        "chr1\t156706110\t156706939\r\n"+
        "chr3\t188948040\t188948895\r\n"+
        "chr1\t53238253\t53238713\r\n"+
        "chr2\t149994311\t149994814\r\n"+
        "chr16\t86479442\t86479841\r\n"+
        "chr6\t169292581\t169293110\r\n"+
        "chr1\t21586950\t21587498\r\n"+
        "chr22\t28917922\t28918527\r\n"+
        "chrX\t45506943\t45507367\r\n"+
        "chr12\t50247176\t50247598\r\n"+
        "chr18\t31241879\t31242280\r\n"+
        "chr3\t185473466\t185473897\r\n"+
        "chr3\t156816837\t156817482\r\n"+
        "chr6\t15763839\t15764201\r\n"+
        "chr11\t61508155\t61508730\r\n"+
        "chr8\t79023646\t79023951\r\n"+
        "chr6\t18692913\t18693336\r\n"+
        "chr8\t28118360\t28118871\r\n"+
        "chr16\t28277669\t28278129\r\n"+
        "chr14\t61537501\t61537980\r\n"+
        "chr7\t6015884\t6016340\r\n"+
        "chr8\t29402121\t29402552\r\n"+
        "chr11\t96389514\t96390033\r\n"+
        "chr8\t127330099\t127330874\r\n"+
        "chr7\t131015595\t131015987\r\n"+
        "chr6\t6811202\t6812081\r\n"+
        "chr6\t155171134\t155171564\r\n"+
        "chr1\t212030983\t212031297\r\n"+
        "chr6\t21000219\t21000828\r\n"+
        "chr15\t65185384\t65185778\r\n"+
        "chr20\t56554871\t56555290\r\n"+
        "chr6\t21742409\t21742744\r\n"+
        "chr2\t191245930\t191246354\r\n"+
        "chr9\t28213010\t28213426\r\n"+
        "chr17\t77288758\t77289134\r\n"+
        "chr7\t126701047\t126701457\r\n"+
        "chr8\t127320967\t127321543\r\n"+
        "chr1\t198935420\t198935860\r\n"+
        "chr4\t97367862\t97368204\r\n"+
        "chr6\t44084662\t44085086\r\n"+
        "chr10\t103451039\t103451409\r\n"+
        "chr11\t12802613\t12803000\r\n"+
        "chr17\t14302575\t14303061\r\n"+
        "chr6\t14622019\t14622578\r\n"+
        "chr2\t176621364\t176621863\r\n"+
        "chr10\t117496550\t117496921\r\n"+
        "chr22\t32411841\t32412383\r\n"+
        "chr21\t45405683\t45406247\r\n"+
        "chr6\t92810901\t92811241\r\n"+
        "chr20\t8019451\t8020075\r\n"+
        "chr9\t107243674\t107244159\r\n"+
        "chr7\t20777585\t20778354\r\n"+
        "chr7\t105830384\t105830817\r\n"+
        "chr2\t159124508\t159125014\r\n"+
        "chr9\t83620807\t83621233\r\n"+
        "chr2\t136236058\t136236462\r\n"+
        "chr16\t75305343\t75305894\r\n"+
        "chr10\t124093443\t124093869\r\n"+
        "chr10\t52313961\t52314443\r\n"+
        "chr1\t27686493\t27687011\r\n"+
        "chr5\t174735359\t174735998\r\n"+
        "chr17\t57295172\t57295871\r\n"+
        "chr6\t21241121\t21241533\r\n"+
        "chr12\t89353835\t89354395\r\n"+
        "chrX\t155026718\t155027194\r\n"+
        "chr10\t97070032\t97070436\r\n"+
        "chr3\t7876773\t7877297\r\n"+
        "chr1\t199733955\t199734603\r\n"+
        "chr6\t46649100\t46649506\r\n"+
        "chrX\t118823582\t118824090\r\n"+
        "chr11\t76210554\t76211047\r\n"+
        "chr17\t75706918\t75707455\r\n"+
        "chr6\t129191201\t129191664\r\n"+
        "chr5\t62305742\t62306331\r\n"+
        "chr19\t45607296\t45607702\r\n"+
        "chr10\t63712028\t63712661\r\n"+
        "chr14\t34982393\t34983066\r\n"+
        "chr10\t112519116\t112519764\r\n"+
        "chr6\t117195700\t117196140\r\n"+
        "chr17\t48972394\t48972812\r\n"+
        "chr11\t94734580\t94734949\r\n"+
        "chr2\t36561349\t36561885\r\n"+
        "chr14\t76904882\t76905282\r\n"+
        "chr2\t42132953\t42133436\r\n"+
        "chr15\t74461027\t74461671\r\n"+
        "chr16\t28925382\t28925901\r\n"+
        "chr6\t34248676\t34249297\r\n"+
        "chr1\t85328948\t85329336\r\n"+
        "chr13\t30832806\t30833303\r\n"+
        "chr16\t75623033\t75623464\r\n"+
        "chr5\t179732490\t179732930\r\n"+
        "chr16\t85329320\t85329871\r\n"+
        "chr2\t238864197\t238864573\r\n"+
        "chr13\t95256123\t95256510\r\n"+
        "chr2\t238597120\t238597521\r\n"+
        "chr21\t29168734\t29169247\r\n"+
        "chr6\t8958886\t8959331\r\n"+
        "chr1\t225767574\t225768088\r\n"+
        "chr1\t94068119\t94068613\r\n"+
        "chr8\t66026445\t66026853\r\n"+
        "chr4\t25953754\t25954252\r\n"+
        "chr11\t1842523\t1842922\r\n"+
        "chr2\t25376820\t25377315\r\n"+
        "chr6\t98957441\t98957821\r\n"+
        "chr9\t72557535\t72557973\r\n"+
        "chr9\t133375883\t133376320\r\n"+
        "chr8\t93935638\t93936266\r\n"+
        "chr14\t76956393\t76956971\r\n"+
        "chr5\t57302238\t57302566\r\n"+
        "chr15\t51869099\t51869418\r\n"+
        "chr2\t70984838\t70985268\r\n"+
        "chr3\t119293753\t119294390\r\n"+
        "chr22\t37735154\t37735525\r\n"+
        "chr10\t114320664\t114321072\r\n"+
        "chr6\t44000246\t44000690\r\n"+
        "chr7\t35003713\t35004350\r\n"+
        "chr10\t32958057\t32958679\r\n"+
        "chr2\t27721413\t27721783\r\n"+
        "chr5\t57366766\t57367234\r\n"+
        "chr7\t20786717\t20787294\r\n"+
        "chr7\t138752501\t138753004\r\n"+
        "chr2\t26785744\t26786219\r\n"+
        "chr14\t53529552\t53529912\r\n"+
        "chr6\t56938613\t56939200\r\n"+
        "chr11\t109859396\t109859779\r\n"+
        "chr9\t127578960\t127579364\r\n"+
        "chr7\t92528395\t92529040\r\n"+
        "chr2\t177212965\t177213464\r\n"+
        "chr6\t129852278\t129852762\r\n"+
        "chr2\t172442015\t172442397\r\n"+
        "chr8\t127687156\t127687617\r\n"+
        "chr7\t55778643\t55779027\r\n"+
        "chr14\t54252049\t54252398\r\n"+
        "chr11\t93614479\t93614802\r\n"+
        "chr8\t37675136\t37675875\r\n"+
        "chr8\t72018598\t72018908\r\n"+
        "chr17\t82336448\t82336967\r\n"+
        "chr18\t61606714\t61607109\r\n"+
        "chr11\t69825118\t69825508\r\n"+
        "chr4\t101155258\t101155725\r\n"+
        "chr17\t43906517\t43906946\r\n"+
        "chr1\t12573805\t12574210\r\n"+
        "chr9\t15422523\t15423031\r\n"+
        "chr5\t131796758\t131797271\r\n"+
        "chr1\t150515180\t150515853\r\n"+
        "chr10\t124354717\t124355318\r\n"+
        "chr17\t1268105\t1268685\r\n"+
        "chr1\t84271602\t84272128\r\n"+
        "chr4\t78954072\t78954483\r\n"+
        "chr3\t31288618\t31289125\r\n"+
        "chr10\t96043217\t96043799\r\n"+
        "chr2\t241271871\t241272220\r\n"+
        "chr12\t65656864\t65657394\r\n"+
        "chr5\t102959084\t102959432\r\n"+
        "chr8\t93883391\t93883818\r\n"+
        "chr22\t29004500\t29005283\r\n"+
        "chr16\t29863089\t29863734\r\n"+
        "chr4\t124631755\t124632118\r\n"+
        "chr6\t32177640\t32178094\r\n"+
        "chr2\t226124509\t226124918\r\n"+
        "chr17\t40516721\t40517301\r\n"+
        "chr2\t226115033\t226115452\r\n"+
        "chr12\t75457700\t75458172\r\n"+
        "chr9\t6955283\t6955774\r\n"+
        "chr17\t75036651\t75037057\r\n"+
        "chr5\t134114490\t134115151\r\n"+
        "chr12\t47943572\t47943975\r\n"+
        "chr17\t72413196\t72413697\r\n"+
        "chr2\t226652356\t226652793\r\n"+
        "chr1\t229064391\t229064868\r\n"+
        "chr12\t43758660\t43759033\r\n"+
        "chr1\t211735693\t211736254\r\n"+
        "chr12\t91778933\t91779325\r\n"+
        "chr21\t43880279\t43880647\r\n"+
        "chr3\t30282153\t30282691\r\n"+
        "chr22\t37318198\t37318797\r\n"+
        "chr1\t113904829\t113905494\r\n"+
        "chr3\t98971105\t98971651\r\n"+
        "chr20\t38779668\t38780213\r\n"+
        "chr11\t47848082\t47848595\r\n"+
        "chr6\t12008449\t12008875\r\n"+
        "chrX\t37685404\t37685767\r\n"+
        "chr12\t53324816\t53326020\r\n"+
        "chr7\t106775512\t106775938\r\n"+
        "chr12\t45215758\t45216263\r\n"+
        "chr1\t7902607\t7903048\r\n"+
        "chr16\t87457710\t87458103\r\n"+
        "chr7\t44606383\t44607257\r\n"+
        "chr11\t103682187\t103682672\r\n"+
        "chr10\t64209580\t64210041\r\n"+
        "chr17\t82228137\t82228594\r\n"+
        "chr16\t56682212\t56682674\r\n"+
        "chr6\t21005777\t21006168\r\n"+
        "chr1\t93813957\t93814357\r\n"+
        "chr15\t74540714\t74541119\r\n"+
        "chr4\t174283605\t174284111\r\n"+
        "chr1\t33436857\t33437256\r\n"+
        "chr15\t58770667\t58771355\r\n"+
        "chr9\t124309585\t124310110\r\n"+
        "chr20\t3811554\t3812161\r\n"+
        "chr16\t11084399\t11084851\r\n"+
        "chr20\t54132764\t54133350\r\n"+
        "chr5\t113166929\t113167401\r\n"+
        "chr4\t36394324\t36394942\r\n"+
        "chr22\t42964999\t42965449\r\n"+
        "chr17\t46822377\t46823012\r\n"+
        "chr1\t171916334\t171916877\r\n"+
        "chr5\t136016912\t136017524\r\n"+
        "chr2\t191020176\t191020591\r\n"+
        "chr5\t149551366\t149551979\r\n"+
        "chr1\t147670352\t147670828\r\n"+
        "chr17\t74442668\t74443358\r\n"+
        "chr1\t147545119\t147545489\r\n"+
        "chr1\t54488197\t54488662\r\n"+
        "chr1\t159925278\t159925868\r\n"+
        "chr2\t70328907\t70329515\r\n"+
        "chr7\t127820255\t127820644\r\n"+
        "chr8\t125125515\t125126257\r\n"+
        "chr22\t36454981\t36455425\r\n"+
        "chr12\t13739666\t13740009\r\n"+
        "chr10\t112517433\t112517879\r\n"+
        "chr12\t57522125\t57522725\r\n"+
        "chr3\t197959921\t197960342\r\n"+
        "chr4\t3836614\t3837297\r\n"+
        "chr4\t11650685\t11651184\r\n"+
        "chr10\t38010396\t38011243\r\n"+
        "chr21\t28517009\t28517417\r\n"+
        "chr17\t46795481\t46795861\r\n"+
        "chr8\t93869258\t93869981\r\n"+
        "chr6\t73224221\t73224627\r\n"+
        "chr17\t57860809\t57861723\r\n"+
        "chr10\t25059896\t25060341\r\n"+
        "chr11\t46309865\t46310194\r\n"+
        "chr2\t113877838\t113878301\r\n"+
        "chr12\t75640982\t75641350\r\n"+
        "chr14\t53391206\t53392072\r\n"+
        "chr10\t119596598\t119597384\r\n"+
        "chr5\t80181675\t80182046\r\n"+
        "chr12\t52050761\t52051748\r\n"+
        "chr17\t75700361\t75700788\r\n"+
        "chr11\t27838604\t27839129\r\n"+
        "chr4\t121071992\t121072529\r\n"+
        "chr17\t45060937\t45061468\r\n"+
        "chr5\t57383032\t57383526\r\n"+
        "chr19\t45692082\t45692856\r\n"+
        "chr22\t30649440\t30649870\r\n"+
        "chr4\t121448248\t121448655\r\n"+
        "chr1\t55384541\t55385145\r\n"+
        "chr2\t224145792\t224146264\r\n"+
        "chr12\t31749168\t31749646\r\n"+
        "chr5\t124289717\t124290176\r\n"+
        "chr9\t35732099\t35732539\r\n"+
        "chr18\t48948432\t48948796\r\n"+
        "chr7\t106346586\t106347024\r\n"+
        "chr19\t29845073\t29845454\r\n"+
        "chr14\t54177836\t54178465\r\n"+
        "chr4\t57043740\t57044246\r\n"+
        "chr6\t92647623\t92647967\r\n"+
        "chr11\t45922019\t45922730\r\n"+
        "chr18\t70181007\t70181421\r\n"+
        "chr6\t89298731\t89299164\r\n"+
        "chr3\t98922745\t98923225\r\n"+
        "chr6\t129501230\t129501767\r\n"+
        "chr6\t90587214\t90587564\r\n"+
        "chr9\t128052012\t128052437\r\n"+
        "chr1\t234599653\t234600087\r\n"+
        "chr20\t19692583\t19692984\r\n"+
        "chr3\t143648180\t143648555\r\n"+
        "chr12\t53451757\t53452174\r\n"+
        "chr2\t226694173\t226694589\r\n"+
        "chr8\t112674152\t112674761\r\n"+
        "chr3\t114650848\t114651275\r\n"+
        "chr7\t7177129\t7177472\r\n"+
        "chr13\t109211659\t109212009\r\n"+
        "chr4\t114026282\t114026830\r\n"+
        "chr13\t35855530\t35855987\r\n"+
        "chr10\t52391958\t52392293\r\n"+
        "chr1\t219784961\t219785584\r\n"+
        "chr11\t62123569\t62123956\r\n"+
        "chr17\t72421180\t72421655\r\n"+
        "chrX\t46320311\t46320822\r\n"+
        "chr20\t2626882\t2627249\r\n"+
        "chr8\t112675327\t112675705\r\n"+
        "chr8\t112398361\t112398857\r\n"+
        "chr4\t74768871\t74769195\r\n"+
        "chr3\t90080940\t90081484\r\n"+
        "chr1\t8120961\t8121657\r\n"+
        "chr7\t101143984\t101144327\r\n"+
        "chr12\t88960337\t88960956\r\n"+
        "chr10\t11035361\t11035681\r\n"+
        "chr5\t95730859\t95731444\r\n"+
        "chr3\t46065252\t46065752\r\n"+
        "chr5\t40835056\t40835456\r\n"+
        "chr10\t86971013\t86971942\r\n"+
        "chr2\t239275094\t239275536\r\n"+
        "chr4\t74629254\t74629631\r\n"+
        "chr1\t199784139\t199784610\r\n"+
        "chr1\t84174128\t84174681\r\n"+
        "chr4\t88284456\t88284992\r\n"+
        "chr17\t71632315\t71632746\r\n"+
        "chr1\t154974340\t154975021\r\n"+
        "chr3\t171248353\t171248780\r\n"+
        "chr6\t16511856\t16512345\r\n"+
        "chr8\t50666136\t50666540\r\n"+
        "chr3\t36362885\t36363362\r\n"+
        "chr17\t42055589\t42055985\r\n"+
        "chr1\t156103558\t156103942\r\n"+
        "chrX\t47658868\t47659519\r\n"+
        "chr22\t36451729\t36452116\r\n"+
        "chr8\t127247188\t127247715\r\n"+
        "chr1\t234724021\t234724733\r\n"+
        "chr19\t2977219\t2977641\r\n"+
        "chr1\t39117170\t39117672\r\n"+
        "chrX\t106300221\t106300618\r\n"+
        "chr2\t241149129\t241149649\r\n"+
        "chr11\t121928963\t121929449\r\n"+
        "chr9\t127699119\t127699586\r\n"+
        "chr10\t1048871\t1049483\r\n"+
        "chr1\t213443432\t213443759\r\n"+
        "chr11\t19723612\t19724124\r\n"+
        "chr3\t151971807\t151972212\r\n"+
        "chr7\t39949301\t39950277\r\n"+
        "chrKI270713.1\t28450\t28945\r\n"+
        "chr14\t57268600\t57269295\r\n"+
        "chr13\t24670902\t24671282\r\n"+
        "chr20\t31608425\t31608929\r\n"+
        "chr7\t14748429\t14748816\r\n"+
        "chr4\t165112218\t165112868\r\n"+
        "chr10\t76051047\t76051497\r\n"+
        "chr6\t53615657\t53616106\r\n"+
        "chr11\t628504\t628904\r\n"+
        "chr3\t33717618\t33718410\r\n"+
        "chr22\t46267537\t46267972\r\n"+
        "chr20\t9977510\t9978047\r\n"+
        "chr12\t65300092\t65300558\r\n"+
        "chr22\t31646335\t31647033\r\n"+
        "chr17\t81393672\t81394257\r\n"+
        "chr9\t137423045\t137423390\r\n"+
        "chr1\t43008331\t43009133\r\n"+
        "chr2\t219698754\t219699395\r\n"+
        "chr9\t21995044\t21995946\r\n"+
        "chr19\t13846405\t13847269\r\n"+
        "chr9\t75890398\t75890753\r\n"+
        "chr4\t119300395\t119301080\r\n"+
        "chr18\t59358602\t59359361\r\n"+
        "chr5\t1933326\t1933753\r\n"+
        "chr7\t5594085\t5594463\r\n"+
        "chr1\t7300989\t7301303\r\n"+
        "chr1\t68213882\t68214299\r\n"+
        "chr12\t88931595\t88931934\r\n"+
        "chr1\t213176220\t213176792\r\n"+
        "chr17\t41071584\t41072017\r\n"+
        "chr6\t75065598\t75065967\r\n"+
        "chr16\t15494240\t15494629\r\n"+
        "chr6\t35731835\t35732531\r\n"+
        "chr8\t29555264\t29555787\r\n"+
        "chr18\t68916635\t68917082\r\n"+
        "chr17\t76029403\t76029867\r\n"+
        "chr17\t17783071\t17783752\r\n"+
        "chr5\t82356837\t82357634\r\n"+
        "chr14\t68598771\t68599390\r\n"+
        "chr1\t8231978\t8232490\r\n"+
        "chr2\t161123081\t161123626\r\n"+
        "chr1\t84253881\t84254378\r\n"+
        "chr17\t1617560\t1618195\r\n"+
        "chr5\t133489677\t133490066\r\n"+
        "chr8\t112616438\t112616837\r\n"+
        "chr3\t193869296\t193870086\r\n"+
        "chr4\t98260215\t98261226\r\n"+
        "chrX\t2894710\t2895270\r\n"+
        "chr3\t48240916\t48241318\r\n"+
        "chr12\t88934263\t88934838\r\n"+
        "chr3\t195040804\t195041166\r\n"+
        "chr7\t13908678\t13909371\r\n"+
        "chr17\t13776124\t13776693\r\n"+
        "chr7\t116210269\t116210801\r\n"+
        "chr11\t76839360\t76839731\r\n"+
        "chr17\t2511742\t2512314\r\n"+
        "chr3\t177357405\t177357823\r\n"+
        "chr6\t132063696\t132064101\r\n"+
        "chr19\t610702\t611464\r\n"+
        "chr7\t79711685\t79712051\r\n"+
        "chr2\t110212346\t110212804\r\n"+
        "chr21\t35051275\t35051623\r\n"+
        "chr12\t88753043\t88753489\r\n"+
        "chr3\t78507287\t78507804\r\n"+
        "chr4\t181150205\t181150614\r\n"+
        "chr7\t80722790\t80723181\r\n"+
        "chr9\t114278907\t114279315\r\n"+
        "chr1\t199685392\t199685741\r\n"+
        "chr2\t130240986\t130241352\r\n"+
        "chr1\t75034297\t75034716\r\n"+
        "chr19\t10332848\t10333437\r\n"+
        "chr16\t11497968\t11498316\r\n"+
        "chr12\t98399534\t98399943\r\n"+
        "chr14\t80941617\t80942069\r\n"+
        "chr1\t181104686\t181105412\r\n"+
        "chrX\t1481639\t1482154\r\n"+
        "chr2\t232988452\t232988893\r\n"+
        "chr10\t73932345\t73932746\r\n"+
        "chr10\t52452500\t52453106\r\n"+
        "chr15\t55279705\t55280014\r\n"+
        "chr6\t46993875\t46994255\r\n"+
        "chr8\t88715556\t88716184\r\n"+
        "chr15\t23566110\t23566535\r\n"+
        "chr1\t33433540\t33434132\r\n"+
        "chr2\t28711713\t28712076\r\n"+
        "chr15\t22776000\t22776362\r\n"+
        "chr7\t142583514\t142583860\r\n"+
        "chr12\t46371248\t46371832\r\n"+
        "chr2\t236078278\t236078883\r\n"+
        "chr1\t94247359\t94248018\r\n"+
        "chr7\t97104642\t97105025\r\n"+
        "chr6\t63527671\t63528035\r\n"+
        "chr3\t45167383\t45167888\r\n"+
        "chr20\t57168050\t57168642\r\n"+
        "chr7\t130845250\t130846061\r\n"+
        "chr4\t113468221\t113468718\r\n"+
        "chr9\t2260647\t2261484\r\n"+
        "chr14\t57833239\t57833754\r\n"+
        "chr15\t50116511\t50116846\r\n"+
        "chr1\t15834378\t15835304\r\n"+
        "chr18\t8389707\t8390058\r\n"+
        "chr7\t25951041\t25951394\r\n"+
        "chr3\t46109270\t46109610\r\n"+
        "chr2\t226673246\t226673817\r\n"+
        "chr7\t27453772\t27454263\r\n"+
        "chr15\t64703195\t64703554\r\n"+
        "chr2\t110105854\t110106474\r\n"+
        "chr1\t199759031\t199759772\r\n"+
        "chr7\t25862431\t25862964\r\n"+
        "chr15\t96273519\t96274095\r\n"+
        "chr22\t50485505\t50486121\r\n"+
        "chr2\t60581734\t60582125\r\n"+
        "chr2\t234880500\t234880882\r\n"+
        "chr15\t75775303\t75775661\r\n"+
        "chr10\t58384919\t58385545\r\n"+
        "chr17\t67421841\t67422283\r\n"+
        "chr5\t151745087\t151745627\r\n"+
        "chr4\t1521204\t1521657\r\n"+
        "chr6\t18584978\t18585494\r\n"+
        "chr21\t36141540\t36142014\r\n"+
        "chr8\t127215016\t127215608\r\n"+
        "chr11\t36231316\t36231677\r\n"+
        "chr20\t38764971\t38765526\r\n"+
        "chr4\t151324317\t151325135\r\n"+
        "chr6\t27177661\t27178163\r\n"+
        "chr7\t73433514\t73433866\r\n"+
        "chr7\t81012941\t81013428\r\n"+
        "chr2\t74529636\t74530060\r\n"+
        "chr8\t128167630\t128168146\r\n"+
        "chr12\t53675768\t53676401\r\n"+
        "chr8\t127400806\t127401306\r\n"+
        "chr17\t40480549\t40481181\r\n"+
        "chr17\t43545438\t43546514\r\n"+
        "chr16\t50548169\t50548572\r\n"+
        "chr8\t124372339\t124372906\r\n"+
        "chr9\t755681\t756049\r\n"+
        "chr4\t186824747\t186825453\r\n"+
        "chr1\t152543858\t152544245\r\n"+
        "chr7\t102440175\t102440559\r\n"+
        "chr5\t133051313\t133052055\r\n"+
        "chr12\t109713445\t109713869\r\n"+
        "chr1\t203661578\t203661942\r\n"+
        "chr1\t100132735\t100133233\r\n"+
        "chr20\t50165971\t50166533\r\n"+
        "chr7\t16989927\t16990399\r\n"+
        "chr15\t70528264\t70528630\r\n"+
        "chr20\t62739976\t62740744\r\n"+
        "chr19\t45154491\t45154885\r\n"+
        "chr12\t75666950\t75667348\r\n"+
        "chr19\t19138326\t19138955\r\n"+
        "chr7\t99504299\t99504877\r\n"+
        "chr1\t55472755\t55473192\r\n"+
        "chr8\t125647887\t125648406\r\n"+
        "chr7\t134554009\t134554354\r\n"+
        "chr17\t64661915\t64662367\r\n"+
        "chr12\t95334442\t95334760\r\n"+
        "chr1\t30526050\t30526641\r\n"+
        "chr11\t59545140\t59545685\r\n"+
        "chr19\t18380088\t18380665\r\n"+
        "chr5\t90645000\t90645360\r\n"+
        "chr17\t39632300\t39632906\r\n"+
        "chr1\t40875652\t40876061\r\n"+
        "chr3\t61561017\t61561711\r\n"+
        "chr5\t104512917\t104513661\r\n"+
        "chr5\t68505927\t68506296\r\n"+
        "chr7\t81235738\t81236311\r\n"+
        "chr12\t54033232\t54033846\r\n"+
        "chr11\t15053179\t15053729\r\n"+
        "chr15\t74196237\t74196645\r\n"+
        "chr19\t940609\t941264\r\n"+
        "chr1\t25167309\t25167934\r\n"+
        "chr17\t45161351\t45161991\r\n"+
        "chr2\t168216485\t168216975\r\n"+
        "chr14\t54258309\t54258810\r\n"+
        "chr1\t230702970\t230703359\r\n"+
        "chr8\t127297532\t127297996\r\n"+
        "chr4\t85474733\t85475263\r\n"+
        "chr6\t78867286\t78868063\r\n"+
        "chr10\t80498723\t80499206\r\n"+
        "chr6\t20630935\t20631386\r\n"+
        "chr2\t179239262\t179239617\r\n"+
        "chr9\t124769639\t124770178\r\n"+
        "chr11\t62880831\t62881793\r\n"+
        "chr6\t150813977\t150814356\r\n"+
        "chr1\t12618983\t12619401\r\n"+
        "chr1\t3313019\t3313516\r\n"+
        "chr2\t171687341\t171688046\r\n"+
        "chr7\t100538499\t100539264\r\n"+
        "chr1\t216325997\t216326398\r\n"+
        "chr13\t19596897\t19597199\r\n"+
        "chr17\t76264824\t76265398\r\n"+
        "chr1\t59156747\t59157198\r\n"+
        "chr6\t46105499\t46105946\r\n"+
        "chr11\t27933991\t27934590\r\n"+
        "chr10\t4663177\t4663866\r\n"+
        "chr22\t39308857\t39309202\r\n"+
        "chr1\t244801275\t244801612\r\n"+
        "chr18\t70371115\t70371651\r\n"+
        "chr18\t75489778\t75490217\r\n"+
        "chr14\t22689219\t22689593\r\n"+
        "chr2\t85754692\t85755036\r\n"+
        "chr1\t219669089\t219669476\r\n"+
        "chr14\t92694042\t92694356\r\n"+
        "chr6\t137051708\t137052199\r\n"+
        "chr12\t65631615\t65632009\r\n"+
        "chr17\t1190694\t1191046\r\n"+
        "chrX\t48475871\t48476294\r\n"+
        "chr11\t69948304\t69948830\r\n"+
        "chr12\t109840708\t109841143\r\n"+
        "chr6\t151208199\t151208553\r\n"+
        "chr6\t150668375\t150668724\r\n"+
        "chr19\t12401021\t12401641\r\n"+
        "chr12\t88763466\t88763989\r\n"+
        "chr2\t79393636\t79394146\r\n"+
        "chr10\t75401542\t75402028\r\n"+
        "chr7\t151426518\t151427097\r\n"+
        "chr2\t121075154\t121075668\r\n"+
        "chr2\t181876604\t181877120\r\n"+
        "chr22\t41468918\t41469285\r\n"+
        "chr5\t23466358\t23466905\r\n"+
        "chr11\t59810609\t59811007\r\n"+
        "chr8\t127265617\t127266163\r\n"+
        "chr6\t130602213\t130602793\r\n"+
        "chr9\t72476972\t72477350\r\n"+
        "chr8\t134832381\t134833330\r\n"+
        "chr1\t941628\t942142\r\n"+
        "chr12\t124917180\t124917804\r\n"+
        "chr15\t57607608\t57608097\r\n"+
        "chr3\t114056436\t114056905\r\n"+
        "chr11\t10647397\t10647859\r\n"+
        "chr7\t50197568\t50197953\r\n"+
        "chr19\t11155692\t11156102\r\n"+
        "chr10\t63629446\t63629919\r\n"+
        "chr4\t183183215\t183183676\r\n"+
        "chr5\t10760049\t10760481\r\n"+
        "chr17\t71424080\t71424596\r\n"+
        "chr11\t119205762\t119206283\r\n"+
        "chr16\t30352074\t30352431\r\n"+
        "chr9\t127828263\t127828760\r\n"+
        "chr5\t149455850\t149456496\r\n"+
        "chr1\t247104123\t247104610\r\n"+
        "chr10\t117186794\t117187327\r\n"+
        "chr6\t158730488\t158731078\r\n"+
        "chr14\t21024675\t21025137\r\n"+
        "chr12\t3203000\t3203358\r\n"+
        "chr10\t117168098\t117168568\r\n"+
        "chr15\t40103294\t40103696\r\n"+
        "chr10\t95561040\t95561566\r\n"+
        "chr12\t14257616\t14258257\r\n"+
        "chr11\t76700336\t76700943\r\n"+
        "chr2\t224678264\t224679029\r\n"+
        "chr3\t107216905\t107217547\r\n"+
        "chr22\t18001254\t18002027\r\n"+
        "chr5\t90096740\t90097128\r\n"+
        "chr22\t39254783\t39255189\r\n"+
        "chr2\t226756136\t226756471\r\n"+
        "chr17\t33142743\t33143111\r\n"+
        "chr16\t11497315\t11497743\r\n"+
        "chr6\t36225025\t36225491\r\n"+
        "chr3\t23668367\t23668941\r\n"+
        "chr1\t199778288\t199778627\r\n"+
        "chr7\t77798290\t77798960\r\n"+
        "chr2\t58042610\t58042968\r\n"+
        "chr11\t117316084\t117316509\r\n"+
        "chr19\t461832\t462320\r\n"+
        "chr17\t43562832\t43563230\r\n"+
        "chr11\t69637781\t69638572\r\n"+
        "chr16\t69404243\t69404947\r\n"+
        "chr9\t21576423\t21577010\r\n"+
        "chr17\t82324529\t82324883\r\n"+
        "chr2\t81304329\t81305001\r\n"+
        "chr9\t2843939\t2844413\r\n"+
        "chr1\t84156135\t84156617\r\n"+
        "chr17\t46922678\t46923297\r\n"+
        "chr11\t47355248\t47355652\r\n"+
        "chr8\t93880109\t93880684\r\n"+
        "chr5\t95646598\t95647022\r\n"+
        "chr7\t22822710\t22823060\r\n"+
        "chr10\t73743937\t73744495\r\n"+
        "chr17\t65560453\t65562178\r\n"+
        "chr1\t244833681\t244834122\r\n"+
        "chr7\t130894145\t130894884\r\n"+
        "chr10\t110641246\t110641652\r\n"+
        "chr5\t68554851\t68555326\r\n"+
        "chr12\t2397719\t2398102\r\n"+
        "chr20\t297216\t297647\r\n"+
        "chr7\t121544676\t121545235\r\n"+
        "chr16\t21820252\t21820675\r\n"+
        "chr8\t129685581\t129685956\r\n"+
        "chr9\t33458526\t33458907\r\n"+
        "chr1\t219310129\t219310718\r\n"+
        "chr2\t70087920\t70088438\r\n"+
        "chr8\t19817159\t19817510\r\n"+
        "chr10\t121927857\t121928341\r\n"+
        "chr22\t43104007\t43104590\r\n"+
        "chr6\t28863290\t28863918\r\n"+
        "chr18\t48002992\t48003351\r\n"+
        "chr6\t100296861\t100297575\r\n"+
        "chr12\t27549760\t27550393\r\n"+
        "chr2\t37379861\t37380239\r\n"+
        "chr2\t175810\t176235\r\n"+
        "chr11\t95150586\t95151387\r\n"+
        "chr11\t33941594\t33941994\r\n"+
        "chr11\t35235885\t35236298\r\n"+
        "chr19\t47130591\t47131067\r\n"+
        "chr5\t111530304\t111530667\r\n"+
        "chr4\t103429313\t103429629\r\n"+
        "chr2\t201882378\t201882765\r\n"+
        "chr10\t21724647\t21725017\r\n"+
        "chr15\t85413439\t85413802\r\n"+
        "chr3\t120349216\t120349925\r\n"+
        "chr3\t9933541\t9933990\r\n"+
        "chr4\t4763400\t4763882\r\n"+
        "chr1\t170531675\t170532522\r\n"+
        "chrX\t1649605\t1649968\r\n"+
        "chr3\t20054517\t20054968\r\n"+
        "chrX\t49190746\t49191454\r\n"+
        "chr9\t97109195\t97109523\r\n"+
        "chr7\t121282082\t121282917\r\n"+
        "chr18\t63969906\t63970754\r\n"+
        "chr2\t38602785\t38603701\r\n"+
        "chr22\t37328001\t37328353\r\n"+
        "chr17\t10095326\t10095667\r\n"+
        "chr7\t129779736\t129780252\r\n"+
        "chr11\t121464523\t121465007\r\n"+
        "chr14\t54189754\t54190182\r\n"+
        "chr2\t65382782\t65383208\r\n"+
        "chr9\t110744691\t110745315\r\n"+
        "chr8\t102806089\t102807197\r\n"+
        "chr1\t11478697\t11479351\r\n"+
        "chr6\t158737615\t158738205\r\n"+
        "chr12\t108838163\t108838719\r\n"+
        "chr7\t44490376\t44490982\r\n"+
        "chr20\t37615875\t37616176\r\n"+
        "chr22\t46754336\t46754759\r\n"+
        "chr8\t128653282\t128653664\r\n"+
        "chr2\t155099633\t155100179\r\n"+
        "chr22\t42303875\t42304434\r\n"+
        "chr4\t180909351\t180909704\r\n"+
        "chr1\t82632117\t82632529\r\n"+
        "chr1\t204516239\t204516874\r\n"+
        "chr5\t173764391\t173764802\r\n"+
        "chr15\t69760851\t69761281\r\n"+
        "chr1\t15356062\t15356493\r\n"+
        "chr5\t45384031\t45384368\r\n"+
        "chr2\t232568172\t232568503\r\n"+
        "chr2\t26355481\t26355906\r\n"+
        "chr20\t54139179\t54139871\r\n"+
        "chr5\t157464405\t157464819\r\n"+
        "chr11\t109424930\t109425233\r\n"+
        "chr7\t44761794\t44762255\r\n"+
        "chr8\t28889831\t28890410\r\n"+
        "chr21\t45365669\t45366114\r\n"+
        "chr8\t131843029\t131843428\r\n"+
        "chr22\t37742370\t37742780\r\n"+
        "chr5\t142356674\t142357383\r\n"+
        "chr10\t37857482\t37857850\r\n"+
        "chr19\t23686826\t23687431\r\n"+
        "chr17\t59355104\t59355581\r\n"+
        "chr1\t25091001\t25091392\r\n"+
        "chr3\t32226844\t32227238\r\n"+
        "chr10\t102641997\t102642712\r\n"+
        "chr6\t4358591\t4359027\r\n"+
        "chr19\t18364894\t18365284\r\n"+
        "chr11\t12724302\t12724975\r\n"+
        "chr11\t122105383\t122105828\r\n"+
        "chr4\t74559891\t74560238\r\n"+
        "chr7\t44044475\t44044883\r\n"+
        "chr1\t66543460\t66543867\r\n"+
        "chr21\t36845102\t36845457\r\n"+
        "chr8\t125271406\t125271890\r\n"+
        "chr12\t105562091\t105562917\r\n"+
        "chr15\t81091974\t81092873\r\n"+
        "chr2\t231613685\t231614511\r\n"+
        "chr11\t10857679\t10858667\r\n"+
        "chr1\t16727235\t16728015\r\n"+
        "chrX\t17674583\t17674951\r\n"+
        "chr12\t49069619\t49070244\r\n"+
        "chr10\t114303968\t114304383\r\n"+
        "chr14\t53980083\t53980437\r\n"+
        "chr1\t219806651\t219807025\r\n"+
        "chr3\t111874434\t111874823\r\n"+
        "chr2\t181782650\t181783003\r\n"+
        "chr3\t194134858\t194135296\r\n"+
        "chr17\t63675881\t63676356\r\n"+
        "chr20\t21017656\t21018129\r\n"+
        "chr3\t101677018\t101677419\r\n"+
        "chr9\t105064572\t105064921\r\n"+
        "chr12\t121799953\t121800646\r\n"+
        "chr10\t103908204\t103908644\r\n"+
        "chr3\t42600264\t42600807\r\n"+
        "chr12\t52036863\t52037195\r\n"+
        "chr16\t89505409\t89505764\r\n"+
        "chr5\t145936396\t145936802\r\n"+
        "chr12\t57693713\t57694254\r\n"+
        "chr20\t33914952\t33915270\r\n"+
        "chr7\t33128897\t33129672\r\n"+
        "chr9\t134896346\t134896852\r\n"+
        "chr17\t2893526\t2894001\r\n"+
        "chr9\t109036097\t109036438\r\n"+
        "chr15\t41513637\t41514231\r\n"+
        "chr14\t93959357\t93959811\r\n"+
        "chr7\t130995407\t130996020\r\n"+
        "chrX\t1764985\t1765442\r\n"+
        "chr17\t81316702\t81317071\r\n"+
        "chr19\t35213760\t35214272\r\n"+
        "chr10\t101135900\t101136228\r\n"+
        "chr4\t57504218\t57504556\r\n"+
        "chr14\t55803758\t55804184\r\n"+
        "chr4\t31236911\t31237604\r\n"+
        "chr1\t25875144\t25875824\r\n"+
        "chr17\t79708549\t79708925\r\n"+
        "chr1\t27321981\t27322476\r\n"+
        "chr4\t100591148\t100591484\r\n"+
        "chr1\t76254218\t76254629\r\n"+
        "chr20\t2798797\t2799223\r\n"+
        "chr3\t195259493\t195260303\r\n"+
        "chr2\t11830067\t11830640\r\n"+
        "chr3\t12345237\t12345589\r\n"+
        "chr14\t100476333\t100476867\r\n"+
        "chr6\t47309709\t47310143\r\n"+
        "chr20\t36951162\t36951795\r\n"+
        "chr3\t98593533\t98594111\r\n"+
        "chr3\t156317377\t156317829\r\n"+
        "chr2\t237299973\t237300251\r\n"+
        "chr14\t63543033\t63543712\r\n"+
        "chr17\t72381795\t72382378\r\n"+
        "chr9\t133558099\t133558612\r\n"+
        "chr16\t69530599\t69531011\r\n"+
        "chr1\t16613287\t16614002\r\n"+
        "chr14\t90969972\t90970565\r\n"+
        "chr19\t37906982\t37907368\r\n"+
        "chr3\t149129362\t149129865\r\n"+
        "chr2\t225354361\t225354714\r\n"+
        "chr17\t65588263\t65588794\r\n"+
        "chr12\t31324089\t31324704\r\n"+
        "chr4\t41935011\t41935571\r\n"+
        "chr5\t134071072\t134071559\r\n"+
        "chr2\t27380425\t27381015\r\n"+
        "chr21\t43884028\t43884367\r\n"+
        "chr16\t67115647\t67115982\r\n"+
        "chr6\t35776521\t35777037\r\n"+
        "chr17\t10616477\t10616835\r\n"+
        "chr4\t186684828\t186685297\r\n"+
        "chr15\t84734954\t84735454\r\n"+
        "chr15\t78726885\t78727222\r\n"+
        "chr3\t182212430\t182213109\r\n"+
        "chr16\t30628793\t30629085\r\n"+
        "chr11\t104668973\t104669511\r\n"+
        "chr2\t226618662\t226619449\r\n"+
        "chr1\t3775956\t3776295\r\n"+
        "chr19\t58380490\t58381235\r\n"+
        "chr6\t151120073\t151120576\r\n"+
        "chr2\t234840349\t234840683\r\n"+
        "chr17\t44141698\t44142099\r\n"+
        "chr2\t181949138\t181949533\r\n"+
        "chr6\t35606084\t35606515\r\n"+
        "chr1\t53838059\t53838711\r\n"+
        "chr17\t54900279\t54900969\r\n"+
        "chr8\t18776567\t18776909\r\n"+
        "chr18\t9025513\t9025962\r\n"+
        "chr2\t233353569\t233354000\r\n"+
        "chr5\t91280404\t91281052\r\n"+
        "chr17\t80036367\t80036868\r\n"+
        "chr4\t74543220\t74543860\r\n"+
        "chr15\t60371310\t60371784\r\n"+
        "chr17\t17921245\t17921761\r\n"+
        "chr11\t23359307\t23359623\r\n"+
        "chr4\t42302362\t42302727\r\n"+
        "chr6\t35368458\t35368924\r\n"+
        "chr8\t125686250\t125686958\r\n"+
        "chr17\t2400950\t2401268\r\n"+
        "chr17\t48830707\t48831109\r\n"+
        "chr18\t9741836\t9742831\r\n"+
        "chr12\t75623629\t75624201\r\n"+
        "chr6\t121959487\t121959841\r\n"+
        "chr10\t89644524\t89645507\r\n"+
        "chr8\t106208720\t106209158\r\n"+
        "chr1\t116988272\t116988738\r\n"+
        "chr5\t17907131\t17907460\r\n"+
        "chr8\t124200005\t124200519\r\n"+
        "chr6\t142009621\t142010058\r\n"+
        "chr11\t34495628\t34496424\r\n"+
        "chr20\t46199239\t46199660\r\n"+
        "chr6\t81451773\t81452200\r\n"+
        "chr9\t129568571\t129569218\r\n"+
        "chr14\t23301274\t23301868\r\n"+
        "chr10\t12270855\t12271370\r\n"+
        "chr4\t30840194\t30840512\r\n"+
        "chr8\t37598519\t37598910\r\n"+
        "chr4\t185573690\t185574213\r\n"+
        "chr6\t142944392\t142944891\r\n"+
        "chr6\t2857489\t2858111\r\n"+
        "chr2\t240255994\t240256380\r\n"+
        "chr1\t211675496\t211676160\r\n"+
        "chr20\t31704537\t31704953\r\n"+
        "chr10\t100697135\t100697572\r\n"+
        "chr2\t111049736\t111050152\r\n"+
        "chr3\t139202398\t139202836\r\n"+
        "chr1\t211258735\t211259402\r\n"+
        "chr1\t224542859\t224543216\r\n"+
        "chr2\t235347674\t235348125\r\n"+
        "chr1\t203177892\t203178481\r\n"+
        "chr9\t100098895\t100099615\r\n"+
        "chr13\t85313766\t85314269\r\n"+
        "chr1\t18643416\t18643996\r\n"+
        "chr2\t71227049\t71227608\r\n"+
        "chr1\t170619282\t170619912\r\n"+
        "chr22\t45553841\t45554326\r\n"+
        "chr3\t47781257\t47781685\r\n"+
        "chr2\t28390090\t28390728\r\n"+
        "chr2\t160205519\t160205915\r\n"+
        "chr5\t174503646\t174504216\r\n"+
        "chr11\t65279777\t65280101\r\n"+
        "chr6\t6790834\t6791225\r\n"+
        "chr6\t54194089\t54194442\r\n"+
        "chr1\t165871417\t165871777\r\n"+
        "chr1\t40691390\t40692235\r\n"+
        "chr4\t188127257\t188127772\r\n"+
        "chr21\t26587913\t26588349\r\n"+
        "chr10\t119030384\t119030877\r\n"+
        "chr2\t29747916\t29748466\r\n"+
        "chr8\t143635782\t143636588\r\n"+
        "chr11\t122196991\t122197500\r\n"+
        "chr15\t62896979\t62897466\r\n"+
        "chr6\t18241445\t18241851\r\n"+
        "chr8\t79103762\t79104098\r\n"+
        "chr18\t32018242\t32018998\r\n"+
        "chrX\t134885342\t134885926\r\n"+
        "chr16\t57590909\t57591618\r\n"+
        "chr12\t53345154\t53345680\r\n"+
        "chr7\t155951428\t155952142\r\n"+
        "chr17\t65783754\t65784286\r\n"+
        "chr1\t55828063\t55828631\r\n"+
        "chr1\t56376712\t56377062\r\n"+
        "chr13\t27251158\t27251730\r\n"+
        "chr20\t4512912\t4513332\r\n"+
        "chr1\t155069736\t155070270\r\n"+
        "chr9\t89180314\t89180796\r\n"+
        "chr15\t90994507\t90994995\r\n"+
        "chr12\t100266843\t100267432\r\n"+
        "chr2\t111975084\t111975539\r\n"+
        "chr20\t62735307\t62735674\r\n"+
        "chr9\t96339632\t96340067\r\n"+
        "chr13\t100393946\t100394424\r\n"+
        "chr20\t9241268\t9241723\r\n"+
        "chr7\t123209758\t123210147\r\n"+
        "chr19\t49487256\t49487736\r\n"+
        "chr18\t58785218\t58785765\r\n"+
        "chr18\t58605408\t58605834\r\n"+
        "chr4\t94452709\t94453056\r\n"+
        "chr5\t129377551\t129377932\r\n"+
        "chr15\t92683400\t92683772\r\n"+
        "chr13\t100454947\t100455257\r\n"+
        "chr1\t153566422\t153566857\r\n"+
        "chr11\t102452485\t102453217\r\n"+
        "chr20\t38181317\t38181691\r\n"+
        "chr14\t53975445\t53975806\r\n"+
        "chr2\t146874012\t146874753\r\n"+
        "chr18\t48003685\t48004362\r\n"+
        "chr12\t31589717\t31590210\r\n"+
        "chr15\t44195190\t44195760\r\n"+
        "chr3\t23743395\t23743794\r\n"+
        "chr1\t230186172\t230186509\r\n"+
        "chr17\t76688537\t76689057\r\n"+
        "chr22\t39574713\t39575233\r\n"+
        "chr12\t75701874\t75702227\r\n"+
        "chr14\t68685475\t68686052\r\n"+
        "chr3\t192830974\t192831383\r\n"+
        "chr17\t7281535\t7282064\r\n"+
        "chr3\t14598275\t14598658\r\n"+
        "chr14\t68181356\t68181953\r\n"+
        "chr20\t2652299\t2653012\r\n"+
        "chr5\t171450698\t171451244\r\n"+
        "chr10\t123154004\t123154481\r\n"+
        "chr1\t193059197\t193059697\r\n"+
        "chr9\t99433615\t99433973\r\n"+
        "chr10\t122307801\t122308378\r\n"+
        "chr1\t226308872\t226309459\r\n"+
        "chr8\t101080595\t101081281\r\n"+
        "chr3\t121165325\t121165841\r\n"+
        "chr6\t6820577\t6821174\r\n"+
        "chr6\t161353209\t161353574\r\n"+
        "chr2\t46909740\t46910164\r\n"+
        "chr7\t135232780\t135233128\r\n"+
        "chr3\t155110972\t155111449\r\n"+
        "chr16\t28863271\t28863678\r\n"+
        "chr19\t49568047\t49568558\r\n"+
        "chr22\t45163529\t45163965\r\n"+
        "chr10\t27893307\t27893756\r\n"+
        "chr19\t38417797\t38418531\r\n"+
        "chr6\t20291715\t20292025\r\n"+
        "chr1\t156054485\t156054997\r\n"+
        "chr4\t186932192\t186933193\r\n"+
        "chr2\t226118450\t226118923\r\n"+
        "chr6\t111105564\t111105956\r\n"+
        "chr1\t84319696\t84320093\r\n"+
        "chr2\t38750988\t38751770\r\n"+
        "chr15\t64093676\t64094125\r\n"+
        "chr1\t234975041\t234975561\r\n"+
        "chr5\t176536508\t176536839\r\n"+
        "chr1\t42658215\t42658905\r\n"+
        "chr9\t126517164\t126517496\r\n"+
        "chr6\t45433627\t45434086\r\n"+
        "chr13\t110712754\t110713229\r\n"+
        "chr1\t19011078\t19011479\r\n"+
        "chr2\t188292503\t188293147\r\n"+
        "chr2\t120791824\t120792552\r\n"+
        "chr13\t95301006\t95301855\r\n"+
        "chr13\t43057645\t43058028\r\n"+
        "chr16\t85350964\t85351296\r\n"+
        "chr18\t3596668\t3597045\r\n"+
        "chr17\t76726323\t76726874\r\n"+
        "chr11\t10633365\t10633712\r\n"+
        "chr1\t7265768\t7266357\r\n"+
        "chr6\t96521551\t96521950\r\n"+
        "chr1\t53685236\t53685691\r\n"+
        "chr8\t141026715\t141027195\r\n"+
        "chr6\t42136568\t42137269\r\n"+
        "chr18\t40120996\t40121427\r\n"+
        "chr5\t81851539\t81852167\r\n"+
        "chr16\t30534636\t30535277\r\n"+
        "chr3\t139310390\t139311021\r\n"+
        "chrX\t9708975\t9709296\r\n"+
        "chr3\t184561345\t184561773\r\n"+
        "chr2\t223815145\t223815574\r\n"+
        "chr1\t10679612\t10679917\r\n"+
        "chr6\t147709481\t147710102\r\n"+
        "chr5\t142223611\t142224124\r\n"+
        "chr20\t43955307\t43956147\r\n"+
        "chr10\t100653916\t100654404\r\n"+
        "chr11\t108616621\t108616964\r\n"+
        "chr16\t21188715\t21189023\r\n"+
        "chr10\t61837239\t61837576\r\n"+
        "chr7\t17461957\t17462688\r\n"+
        "chr5\t93192101\t93192442\r\n"+
        "chr14\t77302977\t77303306\r\n"+
        "chr1\t12478055\t12478797\r\n"+
        "chr6\t36243597\t36243880\r\n"+
        "chr5\t130190018\t130190369\r\n"+
        "chr21\t29114874\t29115285\r\n"+
        "chr1\t45892443\t45892815\r\n"+
        "chr12\t89225363\t89225708\r\n"+
        "chr10\t21292733\t21293282\r\n"+
        "chr10\t84328489\t84329073\r\n"+
        "chr17\t16296137\t16296432\r\n"+
        "chr11\t64917160\t64917655\r\n"+
        "chr1\t46394113\t46394708\r\n"+
        "chr2\t9630770\t9631416\r\n"+
        "chrX\t2188349\t2188828\r\n"+
        "chr4\t101790502\t101791433\r\n"+
        "chr8\t25690252\t25690679\r\n"+
        "chr14\t97266646\t97267026\r\n"+
        "chr17\t65243790\t65244284\r\n"+
        "chr1\t237873458\t237874030\r\n"+
        "chr5\t174520424\t174520878\r\n"+
        "chr15\t41490340\t41490690\r\n"+
        "chr4\t30769972\t30770604\r\n"+
        "chr19\t10417918\t10418498\r\n"+
        "chr1\t180521530\t180521879\r\n"+
        "chr3\t114775467\t114775793\r\n"+
        "chr16\t1942898\t1943395\r\n"+
        "chr2\t232901670\t232902454\r\n"+
        "chr3\t157174853\t157175299\r\n"+
        "chr22\t18077775\t18078280\r\n"+
        "chr2\t223816169\t223816606\r\n"+
        "chr11\t38547877\t38548279\r\n"+
        "chr4\t83548409\t83548831\r\n"+
        "chr3\t41265888\t41266322\r\n"+
        "chr19\t12440850\t12441428\r\n"+
        "chr11\t130181519\t130181952\r\n"+
        "chr2\t215410779\t215411245\r\n"+
        "chr2\t45964211\t45964614\r\n"+
        "chr15\t88904671\t88905026\r\n"+
        "chr11\t69702326\t69702662\r\n"+
        "chr20\t50561142\t50561904\r\n"+
        "chr2\t177263369\t177263737\r\n"+
        "chr12\t65533264\t65533998\r\n"+
        "chr3\t172129981\t172130267\r\n"+
        "chr2\t157898509\t157898944\r\n"+
        "chr3\t12471114\t12471705\r\n"+
        "chr9\t96566326\t96567071\r\n"+
        "chr22\t39205315\t39205704\r\n"+
        "chr12\t65603472\t65603888\r\n"+
        "chr7\t93043317\t93043768\r\n"+
        "chr11\t34916069\t34916763\r\n"+
        "chr6\t92978369\t92978677\r\n"+
        "chr13\t20174782\t20175248\r\n"+
        "chr1\t164465917\t164466430\r\n"+
        "chr20\t47725297\t47725671\r\n"+
        "chr8\t22352522\t22353055\r\n"+
        "chr7\t148339272\t148339625\r\n"+
        "chr6\t142235280\t142235656\r\n"+
        "chr2\t85468726\t85469268\r\n"+
        "chr14\t54169412\t54169946\r\n"+
        "chr7\t9097634\t9098065\r\n"+
        "chr6\t79574663\t79575004\r\n"+
        "chr2\t172098842\t172099342\r\n"+
        "chr14\t24036137\t24036530\r\n"+
        "chr15\t70526525\t70526924\r\n"+
        "chr8\t140510838\t140511373\r\n"+
        "chr2\t200408942\t200409315\r\n"+
        "chr10\t73887585\t73888107\r\n"+
        "chr11\t109864179\t109864722\r\n"+
        "chr9\t112119421\t112119861\r\n"+
        "chr1\t235642087\t235642666\r\n"+
        "chr10\t122140809\t122141557\r\n"+
        "chr9\t136051838\t136052305\r\n"+
        "chr6\t121479467\t121480009\r\n"+
        "chr4\t186845217\t186846028\r\n"+
        "chr22\t30634449\t30634829\r\n"+
        "chr1\t82565165\t82565960\r\n"+
        "chr16\t85330803\t85331102\r\n"+
        "chr17\t64505421\t64505747\r\n"+
        "chr2\t227191422\t227191744\r\n"+
        "chr16\t9047698\t9048336\r\n"+
        "chr12\t71440606\t71441260\r\n"+
        "chr1\t43929586\t43929935\r\n"+
        "chr17\t15649778\t15650280\r\n"+
        "chr12\t75712109\t75712616\r\n"+
        "chr5\t151447379\t151447847\r\n"+
        "chr11\t76784419\t76784869\r\n"+
        "chr17\t58535485\t58535838\r\n"+
        "chr2\t181761991\t181762339\r\n"+
        "chr10\t28678006\t28678384\r\n"+
        "chr19\t43504111\t43504434\r\n"+
        "chr2\t120935678\t120936095\r\n"+
        "chr4\t1022629\t1022987\r\n"+
        "chr3\t111735250\t111735697\r\n"+
        "chr1\t84603795\t84604248\r\n"+
        "chr3\t30227693\t30228179\r\n"+
        "chr16\t55035089\t55035416\r\n"+
        "chr8\t130528367\t130528692\r\n"+
        "chr15\t67174940\t67175361\r\n"+
        "chr13\t31044438\t31044749\r\n"+
        "chr1\t10937394\t10937722\r\n"+
        "chr2\t78967276\t78967629\r\n"+
        "chr11\t61730235\t61730675\r\n"+
        "chr7\t116218145\t116218602\r\n"+
        "chr1\t25861303\t25861861\r\n"+
        "chr7\t128869142\t128869818\r\n"+
        "chr5\t145587696\t145588052\r\n"+
        "chr1\t116909800\t116910840\r\n"+
        "chr5\t82352449\t82352991\r\n"+
        "chr2\t223602229\t223602518\r\n"+
        "chr11\t46845963\t46846512\r\n"+
        "chr12\t46523911\t46524464\r\n"+
        "chr14\t90521060\t90521684\r\n"+
        "chr5\t127999956\t128000270\r\n"+
        "chr1\t8189962\t8190329\r\n"+
        "chr15\t75104782\t75105176\r\n"+
        "chr5\t174751108\t174751710\r\n"+
        "chr16\t11328522\t11328902\r\n"+
        "chr2\t181790706\t181791120\r\n"+
        "chr1\t79193294\t79193780\r\n"+
        "chr15\t99790833\t99791145\r\n"+
        "chr4\t169010195\t169010572\r\n"+
        "chr2\t191866743\t191867342\r\n"+
        "chr9\t22203662\t22204118\r\n"+
        "chr16\t3500715\t3501171\r\n"+
        "chr1\t19925315\t19925704\r\n"+
        "chr11\t28702047\t28702538\r\n"+
        "chr4\t17336633\t17337044\r\n"+
        "chr3\t114880100\t114880507\r\n"+
        "chr5\t112160631\t112161035\r\n"+
        "chr2\t159615415\t159616249\r\n"+
        "chr8\t129707659\t129708378\r\n"+
        "chr11\t86193524\t86193811\r\n"+
        "chr15\t37877817\t37878271\r\n"+
        "chr10\t102917978\t102918721\r\n"+
        "chr10\t52319073\t52319477\r\n"+
        "chr5\t74685023\t74685484\r\n"+
        "chr2\t25187749\t25188205\r\n"+
        "chr13\t87123977\t87124412\r\n"+
        "chr19\t7522372\t7522846\r\n"+
        "chr5\t142169369\t142169942\r\n"+
        "chr11\t15106590\t15107009\r\n"+
        "chr17\t81386552\t81387739\r\n"+
        "chr10\t113326187\t113326581\r\n"+
        "chr2\t66334694\t66335022\r\n"+
        "chr14\t68464611\t68465068\r\n"+
        "chr5\t174951096\t174951473\r\n"+
        "chr16\t77877744\t77878061\r\n"+
        "chr8\t30052458\t30052840\r\n"+
        "chr19\t50975822\t50976140\r\n"+
        "chr4\t186728693\t186729031\r\n"+
        "chr7\t32942856\t32943509\r\n"+
        "chr18\t11500470\t11500806\r\n"+
        "chr10\t63738463\t63738813\r\n"+
        "chr17\t82751841\t82752372\r\n"+
        "chr2\t32357051\t32357724\r\n"+
        "chr2\t161128825\t161129403\r\n"+
        "chr16\t84138754\t84139547\r\n"+
        "chr11\t69297135\t69297723\r\n"+
        "chr20\t381842\t382342\r\n"+
        "chr1\t202222233\t202222649\r\n"+
        "chr3\t42853777\t42854079\r\n"+
        "chr1\t71490507\t71490830\r\n"+
        "chr15\t41774340\t41774885\r\n"+
        "chr17\t81397330\t81397732\r\n"+
        "chr16\t73048192\t73048747\r\n"+
        "chr3\t168024505\t168024913\r\n"+
        "chr15\t64536189\t64536700\r\n"+
        "chr12\t123141659\t123141958\r\n"+
        "chr8\t135456648\t135457298\r\n"+
        "chr17\t69327001\t69327546\r\n"+
        "chr17\t71438655\t71439115\r\n"+
        "chr5\t16187684\t16187988\r\n"+
        "chr15\t89334732\t89335422\r\n"+
        "chr4\t156931327\t156931677\r\n"+
        "chr7\t5529608\t5530182\r\n"+
        "chr20\t41008311\t41008721\r\n"+
        "chrX\t87409428\t87409864\r\n"+
        "chr7\t73564407\t73564713\r\n"+
        "chr7\t66110785\t66111142\r\n"+
        "chr18\t9779646\t9780030\r\n"+
        "chr3\t124878567\t124879294\r\n"+
        "chr5\t68432676\t68433028\r\n"+
        "chr14\t45743900\t45744225\r\n"+
        "chr1\t185733747\t185734606\r\n"+
        "chr12\t113007176\t113007619\r\n"+
        "chr17\t50035461\t50035838\r\n"+
        "chr17\t79074706\t79075074\r\n"+
        "chr17\t27957135\t27957477\r\n"+
        "chr14\t53463172\t53463766\r\n"+
        "chr8\t100510119\t100510446\r\n"+
        "chr16\t12803372\t12804081\r\n"+
        "chr1\t156693037\t156693500\r\n"+
        "chr4\t167428187\t167428561\r\n"+
        "chr6\t45655899\t45656350\r\n"+
        "chr11\t95789538\t95790197\r\n"+
        "chr3\t111926262\t111926634\r\n"+
        "chr9\t129080737\t129081210\r\n"+
        "chr16\t73015689\t73016009\r\n"+
        "chr9\t128558440\t128558848\r\n"+
        "chr1\t119294782\t119295094\r\n"+
        "chr19\t35845310\t35845801\r\n"+
        "chr8\t60792927\t60793232\r\n"+
        "chr8\t100832766\t100833143\r\n"+
        "chr5\t56816595\t56817094\r\n"+
        "chr3\t74789119\t74789571\r\n"+
        "chr14\t54102041\t54102559\r\n"+
        "chr1\t151494769\t151495149\r\n"+
        "chr2\t147352745\t147353351\r\n"+
        "chr1\t113308313\t113308728\r\n"+
        "chr20\t18793922\t18794284\r\n"+
        "chr12\t65306716\t65307274\r\n"+
        "chr3\t149480369\t149480712\r\n"+
        "chr12\t31491786\t31492497\r\n"+
        "chr13\t48037391\t48038146\r\n"+
        "chr10\t78047334\t78047645\r\n"+
        "chr8\t127331892\t127332347\r\n"+
        "chr20\t4014032\t4014418\r\n"+
        "chr7\t17099459\t17099936\r\n"+
        "chr2\t175167810\t175168620\r\n"+
        "chr18\t58545336\t58545657\r\n"+
        "chr4\t153246731\t153247189\r\n"+
        "chr2\t235048991\t235049424\r\n"+
        "chr2\t91477738\t91478350\r\n"+
        "chr17\t50161463\t50161850\r\n"+
        "chr10\t95467230\t95467546\r\n"+
        "chr4\t188214909\t188215245\r\n"+
        "chr17\t3988764\t3989106\r\n"+
        "chr5\t132387572\t132387882\r\n"+
        "chr14\t55454522\t55454984\r\n"+
        "chr17\t72338967\t72339706\r\n"+
        "chr7\t92245463\t92246101\r\n"+
        "chr16\t85553205\t85553781\r\n"+
        "chr1\t151165808\t151166222\r\n"+
        "chr5\t38809749\t38810093\r\n"+
        "chr22\t38057036\t38057490\r\n"+
        "chr3\t32177081\t32177582\r\n"+
        "chr1\t9163656\t9164336\r\n"+
        "chr8\t133217830\t133218410\r\n"+
        "chr7\t102991402\t102992039\r\n"+
        "chr20\t22691551\t22691957\r\n"+
        "chr19\t7373909\t7374256\r\n"+
        "chr2\t237184623\t237184968\r\n"+
        "chr3\t18098709\t18099329\r\n"+
        "chr11\t111878537\t111879575\r\n"+
        "chr6\t1054897\t1055429\r\n"+
        "chr19\t16160831\t16161523\r\n"+
        "chr16\t67562096\t67562536\r\n"+
        "chr11\t74398515\t74399032\r\n"+
        "chr1\t234612474\t234613006\r\n"+
        "chr4\t4761141\t4761791\r\n"+
        "chr11\t40602815\t40603434\r\n"+
        "chr2\t226585173\t226585605\r\n"+
        "chr3\t161349861\t161350284\r\n"+
        "chr9\t128078523\t128079315\r\n"+
        "chr1\t68128241\t68128596\r\n"+
        "chr10\t3852368\t3852829\r\n"+
        "chr6\t32255161\t32255836\r\n"+
        "chr11\t8384313\t8384865\r\n"+
        "chr12\t45192332\t45192719\r\n"+
        "chr11\t111960880\t111961246\r\n"+
        "chr2\t12816152\t12816740\r\n"+
        "chr1\t225710854\t225711251\r\n"+
        "chr10\t11685790\t11686121\r\n"+
        "chr18\t48944226\t48944612\r\n"+
        "chr8\t58553002\t58553512\r\n"+
        "chr17\t59220285\t59220780\r\n"+
        "chr10\t7687247\t7687587\r\n"+
        "chr12\t46433863\t46434258\r\n"+
        "chr19\t35757895\t35758695\r\n"+
        "chr3\t126287403\t126287802\r\n"+
        "chr17\t932884\t933216\r\n"+
        "chr19\t12722369\t12722919\r\n"+
        "chr10\t56537870\t56538309\r\n"+
        "chr5\t132830065\t132830875\r\n"+
        "chr17\t49191855\t49192723\r\n"+
        "chr4\t56026619\t56026924\r\n"+
        "chr17\t82037291\t82038221\r\n"+
        "chr17\t59786391\t59786913\r\n"+
        "chr8\t112115135\t112115488\r\n"+
        "chr20\t34525841\t34526312\r\n"+
        "chr10\t104338071\t104338867\r\n"+
        "chr2\t158795133\t158795472\r\n"+
        "chr22\t38924382\t38924870\r\n"+
        "chr5\t145946557\t145946893\r\n"+
        "chr12\t31103657\t31104031\r\n"+
        "chr7\t80883293\t80883956\r\n"+
        "chr5\t76805999\t76806652\r\n"+
        "chr10\t88897350\t88897795\r\n"+
        "chr5\t142362775\t142363117\r\n"+
        "chr3\t194269534\t194269995\r\n"+
        "chr13\t21637197\t21637813\r\n"+
        "chr6\t42050487\t42051055\r\n"+
        "chr19\t55216358\t55216813\r\n"+
        "chr7\t34747982\t34748826\r\n"+
        "chr14\t53979384\t53979818\r\n"+
        "chr3\t194296420\t194296793\r\n"+
        "chr12\t75974894\t75975277\r\n"+
        "chr8\t116833328\t116833628\r\n"+
        "chr8\t103281148\t103281486\r\n"+
        "chr16\t87076876\t87077582\r\n"+
        "chr10\t75405135\t75405473\r\n"+
        "chr9\t114153822\t114154381\r\n"+
        "chr21\t35294300\t35294829\r\n"+
        "chr3\t59575080\t59575605\r\n"+
        "chr2\t209495881\t209496363\r\n"+
        "chr14\t105020894\t105021304\r\n"+
        "chr4\t175935049\t175935393\r\n"+
        "chr12\t63917993\t63918508\r\n"+
        "chr8\t142184101\t142184502\r\n"+
        "chrX\t141405818\t141406534\r\n"+
        "chr14\t64841175\t64841563\r\n"+
        "chr6\t4018240\t4018938\r\n"+
        "chr22\t47328849\t47329287\r\n"+
        "chr1\t225817660\t225818065\r\n"+
        "chr3\t52128085\t52128534\r\n"+
        "chr22\t23521482\t23522114\r\n"+
        "chr15\t60391103\t60391467\r\n"+
        "chr7\t112789922\t112790539\r\n"+
        "chr6\t79545018\t79545377\r\n"+
        "chr12\t69585193\t69585686\r\n"+
        "chr20\t2315122\t2315482\r\n"+
        "chr14\t97077375\t97077735\r\n"+
        "chr5\t91190068\t91190615\r\n"+
        "chr6\t56714964\t56715566\r\n"+
        "chr4\t40284011\t40284368\r\n"+
        "chr5\t82313077\t82313734\r\n"+
        "chr20\t46293121\t46293451\r\n"+
        "chr11\t25702414\t25702813\r\n"+
        "chr14\t21103573\t21104471\r\n"+
        "chrX\t107118614\t107119010\r\n"+
        "chr5\t1003243\t1003652\r\n"+
        "chr1\t234978687\t234979089\r\n"+
        "chr1\t51316126\t51316543\r\n"+
        "chr9\t129460364\t129461009\r\n"+
        "chr7\t55129684\t55130049\r\n"+
        "chr15\t67106513\t67107330\r\n"+
        "chr8\t127222641\t127223289\r\n"+
        "chr15\t75843294\t75843623\r\n"+
        "chr12\t30795083\t30796180\r\n"+
        "chr12\t108854475\t108854914\r\n"+
        "chr14\t77376949\t77377725\r\n"+
        "chr7\t45978100\t45978520\r\n"+
        "chr5\t143245918\t143246407\r\n"+
        "chr9\t137301112\t137301508\r\n"+
        "chr9\t97501105\t97501591\r\n"+
        "chr5\t137753895\t137754898\r\n"+
        "chr4\t91064482\t91064879\r\n"+
        "chr12\t49059692\t49060270\r\n"+
        "chr19\t16111342\t16111944\r\n"+
        "chr8\t127126620\t127127019\r\n"+
        "chr12\t71710294\t71710713\r\n"+
        "chr3\t113098123\t113098539\r\n"+
        "chr19\t18636085\t18636484\r\n"+
        "chr10\t50739572\t50740276\r\n"+
        "chr11\t45259659\t45260009\r\n"+
        "chr12\t62602375\t62602906\r\n"+
        "chr10\t12707627\t12707987\r\n"+
        "chr22\t28977477\t28977928\r\n"+
        "chr6\t7548312\t7548854\r\n"+
        "chr2\t146830864\t146831334\r\n"+
        "chr6\t10434235\t10434758\r\n"+
        "chr13\t33260343\t33260724\r\n"+
        "chr9\t123375794\t123376188\r\n"+
        "chr1\t53413250\t53413946\r\n"+
        "chr1\t39901344\t39902078\r\n"+
        "chr6\t162964626\t162965165\r\n"+
        "chr9\t98215827\t98216206\r\n"+
        "chr16\t51538768\t51539301\r\n"+
        "chr6\t37819014\t37819818\r\n"+
        "chr7\t74453644\t74454013\r\n"+
        "chr1\t27392202\t27392764\r\n"+
        "chr11\t31655393\t31655830\r\n"+
        "chr19\t32971893\t32972425\r\n"+
        "chr1\t152167900\t152168260\r\n"+
        "chr3\t65963862\t65964668\r\n"+
        "chr3\t171260944\t171261276\r\n"+
        "chrX\t84046472\t84046822\r\n"+
        "chr2\t61538198\t61539006\r\n"+
        "chr17\t58136722\t58137004\r\n"+
        "chr6\t163311830\t163312161\r\n"+
        "chr12\t50764490\t50765198\r\n"+
        "chr1\t218674402\t218674838\r\n"+
        "chr3\t7112586\t7112994\r\n"+
        "chr5\t134758499\t134758987\r\n"+
        "chr16\t85759822\t85760133\r\n"+
        "chr12\t65450541\t65451007\r\n"+
        "chr5\t54310493\t54311043\r\n"+
        "chr7\t5397085\t5397627\r\n"+
        "chr11\t122271064\t122271557\r\n"+
        "chr10\t57983175\t57983629\r\n"+
        "chr16\t14399393\t14399984\r\n"+
        "chr13\t28718720\t28719287\r\n"+
        "chr14\t100408501\t100408811\r\n"+
        "chr6\t29752730\t29753354\r\n"+
        "chr17\t82160122\t82160451\r\n"+
        "chr3\t30631248\t30631625\r\n"+
        "chr11\t46616980\t46617414\r\n"+
        "chr12\t120925716\t120926136\r\n"+
        "chr3\t111585246\t111585568\r\n"+
        "chr5\t1973526\t1974094\r\n"+
        "chr1\t41840691\t41841272\r\n"+
        "chr7\t80611783\t80612277\r\n"+
        "chr2\t201532695\t201533054\r\n"+
        "chr5\t173455092\t173455665\r\n"+
        "chr17\t49851512\t49852056\r\n"+
        "chr1\t202213284\t202213642\r\n"+
        "chr6\t129493325\t129493670\r\n"+
        "chr10\t52313259\t52313868\r\n"+
        "chr19\t11374567\t11375117\r\n"+
        "chr10\t102453055\t102453346\r\n"+
        "chr9\t2241908\t2242662\r\n"+
        "chr4\t151744648\t151745027\r\n"+
        "chr13\t27383274\t27383957\r\n"+
        "chr11\t61333058\t61333923\r\n"+
        "chr11\t64545595\t64545945\r\n"+
        "chr10\t32055472\t32056537\r\n"+
        "chr7\t27171321\t27171619\r\n"+
        "chr15\t85786107\t85786712\r\n"+
        "chr11\t13261558\t13261960\r\n"+
        "chrX\t38803579\t38804386\r\n"+
        "chr19\t46638586\t46639194\r\n"+
        "chr17\t78840702\t78841296\r\n"+
        "chrX\t106933523\t106933918\r\n"+
        "chr5\t21774822\t21775206\r\n"+
        "chr6\t121615559\t121615898\r\n"+
        "chr16\t1002643\t1003130\r\n"+
        "chr17\t49414805\t49415277\r\n"+
        "chr2\t85753692\t85754118\r\n"+
        "chrX\t72572566\t72573211\r\n"+
        "chr1\t8211880\t8212377\r\n"+
        "chr16\t89624759\t89625177\r\n"+
        "chr17\t66951902\t66952417\r\n"+
        "chr9\t24545292\t24545689\r\n"+
        "chr9\t122828271\t122828821\r\n"+
        "chr7\t151608111\t151608567\r\n"+
        "chr8\t48921216\t48921598\r\n"+
        "chr12\t110813307\t110813669\r\n"+
        "chr1\t234957400\t234957997\r\n"+
        "chr1\t171644852\t171645267\r\n"+
        "chr16\t48385471\t48385955\r\n"+
        "chr20\t62523902\t62524231\r\n"+
        "chr9\t83296196\t83296509\r\n"+
        "chr15\t66883341\t66883750\r\n"+
        "chr8\t110848165\t110848538\r\n"+
        "chr15\t31398614\t31399072\r\n"+
        "chr4\t83618502\t83618805\r\n"+
        "chr10\t75959272\t75959627\r\n"+
        "chr12\t101566333\t101566631\r\n"+
        "chr9\t21591566\t21591980\r\n"+
        "chr2\t226631709\t226632112\r\n"+
        "chr5\t68334017\t68334700\r\n"+
        "chr1\t68384331\t68384821\r\n"+
        "chr17\t53626347\t53626639\r\n"+
        "chr12\t82650649\t82651009\r\n"+
        "chr22\t47125589\t47125932\r\n"+
        "chr12\t65510446\t65511386\r\n"+
        "chr3\t45818148\t45818636\r\n"+
        "chr1\t186082293\t186082646\r\n"+
        "chr4\t114015394\t114015895\r\n"+
        "chr3\t191246678\t191247075\r\n"+
        "chr20\t33192923\t33193357\r\n"+
        "chr20\t63682365\t63682838\r\n"+
        "chr1\t199791564\t199792065\r\n"+
        "chr4\t37685628\t37686114\r\n"+
        "chr1\t162690966\t162691255\r\n"+
        "chr1\t13749127\t13749492\r\n"+
        "chr7\t130887229\t130887663\r\n"+
        "chr6\t55713409\t55713776\r\n"+
        "chr1\t63714274\t63714617\r\n"+
        "chr5\t135438085\t135438459\r\n"+
        "chr4\t87391126\t87391747\r\n"+
        "chr4\t113951278\t113951604\r\n"+
        "chr10\t92914533\t92914813\r\n"+
        "chr12\t65500158\t65500842\r\n"+
        "chr19\t2540793\t2541163\r\n"+
        "chr3\t189324606\t189325122\r\n"+
        "chr5\t168114497\t168114834\r\n"+
        "chr7\t37031973\t37032471\r\n"+
        "chr2\t239247480\t239248101\r\n"+
        "chr12\t98503782\t98504378\r\n"+
        "chr1\t18926418\t18926909\r\n"+
        "chr3\t23685509\t23686187\r\n"+
        "chr8\t140668311\t140668666\r\n"+
        "chr14\t104116338\t104117372\r\n"+
        "chr15\t89087880\t89088441\r\n"+
        "chr11\t122180384\t122180816\r\n"+
        "chr20\t5119760\t5120185\r\n"+
        "chr10\t90087256\t90087677\r\n"+
        "chr22\t42079467\t42080061\r\n"+
        "chr1\t30823800\t30824565\r\n"+
        "chr1\t84390218\t84390586\r\n"+
        "chr16\t85516075\t85516370\r\n"+
        "chr1\t43143364\t43143920\r\n"+
        "chr3\t139326782\t139327104\r\n"+
        "chr15\t70892310\t70893088\r\n"+
        "chr18\t50287557\t50288227\r\n"+
        "chr1\t63523103\t63523590\r\n"+
        "chr17\t64385170\t64385521\r\n"+
        "chr11\t3797368\t3798066\r\n"+
        "chr6\t137805552\t137806002\r\n"+
        "chr19\t7853067\t7853669\r\n"+
        "chr1\t211579070\t211579792\r\n"+
        "chr6\t41581381\t41582042\r\n"+
        "chr22\t24601590\t24601892\r\n"+
        "chr9\t110977275\t110977750");
}


