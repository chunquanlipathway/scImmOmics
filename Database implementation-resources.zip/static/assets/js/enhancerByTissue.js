var olanguage = {
    // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Show _START_ to _END_ of _TOTAL_",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function sampleByTissueType(biosampleType, tissueType, checkh3k4me3) {
    $('#sampleBytissuetab').DataTable({
        ajax: {
            url: "tabByTissueType",
            type: "GET",
            async: true,
            data: {"biosampleType": biosampleType, "tissueType": tissueType,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[5, 25, 50, 100], [5, 25, 50, 100]],
        destroy: true,
        columns: [
            {
                "data": "sampleID",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleID + "'>Sample_" + row.sampleID + "</a>";
                }
            },
            // {"data": "dataSource"},
            // {"data": "biosampleType"},
            // {"data": "tissueType"},
            {"data": "biosampleName"},
            {"data": "idenSignal"},
            {
                "data": "sampleID",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='download?sample=" + row.sampleID + "'>bed<i class='fa fa-download' aria-hidden='true'></i></a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function piegraph(biosampleType,tissueType,checkh3k4me3) {
    var chartDom = document.getElementById('main');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "chrPieBySample",
        type: "get",
        data: {"biosampleType": biosampleType,"tissueType":tissueType,"checkh3k4me3":checkh3k4me3},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                title: {
                    text: '',
                    subtext: '',
                    left: 'center'
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left'
                },
                series: [
                    {
                        name: 'chrome number',
                        type: 'pie',
                        radius: '50%',
                        left: '20%',
                        data: res.data,
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function enhancerTabShow(biosampleType,tissueType,singalclass,checkh3k4me3) {
    if (singalclass.H3K27ac=="show"){
        $("#H3K27acid").addClass("active")
        $("#h3k27ac").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"H3K27ac")
    }else if (singalclass.H3K4me1=="show"){
        $("#H3K4me1id").addClass("active")
        $("#h3k4me1").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"H3K4me1")
    }else if (singalclass.ATAC=="show"){
        $("#ATACid").addClass("active")
        $("#atac").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"ATAC")
    }else if (singalclass.DNase=="show"){
        $("#DNaseid").addClass("active")
        $("#dnase").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"DNase")
    }else if (singalclass.MNase=="show"){
        $("#MNaseid").addClass("active")
        $("#mnase").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"MNase")
    }else if (singalclass.FAIRE=="show"){
        $("#FAIREid").addClass("active")
        $("#faire").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"FAIRE")
    }else if (singalclass.Starr=="show"){
        $("#Starrid").addClass("active")
        $("#starr").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"Starr")
    }else if (singalclass.POLR2A=="show"){
        $("#POLR2Aid").addClass("active")
        $("#polr2a").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"POLR2A")
    }else if (singalclass.EP300=="show"){
        $("#EP300id").addClass("active")
        $("#ep300").addClass("active")
        enhancertab(biosampleType,tissueType,checkh3k4me3,"EP300")
    }
}

function enhancertab(biosampleType,tissueType,checkh3k4me3,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "enBySampleids",
            type: "GET",
            async: true,
            data: {"biosampleType": biosampleType,"tissueType":tissueType,"singal":singal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[20, 30, 50, 100], [20, 30, 50, 100]],
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "logpvalue"},
            {"data": "interaction"},
            {"data": "methy450K"},
            {"data": "commonsnp"},
            {"data": "crisps"},
            {"data": "enhancer"},
            {"data": "eqtl"},
            {"data": "gwas"},
            {"data": "tad"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg38&lastVirtModeType=default&lastVirtModeExtraState=&virtModeType=default&virtMode=0&nonVirtPosition=&position="+row.chrome+"%3A"+row.start+"%2D"+row.end+"&hgsid=1334138285_q3d2baKSxBnqflr14dK9CRYkDtfA'>" + "UCSC</a>|<a>ENID"+"</a>";
                }
            }
        ],
        columnDefs:[{"orderable":false,"targets":4}],
        oLanguage: olanguage
    });
}
