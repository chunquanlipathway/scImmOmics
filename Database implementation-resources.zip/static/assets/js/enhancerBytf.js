var olanguage = {
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function tf_count_graph(tfname) {
    var chartDom = document.getElementById('count');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "tf_count_graph",
        type: "get",
        data: {"tfname": tfname,"checkh3k4me3":checkh3k4me3},
        async: true,
        success: function (res) {
            console.log(res);
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    top: '3%',
                    left: '3%',
                    right: '5%',
                    bottom: '2%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLabel:{
                        interval: 0, rotate: 30
                    },
                    data: ['H3K27ac', 'H3K4me1', 'ATAC-seq', 'DNase-seq', 'MNase-seq', 'FAIRE-seq', 'Starr-seq', 'POLR2A', 'EP300']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        data: [res.H3K27ac, res.H3K4me1, res.ATAC, res.DNase, res.MNase, res.FAIRE, res.Starr, res.POLR2A, res.EP300],
                        type: 'line'
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function enhancerBytf(tfname,checkh3k4me3,signal) {
    var tab = "#"+signal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabBytf",
            type: "GET",
            async: true,
            data: {"tfname":tfname,"signal":signal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "tf"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {"data": "pvalue"},
            {"data": "motif"},
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome_e",
                "render": function (data, type, row, meta) {
                    return row.chrome_e + ":" + row.start_e + "-" + row.end_e;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end_e - row.start_e;
                }
            },
            {"data": "tissueType"},
            {
                "data": "biosampleName",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid+ "'>" + row.biosampleName + "</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}


function enhancerBytf_consensus(tfname,checkh3k4me3,signal) {
    var tab = "#"+signal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabBytf",
            type: "GET",
            async: true,
            data: {"tfname":tfname,"signal":signal,"checkh3k4me3":checkh3k4me3}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "tf"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {"data": "pvalue"},
            {"data": "motif"},
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome_e",
                "render": function (data, type, row, meta) {
                    return row.chrome_e + ":" + row.start_e + "-" + row.end_e;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end_e - row.start_e;
                }
            },
            {
                "data": "sampleid",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid+ "'>Sample_" + row.sampleid + "</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

