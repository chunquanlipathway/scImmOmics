var olanguage = {
    // "sProcessing": '<img src="assets/img/loading.gif" style="width: 350px;">',
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function deeptoolsPlot(random,sampleid) {
    $.ajax({
        url: "deeptoolsPlot",
        type: "get",
        data: {"random": random,"sampleid":sampleid},
        async: true,
        success: function (res) {
            $("#"+sampleid+"loading").remove();
            $("#"+sampleid+"deeptools").after('<img src="' + res.deeptoolsPng + '" class="d-block w-100 rounded mt-4" alt="...">');
        },
        dataType: "json"
    });
}

function infoBySample(sampleid) {
    $.ajax({
        url: "getBrowseTableInfo",
        type: "get",
        data: {"sampleid": sampleid},
        async: true,
        success: function (res) {
            var html = '<div class="table-responsive m-2">\n' +
                '    <table class="table align-items-center mb-0">\n' +
                '      <thead>\n' +
                '        <tr>\n' +
                '          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Sample ID</th>\n' +
                '          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Sample Type</th>\n' +
                '          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tissue Type</th>\n' +
                '          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Sample Name</th>\n' +
                '          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Signal</th>\n' +
                '          <th></th>\n' +
                '        </tr>\n' +
                '      </thead>\n' +
                '      <tbody>\n' +
                '        <tr>\n' +
                '          <td>\n' +
                '            <p class="text-xs font-weight-normal mb-0"><a href="detailBySample?sample=' + sampleid + '">Sample_' + sampleid + '</a></p>\n' +
                '          </td>\n' +
                '          <td>\n' +
                '            <p class="text-xs font-weight-normal mb-0">' + res.data.biosampleType + '</p>\n' +
                '          </td>\n' +
                '          <td>\n' +
                '            <p class="text-xs font-weight-normal mb-0">' + res.data.tissueType +'</p>\n' +
                '          </td>\n' +
                '          <td>\n' +
                '            <p class="text-xs font-weight-normal mb-0">' + res.data.biosampleName + '</p>\n' +
                '          </td>\n' +
                '          <td>\n' +
                '            <p class="text-xs font-weight-normal mb-0">' + res.data.idenSignal + '</p>\n' +
                '          </td>\n' +
                '        </tr>\n' +
                '      </tbody>\n' +
                '    </table>\n' +
                '</div>'
            $("#"+sampleid+"info").append(html);
        },
        dataType: "json"
    });
}

function enhancer_tab(random,sampleid) {
    var id = sampleid+"tab";

    $('#'+id).DataTable({
        ajax: {
            url: "enhancer_tabdemo",
            type: "GET",
            async: true,
            data: {"sampleid": sampleid}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: true,
        paging: true,
        ordering: true,
        scrollX: true,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        destroy: true,
        columns: [
            {"data": "id"},
            {"data": "overlapGene"},
            {"data": "proximalGene"},
            {"data": "closestGene"}
        ],
        oLanguage: olanguage
    });
}

function enhancer_graph(random,sampleid) {
    var id = sampleid+"force";
    var chartDom = document.getElementById(id);
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "enhancer_graphdemo",
        type: "get",
        data: {"sampleid": sampleid,"random":random},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                legend: [
                    {
                        data: res.categories.map(function (a) {
                            return a.name;
                        })
                    }
                ],
                color:['#5470c6','#e91e63','#fac858','#ffd454','#ffa361','#d1d1d1'],
                series: [
                    {
                        name: 'Les Miserables',
                        type: 'graph',
                        layout: 'none',
                        data: res.nodes,
                        links: res.links,
                        categories: res.categories,
                        roam: true,
                        label: {
                            show: true,
                            position: 'right',
                            formatter: '{b}'
                        },
                        labelLayout: {
                            hideOverlap: true
                        },
                        itemStyle: {
                            normal: {
                                borderColor: '#fff',
                                borderWidth: 1,
                                shadowBlur: 10,
                                shadowColor: 'rgba(0, 0, 0, 0.3)'
                            }
                        },
                        emphasis: {
                            lineStyle: {
                                width: 10
                            }
                        },
                        scaleLimit: {
                            min: 0.4,
                            max: 0.9
                        },
                        lineStyle: {
                            color: '#c2c2c2',
                            curveness: 0
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}


function scatter_graph(random,sampleid) {
    var id = sampleid+"scatter";
    var chartDom = document.getElementById(id);
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "samplescatterPlot",
        type: "get",
        data: {"sampleid": sampleid,"random":random},
        async: true,
        success: function (res) {
            var data = eval(res.data)
            myChart.hideLoading();
            option = {
                title: {
                    text: 'Signal of input genes in the sample',
                    left: 'center',
                    top: '1%',
                    show:false
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '15%',
                    top: '9%',
                    bottom: '10%'
                },
                xAxis: {
                    name: 'Rank',
                    splitLine: {
                        lineStyle: {
                            type: 'dashed'
                        }
                    }
                },
                yAxis: {
                    name: 'Single Sum',
                    splitLine: {
                        lineStyle: {
                            type: 'dashed'
                        }
                    },
                    scale: true
                },
                series: [
                    {
                        name: '2015',
                        data: data,
                        type: 'scatter',
                        symbolSize: function (data) {
                            return Math.sqrt(data[2])*5;
                        },
                        emphasis: {
                            focus: 'series',
                            label: {
                                show: true,
                                formatter: function (param) {
                                    return param.data[3]+" : "+param.data[2];
                                },
                                position: 'top'
                            }
                        },
                        itemStyle: {
                            shadowBlur: 10,
                            shadowColor: 'rgba(25, 100, 150, 0.5)',
                            shadowOffsetY: 5,
                            color: new echarts.graphic.RadialGradient(0.4, 0.3, 1, [
                                {
                                    offset: 0,
                                    color: 'rgb(129, 227, 238)'
                                },
                                {
                                    offset: 1,
                                    color: 'rgb(25, 183, 207)'
                                }
                            ])
                        }
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function celllineHeatmapDeep(random) {
    $.ajax({
        url: "celllineHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            genes = res.genes;
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["A549","AG04450","BE2C","BJ","GM12878","GM23248","GM23338","H1-hESC","HeLa-S3","HT1080","HUES64","IMR-90","Jurkat clone E61","K562","MCF-7","Panc1","PFSK-1","SK-MEL-5","U-87 MG","UCSF-4","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_cell', data, layout, config);
        },
        dataType: "json"
    });
}
function vitroHeatmapDeep(random) {
    $.ajax({
        url: "vitroHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["cardiac muscle cell","ectodermal cell","hepatocyte","mesenchymal stem cell","mesendoderm","mesodermal cell","neural stem progenitor cell","smooth muscle cell","trophoblast cell"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_vitro', data, layout, config);
        },
        dataType: "json"
    });
}
function primaryHeatmapDeep(random) {
    $.ajax({
        url: "primaryHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["astrocyte","B cell","CD14-positive monocyte","CD4-positive, alpha-beta T cell","common myeloid progenitor, CD34-positive","endothelial cell of umbilical vein","fibroblast of breast","fibroblast of lung","foreskin fibroblast","foreskin keratinocyte","foreskin melanocyte","keratinocyte","luminal epithelial cell of mammary gland","mammary epithelial cell","mammary stem cell","myoepithelial cell of mammary gland","natural killer cell","neurosphere","peripheral blood mononuclear cell","Purkinje cell","skin fibroblast","T-cell","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_primary', data, layout, config);
        },
        dataType: "json"
    });
}
function gtexHeatmapDeep(random) {
    $.ajax({
        url: "gtexHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["Adipose Tissue","Adrenal Gland","Blood Vessel","Bladder","Brain","Breast","Blood","Skin","Cervix Uteri","Colon","Esophagus","Fallopian Tube","Heart","Kidney","Liver","Lung","Salivary Gland","Muscle","Nerve","Ovary","Pancreas","Pituitary","Prostate","Small Intestine","Spleen","Stomach","Testis","Thyroid","Uterus","Vagina","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_gtex', data, layout, config);
        },
        dataType: "json"
    });
}
function ccleHeatmapDeep(random) {
    $.ajax({
        url: "ccleHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["prostate","stomach","urinary_tract","glioma","ovary","leukemia_other","kidney","thyroid","melanoma","soft_tissue","upper_aerodigestive","lymphoma_DLBCL","lung_NSC","Ewings_sarcoma","mesothelioma","T.cell_ALL","AML","multiple_myeloma","endometrium","pancreas","breast","B.cell_lymphoma_other","B.cell_ALL","lymphoma_Burkitt","CML","colorectal","chondrosarcoma","meningioma","neuroblastoma","lung_small_cell","esophagus","medulloblastoma","T.cell_lymphoma_other","fibroblast_like","osteosarcoma","lymphoma_Hodgkin","cervix","liver","giant_cell_tumour","bile_duct","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('exp_ccle', data, layout, config);
        },
        dataType: "json"
    });
}
function tcgaHeatmapDeep(random) {
    $.ajax({
        url: "tcgaHeatmapDeep",
        type: "get",
        data: {"random":random},
        async: true,
        success: function (res) {
            var colorscaleValue = [
                [0, '#fff'],
                [1, '#e91e63'],
            ];
            var data = [{
                z:jQuery.parseJSON(res.z),
                x:["ACC","BLCA","CESC","CHOL","COAD","DLBC","ESCA","GBM","HNSC","KICH","KIRC","KIRP","LGG","LIHC","LUAD","LUSC","MESO","NBL","OV","PAAD","PCPG","PRAD","READ","SARC","SKCM","STAD","TGCT","THCA","THYM","UCEC","UCS","UVM","WT","other"],
                y:res.y,
                type: 'heatmap',
                hoverongaps: false,
                colorscale: colorscaleValue,
            }];
            var layout = {
                title: 'Expression of Input' + ' associated genes',
                showlegend: false
            };
            var config = {
                toImageButtonOptions: {
                    format: 'svg', // one of png, svg, jpeg, webp
                    filename: 'gene express matrix',
                    scale: 1 // Multiply title/legend/axis/canvas sizes by this factor
                }
            };
            Plotly.newPlot('cancer_tcga', data, layout, config);
        },
        dataType: "json"
    });
}