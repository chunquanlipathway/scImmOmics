
var vue = new Vue({
    el : '#app',
    data : {
        bioSelects:["Cell line","Tissue"],
        bioSelect:"",
        tissueSelects:["Blood","lung"],
        tissueSelect:"",
        sampleSelects:[{name:"",value:""},{name:"",value:""}],
        sampleSelect:""
    },
    methods : {
        signalFun : function signalFun() {
            var _self = this;
            /*search biosample type
            * */
            $.ajax({
                url: "getbio",
                type: "get",
                data: {},
                async: true,
                success: function (res) {
                    _self.bioSelects = res.data;
                    _self.bioSelect = res.data[0];
                    /*search tissue type
                    * */
                    $.ajax({
                        url: "gettissue",
                        type: "get",
                        data: {"bioParam": _self.bioSelect},
                        async: true,
                        success: function (res) {
                            _self.tissueSelects = res.data;
                            _self.tissueSelect = res.data[0];
                            /*search sample name
                            * */
                            $.ajax({
                                url: "getsample",
                                type: "get",
                                data: {"bioParam": _self.bioSelect,"tissueParam": _self.tissueSelect},
                                async: true,
                                success: function (res) {
                                    _self.sampleSelects = res.data;
                                    _self.sampleSelect = res.data[0].value;
                                },
                                dataType: "json"
                            });
                        },
                        dataType: "json"
                    });
                },
                dataType: "json"
            });
        },
        bioSelectFun : function bioSelectFun() {
            var _self = this;
            /*search tissue type
             * */
            $.ajax({
                url: "gettissue",
                type: "get",
                data: {"bioParam": _self.bioSelect},
                async: true,
                success: function (res) {
                    _self.tissueSelects = res.data;
                    _self.tissueSelect = res.data[0];
                    /*search sample name
                             * */
                    $.ajax({
                        url: "getsample",
                        type: "get",
                        data: {"bioParam": _self.bioSelect,"tissueParam": _self.tissueSelect},
                        async: true,
                        success: function (res) {
                            _self.sampleSelects = res.data;
                            _self.sampleSelect = res.data[0].value;
                        },
                        dataType: "json"
                    });
                },
                dataType: "json"
            });
        },
        tissueSelectFun : function tissueSelectFun() {
            var _self = this;
            /*search sample name
            * */
            $.ajax({
                url: "getsample",
                type: "get",
                data: {"bioParam": _self.bioSelect,"tissueParam": _self.tissueSelect},
                async: true,
                success: function (res) {
                    _self.sampleSelects = res.data;
                    _self.sampleSelect = res.data[0].value;
                },
                dataType: "json"
            });
        }
    }
});
vue.signalFun();

var vue2 = new Vue({
    el : '#app2',
    data : {
        bioSelects:["Cell line","Tissue"],
        bioSelect:"",
        tissueSelects:["Blood","lung"],
        tissueSelect:""
    },
    methods : {
        signalFun : function signalFun() {
            var _self = this;
            /*search biosample type
            * */
            $.ajax({
                url: "getbio",
                type: "get",
                data: {},
                async: true,
                success: function (res) {
                    _self.bioSelects = res.data;
                    _self.bioSelect = res.data[0];
                    /*search tissue type
                    * */
                    $.ajax({
                        url: "gettissue",
                        type: "get",
                        data: {"bioParam": _self.bioSelect},
                        async: true,
                        success: function (res) {
                            _self.tissueSelects = res.data;
                            _self.tissueSelect = res.data[0];
                        },
                        dataType: "json"
                    });
                },
                dataType: "json"
            });
        },
        bioSelectFun : function bioSelectFun() {
            var _self = this;
            /*search tissue type
             * */
            $.ajax({
                url: "gettissue",
                type: "get",
                data: {"bioParam": _self.bioSelect},
                async: true,
                success: function (res) {
                    _self.tissueSelects = res.data;
                    _self.tissueSelect = res.data[0];
                },
                dataType: "json"
            });
        }
    }
});
vue2.signalFun();

function tissuegraph() {
    var chartDom = document.getElementById('tissuegraph');
    chartDom.style.width=$("#tissuegraphwidth").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    myChart.hideLoading();
    option = {
        title: {
            text: 'Statistics of Tissue type',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            left: 0,
            top: 1,
            bottom: 1,
            data: ["Adipose","Adipose Tissue","Adrenal Gland","Aorta","Biliary","Blood","Blood Vessel","Bone","Bone Marrow","Brain","Breast","Bronchial","Cerebellar Cortex","Colon","Connective Tissue","Coronary Artery","Embryo","Embryonic","Endothelial Of Umbilical Vein","Epithelial","Epithelium","Esophagus","Esophagus Muscularis Mucosa","Eye","Fetal Lung","Fetal Spleenocytes","Fibroblast","Fibrosarcoma","Foreskin","Gallbladder","Gum","Haematopoietic And Lymphoid","Haematopoietic And Lymphoid Tissue Blood","Head And Neck","Heart","HMSCs","HSPC","Intestine","IPSC","Kidney","Limb","Liver","Lung","Lymphoid Tissue","Mammary Gland","Muscle","Musculature","Nasopharyngeal Carcinoma","Nerve","Nose","Other","Ovary","Pancreas","PBMCs","Penis","Peripheral Blood","Pharyngeal","Placenta","Podocyte","Prostate","Prostate Gland","Shoulder","Skin","Spinal Cord","Spleen","Stomach","Submandibular Salivary Gland","Synovial Sarcoma","Testis","Thymus","Thyroid Gland","Tongue","Tonsil","Trachea","Umbilical Artery","Umbilical Cord","Umbilical Vein","Urinary Bladder","Uterus","Vagina"]
        },
        series: [
            {
                name: 'Number of Tissue type',
                type: 'pie',
                radius: '55%',
                center: ['65%', '65%'],
                data: [{name:'Adipose', value:27}, {name:'Adipose Tissue', value:32}, {name:'Adrenal Gland', value:20}, {name:'Aorta', value:42}, {name:'Biliary', value:5}, {name:'Blood', value:1202}, {name:'Blood Vessel', value:6}, {name:'Bone', value:134}, {name:'Bone Marrow', value:238}, {name:'Brain', value:603}, {name:'Breast', value:321}, {name:'Bronchial', value:8}, {name:'Cerebellar Cortex', value:1}, {name:'Colon', value:224}, {name:'Connective Tissue', value:13}, {name:'Coronary Artery', value:2}, {name:'Embryo', value:319}, {name:'Embryonic', value:1}, {name:'Endothelial Of Umbilical Vein', value:2}, {name:'Epithelial', value:11}, {name:'Epithelium', value:52}, {name:'Esophagus', value:26}, {name:'Esophagus Muscularis Mucosa', value:1}, {name:'Eye', value:30}, {name:'Fetal Lung', value:1}, {name:'Fetal Spleenocytes', value:1}, {name:'Fibroblast', value:28}, {name:'Fibrosarcoma', value:2}, {name:'Foreskin', value:52}, {name:'Gallbladder', value:1}, {name:'Gum', value:4}, {name:'Haematopoietic And Lymphoid', value:3}, {name:'Haematopoietic And Lymphoid Tissue Blood', value:1}, {name:'Head And Neck', value:8}, {name:'Heart', value:123}, {name:'HMSCs', value:2}, {name:'HSPC', value:1}, {name:'Intestine', value:45}, {name:'IPSC', value:14}, {name:'Kidney', value:189}, {name:'Limb', value:6}, {name:'Liver', value:89}, {name:'Lung', value:272}, {name:'Lymphoid Tissue', value:231}, {name:'Mammary Gland', value:129}, {name:'Muscle', value:2}, {name:'Musculature', value:108}, {name:'Nasopharyngeal Carcinoma', value:3}, {name:'Nerve', value:142}, {name:'Nose', value:5}, {name:'Other', value:357}, {name:'Ovary', value:41}, {name:'Pancreas', value:109}, {name:'PBMCs', value:2}, {name:'Penis', value:6}, {name:'Peripheral Blood', value:92}, {name:'Pharyngeal', value:4}, {name:'Placenta', value:2}, {name:'Podocyte', value:2}, {name:'Prostate', value:17}, {name:'Prostate Gland', value:163}, {name:'Shoulder', value:4}, {name:'Skin', value:147}, {name:'Spinal Cord', value:7}, {name:'Spleen', value:6}, {name:'Stomach', value:42}, {name:'Submandibular Salivary Gland', value:1}, {name:'Synovial Sarcoma', value:14}, {name:'Testis', value:10}, {name:'Thymus', value:11}, {name:'Thyroid Gland', value:8}, {name:'Tongue', value:6}, {name:'Tonsil', value:5}, {name:'Trachea', value:3}, {name:'Umbilical Artery', value:1}, {name:'Umbilical Cord', value:5}, {name:'Umbilical Vein', value:56}, {name:'Urinary Bladder', value:11}, {name:'Uterus', value:169}, {name:'Vagina', value:2}],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    option && myChart.setOption(option);
}

function tfgraph() {
    var chartDom = document.getElementById('tfgraph');
    chartDom.style.width=$("#tfwidth").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    myChart.hideLoading();
    option = {
        title: {
            text: 'TF Class',
            left: 'center'
        },
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            left: 'left'
        },
        series: [
            {
                name: 'Access From',
                type: 'pie',
                radius: '50%',
                center: ['70%', '50%'],
                data: [
                    {value: 3, label: {normal: {show: false, position: 'insideRight'}}, name: 'beta-Sheet binding to DNA'},
                    {value: 110, name: 'Basic domains'},
                    {value: 34, name: 'Other all-alpha-helical DNA-binding domains'},
                    {value: 317, name: 'Helix-turn-helix domains'},
                    {value: 12, name: 'alpha-Helices exposed by beta-structures'},
                    {value: 360, label: {normal: {show: false, position: 'insideRight'}}, name: 'UNKNOW'},
                    {value: 11, label: {normal: {show: false, position: 'insideRight'}}, name: 'beta-Hairpin exposed by an alpha/beta-scaffold'},
                    {value: 191, label: {normal: {show: false, position: 'insideRight'}}, name: 'Zinc-coordinating DNA-binding domains'},
                    {value: 46, label: {normal: {show: false, position: 'insideRight'}}, name: 'Immunoglobulin fold'},
                    {value: 1, label: {normal: {show: false, position: 'insideRight'}}, name: 'beta-Barrel DNA-binding domains'}
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    option && myChart.setOption(option);
}

function chromegraph() {
    var chartDom = document.getElementById('chromegraph');
    chartDom.style.width=$("#chromewidth").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    myChart.hideLoading();
    option = {
        title: {
            text: 'Number of chrome',
            subtext: '',
            left: 'center'
        },
        toolbox: {
            show: true,
            feature: {
                saveAsImage: {title:"save"}
            }
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 'left'
        },
        series: [
            {
                type: 'pie',
                radius: '50%',
                left: '20%',
                data: [
                    {"name": "chr1", "value": "6500"},
                    {"name": "chr10", "value": "3258"},
                    {"name": "chr11", "value": "3290"},
                    {"name": "chr12", "value": "3093"},
                    {"name": "chr13", "value": "1465"},
                    {"name": "chr14", "value": "1928"},
                    {"name": "chr15", "value": "2141"},
                    {"name": "chr16", "value": "2708"},
                    {"name": "chr17", "value": "3235"},
                    {"name": "chr18", "value": "1499"},
                    {"name": "chr19", "value": "2888"},
                    {"name": "chr2", "value": "4931"},
                    {"name": "chr20", "value": "1949"},
                    {"name": "chr21", "value": "1069"},
                    {"name": "chr22", "value": "1752"},
                    {"name": "chr3", "value": "3801"},
                    {"name": "chr4", "value": "2669"},
                    {"name": "chr5", "value": "3263"},
                    {"name": "chr6", "value": "3477"},
                    {"name": "chr7", "value": "3459"},
                    {"name": "chr8", "value": "2719"},
                    {"name": "chr9", "value": "2993"},
                    {"name": "chrM", "value": "15"},
                    {"name": "chrX", "value": "1241"},
                    {"name": "chrY", "value": "315"}
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    option && myChart.setOption(option);
}



$("#example").click(function(){
    $("#region").val("");
});

$("#exampleGene").click(function(){
    $("#geneSelect").val("Closest")
    $("#geneSymbol").val("DVL1");
});

$("#exampleSNPid").click(function(){
    $("#snpid").val("rs2240899")
});

$("#exampleTFid").click(function(){
    $("#tf").val("AHR")
});