var olanguage = {
    "sProcessing": 'processing......',
    "sLengthMenu": "_MENU_ entries per page",
    "sZeroRecords": "No matching data found",
    "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoEmpty": "Showing _START_ to _END_ of _TOTAL_ entries",
    "sInfoFiltered": "( Filter from _MAX_ records )",
    "sSearch": "Search: ",
    "oPaginate": {
        "sFirst": "home",
        "sPrevious": "‹",
        "sNext": "›",
        "sLast": "end"
    }
}

function enhancercount_graph(geneSymbol,geneSelect,checkh3k4me3) {
    var chartDom = document.getElementById('count');
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "enhancerBygene_count_graph",
        type: "get",
        data: {"geneSymbol": geneSymbol, "geneSelect":geneSelect,"checkh3k4me3":checkh3k4me3},
        async: true,
        success: function (res) {
            console.log(res);
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    top: '3%',
                    left: '3%',
                    right: '5%',
                    bottom: '2%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLabel:{
                        interval: 0, rotate: 30
                    },
                    data: ['H3K27ac', 'H3K4me1', 'ATAC-seq', 'DNase-seq', 'MNase-seq', 'FAIRE-seq', 'Starr-seq', 'POLR2A', 'EP300']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        data: [res.H3K27ac, res.H3K4me1, res.ATAC, res.DNase, res.MNase, res.FAIRE, res.Starr, res.POLR2A, res.EP300],
                        type: 'line'
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}


function enhancerByGene(geneSymbol,geneSelect,checkh3k4me3,singal) {
    var tab = "#"+singal+"tab";
    $(tab).DataTable({
        ajax: {
            url: "tabByGene",
            type: "GET",
            async: true,
            data: {"geneSymbol": geneSymbol,"geneSelect":geneSelect,"checkh3k4me3":checkh3k4me3,"singal":singal}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: false,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {
                "data": "id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.id + "'>E_" + row.id + "</a>";
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return row.chrome + ":" + row.start + "-" + row.end;
                }
            },
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  row.end - row.start;
                }
            },
            {"data": "tissueType"},
            {
                "data": "biosampleName",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='detailBySample?sample=" + row.sampleid+ "'>" + row.biosampleName + "</a>";
                }
            },
            {"data": "logpvalue"},
            {"data": "interaction"},
            {"data": "methy450K"},
            {"data": "commonsnp"},
            {"data": "crisps"},
            {"data": "enhancer"},
            {"data": "eqtl"},
            {"data": "gwas"},
            {"data": "tad"},
            {
                "data": "chrome",
                "render": function (data, type, row, meta) {
                    return  "<a class='link-info' target='_blank' href='http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg38&lastVirtModeType=default&lastVirtModeExtraState=&virtModeType=default&virtMode=0&nonVirtPosition=&position="+row.chrome+"%3A"+row.start+"%2D"+row.end+"&hgsid=1334138285_q3d2baKSxBnqflr14dK9CRYkDtfA'>" + "UCSC</a>|<a>ENID"+"</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function exp_cell(geneSymbol) {
    var chartDom = document.getElementById('exp_cell');
    chartDom.style.width=$("#exp_cellSource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getEXP_cell_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["A549","AG04450","BE2C","BJ","GM12878","GM23248","GM23338","H1-hESC","HeLa-S3","HT1080","HUES64","IMR-90","Jurkat clone E61","K562","MCF-7","Panc1","PFSK-1","SK-MEL-5","U-87 MG","UCSF-4","other"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function cancer_tcga(geneSymbol) {
    var chartDom = document.getElementById('cancer_tcga');
    chartDom.style.width=$("#exp_cellSource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getCancerTcga_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["ACC","BLCA","CESC","CHOL","COAD","DLBC","ESCA","GBM","HNSC","KICH","KIRC","KIRP","LGG","LIHC","LUAD","LUSC","MESO","NBL","OV","PAAD","PCPG","PRAD","READ","SARC","SKCM","STAD","TGCT","THCA","THYM","UCEC","UCS","UVM","WT","other"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function exp_vitro(geneSymbol) {
    var chartDom = document.getElementById('exp_vitro');
    chartDom.style.width=$("#exp_vitroSource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getEXP_vitro_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["cardiac muscle cell","ectodermal cell","hepatocyte","mesenchymal stem cell","mesendoderm","mesodermal cell","neural stem progenitor cell","smooth muscle cell","trophoblast cell"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function exp_primary(geneSymbol) {
    var chartDom = document.getElementById('exp_primary');
    chartDom.style.width=$("#exp_primarySource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getEXP_primary_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["astrocyte","B cell","CD14-positive monocyte","CD4-positive, alpha-beta T cell","common myeloid progenitor, CD34-positive","endothelial cell of umbilical vein","fibroblast of breast","fibroblast of lung","foreskin fibroblast","foreskin keratinocyte","foreskin melanocyte","keratinocyte","luminal epithelial cell of mammary gland","mammary epithelial cell","mammary stem cell","myoepithelial cell of mammary gland","natural killer cell","neurosphere","peripheral blood mononuclear cell","Purkinje cell","skin fibroblast","T-cell","other"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function exp_gtex(geneSymbol) {
    var chartDom = document.getElementById('exp_gtex');
    chartDom.style.width=$("#exp_gtexSource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getEXP_gtex_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["Adipose Tissue","Adrenal Gland","Blood Vessel","Bladder","Brain","Breast","Blood","Skin","Cervix Uteri","Colon","Esophagus","Fallopian Tube","Heart","Kidney","Liver","Lung","Salivary Gland","Muscle","Nerve","Ovary","Pancreas","Pituitary","Prostate","Small Intestine","Spleen","Stomach","Testis","Thyroid","Uterus","Vagina","other"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function exp_ccle(geneSymbol) {
    var chartDom = document.getElementById('exp_ccle');
    chartDom.style.width=$("#exp_ccleSource").width()-15 + 'px'
    var myChart = echarts.init(chartDom, null, {renderer: 'svg'});
    myChart.showLoading();
    var option;
    $.ajax({
        url: "getEXP_ccle_gene",
        type: "get",
        data: {"geneSymbol": geneSymbol},
        async: true,
        success: function (res) {
            myChart.hideLoading();
            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {title:"save"}
                    }
                },
                grid: {
                    left: '3%',
                    right: '5%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ["prostate","stomach","urinary_tract","glioma","ovary","leukemia_other","kidney","thyroid","melanoma","soft_tissue","upper_aerodigestive","lymphoma_DLBCL","lung_NSC","Ewings_sarcoma","mesothelioma","T.cell_ALL","AML","multiple_myeloma","endometrium","pancreas","breast","B.cell_lymphoma_other","B.cell_ALL","lymphoma_Burkitt","CML","colorectal","chondrosarcoma","meningioma","neuroblastoma","lung_small_cell","esophagus","medulloblastoma","T.cell_lymphoma_other","fibroblast_like","osteosarcoma","lymphoma_Hodgkin","cervix","liver","giant_cell_tumour","bile_duct","other"],
                        axisTick: {
                            alignWithLabel: true
                        },
                        axisLabel:{
                            interval: 0, rotate: 30
                        }
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
                series: [
                    {
                        name: 'FPKM',
                        type: 'bar',
                        barWidth: '60%',
                        data: jQuery.parseJSON(res.data),
                    }
                ]
            };
            option && myChart.setOption(option);
        },
        dataType: "json"
    });
}

function pathway(geneSymbol) {
    $("#pathwayTab").DataTable({
        ajax: {
            url: "pathwayByGene",
            type: "GET",
            async: true,
            data: {"geneSymbol": geneSymbol}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: true,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "gene"},
            {
                "data": "pathway_ID",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='detailByEn?enid=" + row.pathway_ID + "'>" + row.pathway_ID + "</a>";
                }
            },
            {"data": "pathway_name"},
            {"data": "pathway_source"},
            {"data": "gene_number"},
            {"data": "edge_number"}
        ],
        oLanguage: olanguage
    });
}

function disease(geneSymbol) {
    $("#disease").DataTable({
        ajax: {
            url: "diseaseBygene",
            type: "GET",
            async: true,
            data: {"geneSymbol": geneSymbol}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: true,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "gene"},
            {"data": "diseaseid"},
            {"data": "diseasename"},
            {"data": "diseasetype"},
            {"data": "diseaseclass"},
            {"data": "diseasesemantic"},
            {"data": "score"},
            {"data": "source"}
        ],
        oLanguage: olanguage
    });
}


function goterm(geneSymbol) {
    $("#gotermTab").DataTable({
        ajax: {
            url: "gotermByGene",
            type: "GET",
            async: true,
            data: {"geneSymbol": geneSymbol}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: true,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "gene"},
            {"data": "goterm"},
            {
                "data": "identifier",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='https://www.ebi.ac.uk/QuickGO/term/" + row.identifier + "'>" + row.identifier + "</a>";
                }
            }
        ],
        oLanguage: olanguage
    });
}

function hallmark(geneSymbol) {
    $("#hallmarkTab").DataTable({
        ajax: {
            url: "hallmarkByGene",
            type: "GET",
            async: true,
            data: {"geneSymbol": geneSymbol}
        },
        // bStateSave: false,
        bProcessing : true,
        serverSide: true,
        searching: false,
        paging: true,
        ordering: true,
        scrollX: true,
        // lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        bLengthChange: false,
        destroy: true,
        columns: [
            {"data": "gene"},
            {"data": "cancer_hallmark"},
            {
                "data": "go_term_id",
                "render": function (data, type, row, meta) {
                    return "<a class='link-info' target='_blank' href='https://www.ebi.ac.uk/QuickGO/term/" + row.go_term_id + "'>" + row.go_term_id + "</a>";
                }
            },
            {"data": "go_term_name"}
        ],
        oLanguage: olanguage
    });
}

function datatablesShow() {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        // 当切换tab时，强制重新计算列宽
        $.fn.dataTable.tables({
            visible: true,
            api: true
        }).columns.adjust();
    });
    /* datatables配置结束 */
}