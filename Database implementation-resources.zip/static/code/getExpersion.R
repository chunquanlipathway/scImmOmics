enrichment<-function(x,adjust,threshold=0.05,bgfile) {
	load(bgfile)
	input<-c(x)
	n<-length(input)
	result<-matrix(NA,length(GeneSet),16)
	for (i in 1:length(GeneSet)) {
		result[i,1]<-GeneSet[[i]]$SampleID
		result[i,2]<-GeneSet[[i]]$Sapiens
		result[i,3]<-GeneSet[[i]]$Tissue
		result[i,4]<-GeneSet[[i]]$Disease
		result[i,5]<-GeneSet[[i]]$Status
		result[i,6]<-GeneSet[[i]]$PMID
		result[i,7]<-GeneSet[[i]]$Article
		result[i,8]<-GeneSet[[i]]$Journal
		result[i,9]<-GeneSet[[i]]$Year
		result[i,10]<-GeneSet[[i]]$Source
		result[i,11]<-GeneSet[[i]]$Platform
		result[i,12]<-GeneSet[[i]]$Integrated_Type
		result[i,13]<-GeneSet[[i]]$CellType2
		inter<-intersect(GeneSet[[i]]$GeneSet,x)
		result[i,14]<- paste(inter,collapse="; ")
		t<-length(GeneSet[[i]]$GeneSet)
		r<-length(inter)
		result[i,15]<-signif(phyper(r-1,t,20000-t,n,lower.tail=FALSE),3)
	}
	result[,16]<-signif(p.adjust(result[,15],method="fdr",n=length(GeneSet)),3)

	if (adjust==1) {
		result<-result[which(as.numeric(result[,16])<as.numeric(threshold)),]
		result<-result[sort.list(as.numeric(result[,16]),decreasing=F),]
	} else {
		result<-result[which(as.numeric(result[,15])<as.numeric(threshold)),]
		result<-result[sort.list(as.numeric(result[,15]),decreasing=F),]
	}
	result <- as.data.frame(result)
	result <- data.frame(lapply(result, as.character), stringsAsFactors = FALSE)
# 	write.csv(result,"F://webdata//update//bbb.txt")
	return(result)
}

getExpersionByTissue <- function(file,gene,index) {
    print(gene)
    print(head(index))
    colindex<-c(index)
    ncolindex=as.numeric(colindex)
    data<-readRDS(file)
    print(head(data))
    if(length(which(rownames(data)%in%gene))>0){
        index<-which(rownames(data)%in%gene)
        print(index)
        print(class(index))
        a<-data[index,ncolindex]
        result<-toString(a)
        return(result)
    }else if(gene==""){
        index<-1L
        a<-data[index,ncolindex]
        result<-toString(a)
        return(result)
    }else{
        result<-toString(rep(0,length(data[1,])))
        return(result)
    }
}

getExpersion <- function(file,gene) {
    print(gene)
    print(file)
    data<-readRDS(file)
    print(head(data))
    if(length(which(rownames(data)%in%gene))>0){
        index<-which(rownames(data)%in%gene)
        print(index)
        print(class(index))
        result<-data[index,]
        print("gene")
        return(result)
    }else if(gene==""){
        index<-1L
        result<-data[index,]
        print("no gene")
        return(result)
    }else{
        result<-rep(0,length(data[1,]))
        print("no")
        return(result)
    }
}


getGeneList <- function(file) {
    print(file)
    data<-readRDS(file)
    print(dim(data))
    result<-rownames(data)
    print(head(result))
    return(result)
}

getCorExp <- function(file) {
    data<-readRDS(file)
    array <- data[[1]]
    celltype <- rownames(data[[2]])
    result <- list(array, celltype)
    return(result)
}


getCorExp_integana <- function(file) {
    data<-readRDS(file)
    array <- data[[1]]
    celltypeatac <- rownames(data[[1]])
    celltyperna <- colnames(data[[1]])
    result <- list(array, celltypeatac, celltyperna)
    return(result)
}

############ATAC############
getExpersion_atac <- function(file,gene,metadata,outfile) {
    print(gene)
    data<-readRDS(file)
    metadata<-read.csv(metadata,header=T,sep="\t",row.names=1)
    print(dim(data))
    if(length(which(rownames(data)%in%gene))>0){
        index<-which(rownames(data)%in%gene)
        print(index)
        print(class(index))
        a<-data[index,]
    }else{
        a<-data[1,]
    }
    fina<-cbind(metadata[match(colnames(data),rownames(metadata)),1:2],a)
    fina<-fina[order(fina[,3],decreasing = F),]
    return(fina)
}

getGeneList_atac <- function(file) {
    data<-readRDS(file)
    print(dim(data))
    result=rownames(data)
    return(result)
}

getTFmotifValue_atac <- function(file,tf,metadata,outfile) {
    print(tf)
    data<-readRDS(file)
    metadata<-read.csv(metadata,header=T,sep="\t",row.names=1)
    print(dim(data))
    if(length(which(rownames(data)%in%tf))>0){
        index<-which(rownames(data)%in%tf)
        print(index)
        print(class(index))
        a<-data[index,]
    }else{
        a<-data[1,]
    }
    fina<-cbind(metadata[match(colnames(data),rownames(metadata)),1:2],a)
    fina<-fina[order(fina[,3],decreasing = F),]
    return(fina)
}

getTFList_atac <- function(file) {
    data<-readRDS(file)
    print(dim(data))
    result<-rownames(data)
    return(result)
}

getHeatTF_atac <- function(file) {
    data<-readRDS(file)
    result<-rownames(data)
    return(result)
}
getHeatCell_atac <- function(file) {
    data<-readRDS(file)
    result<-colnames(data)
    return(result)
}
getHeatData_atac <- function(file) {
    data<-readRDS(file)
    return(data)
}
getHeatCelltype_atac <- function(file,metafile) {
    library(dplyr)
    meta=read.csv(metafile,sep="\t",row.names=1,header=T)
    tfdata<-readRDS(file)
    print(dim(tfdata))
    print(dim(meta))
    Barcode=colnames(tfdata)
    celldf=as.data.frame(Barcode)
    copydata <- tibble::rownames_to_column(meta, "ID")
    result=inner_join(celldf,copydata,by=c("Barcode"="ID"))[,"Celltype2"]
    return(result)
}
#meta=read.table("GSE164849_metadata.txt",header=T)
#tfdata=readRDS("GSE164849_TF1000.rds")
#b=colnames(tfdata)
#c=subset(meta,Barcode%in%b)